#!/bin/sh
# Copyright (C) 2012-2014 Amarisoft
# LTEMME system config version 2015-10-28

# Run once as root after the boot to init the network for LTEMME.

# Name of the network interface which is used to access to the local
# network (and Internet)
ifname="default"

# IPv6 configuration
ipv6=0

# Check root access
if [ `id -u` != 0 ] ; then 
    echo -e "\033[33mWarning, script must be run with root permissions\033[0m"
    exit 1
fi


while [ "$1" != "" ] ; do
  case $1 in
    -h|--help)
      echo "Usage:"
      echo "> $0 [-6] [<ifname>]";
      echo "  ifname: interface name of the network connect to ths outside world"
      echo "    If set to default or omitted, script will use default gateway interface"
      echo "    If set to lo, configuration will be discared"
      echo "  -6 to use ipv6"
      exit 1;
      ;;
    -6)
      echo "Use IPv6 configuration"
      ipv6=1
      ;;
    *)
      ifname="$1"
      ;;
  esac
  shift
done

# Interface lookup
if [ "$ifname" != "lo" ] ; then

    # May be ipv6
    iflist=$(ifconfig -a | sed 's/[: \t].*//;/^$/d')
    defif=$(netstat -rn | grep UG | awk '{print $8}')

    if [ "$ifname" = "default" ] ; then
        ifname="$defif"
        echo "Using default interface '$ifname'";
    fi

    # Interface present ?
    found=0;
    for i in $iflist; do
        if [ "$i" = "$ifname" ] ; then
            found=1;
        fi
    done
    if [ "$found" = "0" ] ; then
        echo -e "\033[33mWarning, $ifname interface not found\033[0m"
        echo "Available interfaces:"
        for f in $iflist ; do
            if [ "$f" = "$defif" ] ; then
                echo -e "  - \033[32m$f\033[0m (default)"
            else
                echo "  - $f"
            fi
        done
        echo "You may edit this script to force interface and/or to edit iptables rules"
        exit 1
    fi
fi



########################################################################
# Activate masquerading and forwarding so that the UEs connected to
# the eNodeB can access the local network.
echo 1 > /proc/sys/net/ipv4/ip_forward

if [ "$ifname" != "lo" ] ; then
  iptables -t nat -A POSTROUTING -o ${ifname} -j MASQUERADE
fi

########################################################################
# Note: the two following rules are only needed if a firewall is enabled
# on your PC.

# Warning: Fedora 17 specific: remove the rule blocking the
# forwarding.
RULE=$(iptables -v -n --line-numbers -L FORWARD | grep REJECT | cut -d ' ' -f1)
if [ "$RULE" != "" ] ; then
    iptables -D FORWARD $RULE
fi

# local connections from LTE
iptables -I INPUT -i tun0 -j ACCEPT

# IPv6
if [ "$ipv6" = "1" ] ; then

    # Enable stateless address autoconfiguration also in case of ipv6 forwarding
    echo 2 > /proc/sys/net/ipv6/conf/${ifname}/accept_ra

    echo 1 > /proc/sys/net/ipv6/conf/all/forwarding
    if [ "$ifname" != "lo" ] ; then
      ip6tables -t nat -A POSTROUTING -o ${ifname} -j MASQUERADE
    fi
    ip6tables -I INPUT -i tun0 -j ACCEPT
fi
exit 0;
