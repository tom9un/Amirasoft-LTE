#!/bin/bash
# Copyright (C) 2012-2015 Amarisoft
# LTE system logger version 2015-10-28

# Path for multi environment support
export PATH="$PATH:/bin/:/usr/bin/:/usr/local/bin"

source /etc/ltestart.conf

# Override with local config
# Every parameter below can be overriden
if [ -e "/root/.lte" ] ; then
    source /root/.lte
fi

while [ "$1" != "" ] ; do

    if [ -e "$1" ] ; then
        # Avoid storing logs with comments only
        HAS_LOG=$(grep -v -l "#" $1)
        if [ "$HAS_LOG" != "" ] ; then
            DATE=$(date -u +%Y%m%d.%H:%M:%S | sed -e "s/ /-/g")
            FILE=$(basename $1)
            mv $1 "${LOG_PATH}/${FILE}.${DATE}"
        else
            rm -f $1
        fi
    fi
    shift
done

