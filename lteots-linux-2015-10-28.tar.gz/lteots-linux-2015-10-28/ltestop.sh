#!/bin/bash
# Copyright (C) 2012-2015 Amarisoft
# LTE system stopper version 2015-10-28

# Redirect IO
exec 0>&-
exec 1>>/tmp/lte.log
exec 2>>/tmp/lte.log

# Path for multi environment support
export PATH="$PATH:/bin/:/usr/bin/:/usr/local/bin"

echo "* Stop LTE service"

# Kill
CUR=$(pgrep ltestart.sh)
if [ "$CUR" != "" ] ; then
    echo "Killing $CUR"
    kill -9 $CUR
fi

# Quit programs and screen windows
for i in 0 1 2 3 ; do
    screen -S lte -p $i -X stuff $'\nquit\n'
    screen -S lte -p $i -X stuff $'exit\n'
done

# Save logs
ltelogs.sh /tmp/ims.log /tmp/mme.log /tmp/enb0.log /tmp/mbmsgw.log

exit 0

