#!/bin/bash
# Copyright (C) 2012-2015 Amarisoft
# LTE system starter version 2015-10-28

##################
# Default config #
##################
source /etc/ltestart.conf

# Override with local config
# Every parameter below can be overriden
if [ -e "/root/.lte" ] ; then
    source /root/.lte
fi


# Redirect IO
exec 0>&-
exec 1>>$LOG_FILE
exec 2>>$LOG_FILE

# Send command to window
function cmd
{
    win="$1"

    screen -S lte -p $win -X stuff $'\n' # Empty line in case of

    while [ "$2" != "" ] ; do
        screen -S lte -p $win -X stuff "$2"$'\n'
        shift
    done
}


# Path for multi environment support
export PATH="$PATH:/bin/:/usr/bin/:/usr/local/bin"

echo "* Start LTE service"

# Logs
LOG_CFG="file.rotate=$LOG_SIZE,file.path=$LOG_PATH"
mkdir -p $LOG_PATH

# Poll
while [ 1 ] ; do

    ##########
    # Screen #
    ##########
    SCREEN=$(screen -ls lte | grep -w lte)
    if [ "$SCREEN" = "" ] ; then
        echo "* Create screen and initialize windows"

        # start a new screen session
        screen -dm -S lte

        # Add windows
        screen -S lte -X screen
        screen -S lte -X screen
        screen -S lte -X screen

        # Set HOME for UHD to find calibration files
        cmd $ENB_WIN "export HOME=/root"
    fi

    # Update date
    DATE=$(date -u +%Y%m%d-%H:%M:%S | sed -e "s/ /-/g")

    S1CONNECT=0

    #######
    # MME #
    #######
    if [ -e "$MME_PATH/ltemme" ] ; then
        # Init
        if [ "$MME_INIT" != "done" ] ; then

            echo "* Initialize MME with '$MME_INIT' interface"
            $MME_PATH/lte_init.sh $MME_INIT
            if [ "$?" = "0" ] ; then
                echo "* MME initialized"
                MME_INIT="done"
            else
                # Configure at least locally to allow LTE local connections
                if [ "$MME_LOCAL" != "1" ] ; then
                    echo "* Initialize MME with local interface"
                    $MME_PATH/lte_init.sh lo
                    MME_LOCAL=1
                fi
            fi
        fi

        MME=$(pgrep ltemme)
        if [ "$MME" = "" ] ; then

            # "MME not running, start it here"
            echo "* Starting MME"
            ltelogs.sh /tmp/mme.log
            cmd $MME_WIN "cd $MME_PATH" "./ltemme config/mme.cfg" "log $LOG_CFG"

            # Wait for MME to start
            sleep 1

            S1CONNECT=1
        fi

        #######
        # IMS #
        #######
        if [ -e "$IMS_PATH/lteims" ] ; then
            IMS=$(pgrep lteims)
            if [ "$IMS" = "" ]; then
                # IMS not running, start it here
                echo "* Starting IMS"
                ltelogs.sh /tmp/ims.log
                cmd $IMS_WIN "cd $IMS_PATH" "./lteims config/ims.cfg" "log $LOG_CFG"

                sleep 1
                cmd $MME_WIN "imsconnect"
            fi
        fi
    fi

    #######
    # eNB #
    #######
    if [ -e "$ENB_PATH/lteenb" ] ; then
        # Init
        if [ "$ENB_INIT" != "done" ] ; then
            echo "* Initialize eNB"
            $ENB_PATH/lte_init.sh
            if [ "$?" = "0" ] ; then
                ENB_INIT="done"
            fi
        fi

        ENB=$(pgrep lteenb)
        if [ "$ENB" = "" ]; then
            # Test if Radio head is running to start eNB
            if [ -e "${ENB_PATH}/config/rf_driver/rrh_check.sh" ] ; then
                ${ENB_PATH}/config/rf_driver/rrh_check.sh $RRH_CFG
                RRH="$?"
            else
                RRH="0"
            fi
            if [ "$RRH" = "0" ] ; then
                # "eNodeB not running, start it here"
                echo "* Starting eNB"
                ltelogs.sh /tmp/enb0.log
                cmd $ENB_WIN "cd $ENB_PATH" "./lteenb config/enb.cfg" "log $LOG_CFG" "t"
            fi

        else
            # Force S1 connection ?
            if [ "$S1CONNECT" = "1" ] ; then
                cmd "ENB" "cd $ENB_PATH" "s1connect" "t"
            fi
        fi
    fi

    ########
    # MBMS #
    ########
    if [ -d "$MBMS_PATH" ] ; then
        # Init
        if [ "$MBMS_INIT" != "done" ] ; then
            echo "* Initialize MBMSGW"
            $MBMS_PATH/lte_init.sh
            if [ "$?" = "0" ] ; then
                MBMS_INIT="done"
            fi
        fi

        MBMS=$(pgrep ltembmsgw)
        if [ "$MBMS" = "" ]; then
            # MBMS not running, start it here
            echo "* Starting MBMSGW"
            ltelogs.sh /tmp/mbmsgw.log
            cmd $MBMS_WIN "cd $MBMS_PATH" "./ltembmsgw config/mbmsgw.cfg" "log $LOG_CFG"
        fi
    fi

    # Remove core dumps older than 30min
    find /tmp/ -name "core*" -mmin 30 | xargs rm -f

    # Remove logs if too much
    while [ $(du -ks $LOG_PATH | cut -d $'\t' -f1) -gt $LOG_PERSISTENT_SIZE ] ; do
        FILES=$(ls -a $LOG_PATH)
        for i in $FILES ; do
            if [ -f $LOG_PATH/$i ] ; then
                rm $LOG_PATH/$i;
                break
            fi
        done
    done

    # 5s polling
    sleep 5

done
