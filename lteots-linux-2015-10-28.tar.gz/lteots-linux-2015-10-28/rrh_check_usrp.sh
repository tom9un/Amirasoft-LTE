#!/bin/bash
# Copyright (C) 2012-2015 Amarisoft
# Ettus USRP presence checker 2015-10-28

TYPE="##TYPE##"

set -e

if [ "$TYPE" = "b2x0" ] ; then
    uhd_usrp_probe 1>/dev/null 2>/dev/null

else
    if [ "$1" = "" ] ; then
        exit 1
    fi
    for i in $@ ; do
        uhd_usrp_probe --args=addr=$i 1>/dev/null 2>/dev/null
    done
fi

exit 0

