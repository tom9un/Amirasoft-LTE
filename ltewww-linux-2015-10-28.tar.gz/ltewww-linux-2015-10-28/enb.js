
Ext.define("lte.enb.tab", {

	extend: 'Ext.panel.Panel',
	layout: 'border',
	
	constructor: function (config) {
		this._client = config.client;

		this._duration = 90000;
		this._minTime  = this._startTime = new Date() - 0;
		this._maxTime  = this._minTime + this._duration;

		this._rntiList = {};
		this._storeFields = ["time"];

		// Chart config
		this._chartList = [{
			title:		"Bitrate",
			fieldType:	["dl_bitrate", "ul_bitrate"],
			unit: 'brate'
		}, {
			title:		"TX/RETX",
			fieldType:	["dl_tx", "dl_retx", "ul_tx", "ul_retx"],
			unit: ' packet(s)'
		}];

		// Fast access to chart from field type
		var field2chart = this._field2chart = {};
		this._chartList.forEach(function (chart) {
			chart.fieldType.forEach(function (f) {
				field2chart[f] = chart;
			});
		});

		// List of stats
		this._statsData = [];

		// Listen events
		this._listenerId = this._client.registerEventListener('*', this._eventListener.bind(this));

		this.callParent(arguments);
	},

	listeners: {
		activate: function () {
			this._updater.update(true);
			this._updater.unlock();
			this._chartList.forEach(function (chart) { chart.comp.unlock(); });
		},

		deactivate: function() {
			this._updater.lock();
			this._chartList.forEach(function (chart) { chart.comp.lock(); });
		},

		close: function () {
			this._updater.destroy();
			this._client.unregisterEventListener(this._listenerId);
		},
	},

	lteUpdate: function() {
		this._updater.update(true);
	},

	initComponent: function () {
		this.callParent(arguments);

		var cellStore = this._cellStore = Ext.create('Ext.data.Store', {
			fields: ["cell_id", "n_rb_dl", "n_rb_ul"]
		});

		var cellGrid = Ext.create('Ext.grid.Panel', {
			store: cellStore,
			viewConfig:{
				markDirty: false
			},
			columns: [{
				text: "Cell ID",
				dataIndex: "cell_id",
				flex: 1,
			}, {
				xtype: 'actioncolumn',
				width: 30,
				text: "",
				dataIndex: 'const',
				items: [{
					scope: this,
					getClass: function (constel, meta, rec, rowIndex, colIndex, store) {
						return constel ? "icon-star" : "icon-nostar";
					},
					tooltip: lteLogs.tooltip("Start/stop recording constellations"),
					handler: function(view, rowIndex, colIndex, item, e, record) {
						var constel = record.get("const");
						var cell_id = record.get("cell_id");
						this._client.sendMessage(constel ? "const_stop" : "const_start", {cell_id: cell_id}, function (resp) {
							record.set("const", !constel);
							view.refresh();
						});
					}
				}]
			}],
		});

		var ueStore = Ext.create('Ext.data.Store', {
			fields: ['rnti', 'enb_ue_id', 'mme_ue_id', 'cell_id']
		});

		var ueGrid = Ext.create('Ext.grid.Panel', {
			store: ueStore,
			columns: {
				defaults: {
					menuDisabled: true,
					flex: 1
				},
				items: [{
					text: 'RNTI',
					dataIndex: 'rnti',
				}, {
					text: 'Cell',
					dataIndex: 'cell_id',
				}, {
					text: 'ENB-UE-ID',
					dataIndex: 'enb_ue_id',
				}, {
					text: 'MME-UE-ID',
					dataIndex: 'mme_ue_id',
				}],
			},
			listeners: {
				scope: this,
				selectionchange: function(view, selected, eOpts) {
				},

				// UE right click menu
				cellcontextmenu: function(view, td, cellIndex, record, tr, rowIndex, e, eOpts) {

					var items = [];
					var ue_data = record.getData();
					var cell_id = ue_data.cell_id;
					for (var i = 0, count = cellStore.getCount(); i < count; i++) {
						var cell_data = cellStore.getAt(i).getData();
						if (cell_data.cell_id === cell_id) continue;

						items.push({
							text: 'Handover to cell ' + cell_data.cell_id,
							scope: this,
							iconCls: 'icon-air',
							handler: (function(msg) {
								this._client.sendMessage(msg, (function (r) {
									this._updater.update(true);
								}).bind(this));
							}).bind(this, {
								message: 'handover',
								enb_ue_id: ue_data.enb_ue_id,
								pci: cell_data.cell_id,
								dl_earfcn: cell_data.dl_earfcn
							})
						});
					}

					var menu = new Ext.menu.Menu({items: items});
					var position = e.getXY();
					e.stopEvent();
					menu.showAt(position);
				},
			}
		});

		this._updater = Ext.create("lte.updater", {
			scope:			this,
			updateDelay:	1000,
			autoDelay:		5000,
			dirty:			true,
			lock:			1,
			handler:		function () {
				this._client.sendMessage({message: 'ue_get'}, (function (msg) {
					ueStore.loadData(msg.ue_list);
				}).bind(this));
			}
		});

		this.add({
			region: 'west',
			layout: 'border',
			width: 300,
			items: [{
				region: "north",
				layout: 'fit',
				height: 200,
				items: [cellGrid],
			}, {
				region: "center",
				layout: 'fit',
				items: [ueGrid],
			}]
		});

		var now = new Date() * 1;
		this.add({
			split: true,
			layout: 'fit',
			region: 'center',
			items: [{
				xtype: 'tabpanel',
				items: this._chartList.map(function (chart) {
					chart.comp = Ext.create("lte.graph", {
						title: chart.title,
						graph: {
							axis: {
								x: {
									unit: 'date',
									auto: 'max',
									min: now,
									max: now + 60000,
								},
								y: {
									unit: chart.unit,
								}
							}
						}
					});
					chart.comp.lock();
					return chart.comp;
				})
			}],
		});
	},

	setClientConfig: function (config) {
		var data = Object.keys(config.cells).map(function (id) {
			var cell = config.cells[id];
			cell.cell_id = id - 0;
			return cell;
		});
		this._cellStore.setData(data);
	},

	_eventListener: function (event) {

		switch (event.type) {
		case 'stats':
			var cells = event.data.cells;
			for (var cell_id in cells) {

				var cell = cells[cell_id];
				for (var stat in cell) {
					var chart = this._field2chart[stat];
					if (!chart) continue;

					var id = cell_id + "-" + stat;
					chart.comp.addSerie(id, {
						title: "Cell " + cell_id + " " + stat,
						values: [{x: new Date() * 1, y: cell[stat]}]
					});
					chart.comp.update();
				}
			}
			break;
		}
	},
});



