/*
 * Copyright (C) 2012-2014 Amarisoft
 *
 * Amarisoft LTE Web interface 2015-10-28
 */

var lteSim = {

	

	ipDefinitionList: [
		{type: 'ping',	name: 'ICMP PING',		msg: 'ping',	fields: {payload_len: 1000, delay: 1, dst_addr: '192.168.3.1'}},
		{type: 'udp',	name: 'UDP',			msg: 'cbr',		fields: {payload_len: 1000, bit_rate: 1000000, dst_addr: '192.168.3.1', direction: 'dl'}},
		{type: 'rtp',	name: 'RTP',			msg: 'cbr',		fields: {payload_len: 1000, bit_rate: 1000000, dst_addr: '192.168.3.1', direction: 'dl'}},
		{type: 'voip',	name: 'VOIP',			msg: 'cbr',		fields: {payload_len: 31, bit_rate: 12400, dst_addr: '192.168.3.1', direction: 'all', mean_talking_duration: 2, vaf: 50}},
		{type: 'flood',	name: 'Flood',			msg: 'flood',	fields: {payload_len: 1000, dst_addr: '192.168.3.1', direction: 'dl'}},
		{type: 'http',	name: 'HTTP transfert',	msg: 'http',	fields: {url: 'http://192.168.3.1:8080/data?size=10000', max_delay: 1}},
	],

	adjustConfig: function (cfg) {

		var def = this.getIpDefinition(cfg.type);
		if (def) {
			lteLogs.merge(cfg, def.fields);
			lteLogs.merge(cfg, {
				duration: 5,
				start_delay: 0,
			});
		}
	},

	getIpDefinition: function (type) {
		for (var i = 0; i < this.ipDefinitionList.length; i++) {
			var def = this.ipDefinitionList[i];
			if (type === def.type)
				return def;
		}
		return null;
	},

	// Random generation
	'random': {
		'gen': function gen(min, max, granularity) {

			if (!granularity) granularity = 1; // Integer by default
			var g = Math.random() * (max - min + granularity);
			return Math.floor(g / granularity) * granularity + min;
		},

		'genFromRange': function genFromRange(range, gran) {
			if (typeof range === "number") range = [range, range];

			if (range.length > 2) gran = range[2];
			return this.gen(range[0], range[1], gran);
		},

		'time': function time(from, to) {
			return this.gen(from, to, 0.001);
		},

		'timeFromRange': function timeFromRange(range) {
			if (typeof range === "number") range = [range, range];

			if (range.length > 2) gran = range[2];
			return this.time(range[0], range[1]);
		},

		'position': function position(dist) {
			var d = this.gen(dist[0], dist[1], 0.1);
			var a = Math.random() * 2 * Math.PI;
			return [Math.floor(d * Math.cos(a)), Math.floor(d * Math.sin(a))];
		},

		'string': function genString(count, base) {
			var str = "";
			for (var i = 0; i < count; i++) {
				str += (Math.floor(Math.random() * base)).toString(base);
			}
			return str;
		},
	},

	setIPAuto: function (ue, cfgList) {
		for (var time = 0; time < Number.POSITIVE_INFINITY; time = range[1]) {
			var range = this._getOnRange(ue, time);
			if (!range) break; // No more range

			this.setIP(ue, cfgList, range);
		}
	},

	genString: function(fmt, str, size) {

		if (fmt.indexOf("$") >= 0) {
			var len = size - fmt.length + 1;
			while (str.length < len) str = "0" + str;
			fmt = fmt.replace("$", str);
		}
		while (fmt.length < size) fmt = "0" + fmt;
		return fmt;
	},

	_setIPMsg: function(msg, cfg) {

		var msg_type = this.getIpDefinition(cfg.type).msg;

		switch (cfg.direction) {
		case 'all':
			var msg1 = lteLogs.clone(msg);
			msg.message = msg_type + '_send';
			msg1.message = msg_type + '_recv';
			return [msg1, msg];
			break;

		case 'dl':
			msg.message = msg_type + '_recv';
			break;

		case 'ul':
			msg.message = msg_type + '_send';
			break;

		default:
			msg.message = msg_type;
			break;
		}

		return [msg];
	},

	setIP: function (ue, cfgList, range) {

		// XXX: handle randomness
		// if (Math.random() > cfg.probability) return;

		if (!range) range = [0, Number.POSITIVE_INFINITY];

		var rangeSize  = range[1] - range[0];
		var rangeStart = range[0];
		var rangeEnd   = range[1];

		this.info("Range:", rangeStart, rangeEnd);

		// Create final script
		cfgList.forEach((function (cfg) {

			// Mandatory part
			var start_time = lteSim.adjustTime(rangeStart + cfg.start_delay);
			var end_time   = lteSim.adjustTime(rangeStart + cfg.start_delay + cfg.duration);

			var msg = {
				ue_id:		ue.ue_id,
				start_time:	start_time,
				end_time:	end_time,
			};
			var script = {
				type:		cfg.type,
				time:		start_time,
				duration:	end_time - start_time,
				ip:			true,
			};

			this.info(ue.imsi, "Add script", start_time.toFixed(3), end_time.toFixed(3));
			if (end_time > rangeEnd) {
				this.warn(ue.imsi, "Script too long for power on period:", end_time, rangeEnd);
				script.overflow = true;
			}

			// Specific part
			switch (cfg.type) {
			case 'udp':
				msg.dst_addr	= cfg.dst_addr;
				msg.payload_len	= lteSim.random.genFromRange(cfg.payload_len, 4);
				msg.bit_rate	= lteSim.random.genFromRange(cfg.bit_rate);
				msg.type = 'udp';
				break;
			case 'rtp':
				msg.dst_addr		= cfg.dst_addr;
				msg.payload_len	= lteSim.random.genFromRange(cfg.payload_len, 4);
				msg.bit_rate		= lteSim.random.genFromRange(cfg.bit_rate);
				msg.type = 'rtp';
				break;
			case 'voip':
				msg.dst_addr				= cfg.dst_addr;
				msg.payload_len				= lteSim.random.genFromRange(cfg.payload_len, 4);
				msg.bit_rate				= lteSim.random.genFromRange(cfg.bit_rate);
				msg.vaf						= lteSim.random.genFromRange(cfg.vaf);
				msg.mean_talking_duration	= lteSim.random.genFromRange(cfg.mean_talking_duration);
				msg.type = 'voip';
				break;
			case "flood":
				msg.dst_addr	= cfg.dst_addr;
				msg.payload_len	= lteSim.random.genFromRange(cfg.payload_len, 4);
				break;
			case "ping":
				msg.dst_addr		= cfg.dst_addr;
				msg.payload_len	= lteSim.random.genFromRange(cfg.payload_len, 4);
				msg.delay		= cfg.delay;
				msg.id			= cfg.id || lteSim.random.gen(1, 65535);
				break;
			case "http":
				msg.url			= cfg.url;
				msg.max_delay	= cfg.max_delay;
				break;
			}
			script.msg = this._setIPMsg(msg, cfg);
			script.name = cfg.name || this.getIpDefinition(cfg.type).name;
			script.category = 'UE #' + ue.ue_id;
			ue.scripts.push(script);
		}).bind(this));
	},

	adjustTime: function(t) {
		return Math.round(t * 1000) / 1000;
	},

	_getOnRange: function _getOnRange(ue, time) {

		for (var i = 0; i < ue.scripts.length; i++) {
			var script = ue.scripts[i];
			if (script.type !== 'power') continue;

			if (time < script.time || (time >= script.time && time < script.time + script.duration))
				return [script.time, script.time + script.duration];
		}
		return null;
	},

	// On/off
	setOnOff: function (ueList, cfg) {
		// Merge default properties
		cfg = lteLogs.merge(lteLogs.clone(cfg), {
			duration:	[20, 20],
			on_time:	[10, 10], // On between 10 and 15s
			off_time:	[5, 10],
			caps:		2,
			on_max:		10,
			noise:		false,
		});

		var ue_count	= ueList.length;
		var min_delay	= 1 / cfg.caps;

		// Each UE:
		var ue_state = ueList.map(function (ue, id) { return {
			on_time:	0,
			off_time:	Number.NEGATIVE_INFINITY,
			id:			id,
			events:		[]
		};});

		// Add and remove
		var duration = lteSim.random.genFromRange(cfg.duration);
		this.info("Generate power script for " + duration + "s");
		for (time = 0; time < duration;) {

			// Get powered on UE
			var on_list = ue_state.filter(function (ue) { return time < ue.off_time; });

			var available_list = ue_state.filter(function (ue) { return time >= ue.on_time; });

			this.info("[" + time.toFixed(2) + "] Check, on = " + on_list.length + ", available = " + available_list.length);
			if (available_list.length > 0 && on_list.length < cfg.on_max) {
				// Select off UE
				var id = lteSim.random.gen(0, available_list.length - 1);
				var ue = available_list[id];

				// Power on time
				var start = time;
				if (cfg.noise)
					start += lteSim.random.time(-min_delay / 2, min_delay / 2); // Add noise

				// Power off time
				var end = start + lteSim.random.timeFromRange(cfg.on_time);
				if (cfg.noise)
					end += lteSim.random.time(-min_delay / 2, min_delay / 2); // Add noise

				// Add power on/off event
				if (end <= duration) {
					if (start < 0) start = 0; // In case of noise

					ue.events.push({
						id:		id,
						start:	lteSim.adjustTime(start),
						end:	lteSim.adjustTime(end)
					});
					this.info("[" + time.toFixed(2) + "] Add " + ueList[id] + ", from " + start.toFixed(3) + " to " + end.toFixed(3));
				}

				// Next power off/on events
				ue.off_time = end + min_delay;
				ue.on_time  = end + lteSim.random.timeFromRange(cfg.off_time);

				// Update
				time += min_delay;

			} else {
				this.info("[" + time.toFixed(2) + "] No space left");

				// No slot available, look for next time
				var next_time = Number.POSITIVE_INFINITY;
				ue_state.forEach(function (ue) {
					if (ue.off_time > time)
						next_time = Math.min(next_time, ue.off_time);
					if (ue.on_time > time)
						next_time = Math.min(next_time, ue.on_time);
				});
				time = next_time;
			}
		}

		// Add scripts
		ue_state.forEach(function (ue) {
			ue.events.forEach(function (event) {
				var ue_id = ueList[ue.id].ue_id;
				ueList[ue.id].scripts.push({
					type:		'power',
					name:		'Power on/off',
					category:	'UE #' + ue_id,
					time:		event.start,
					duration:	event.end - event.start,
					msg:		[{
						message:	'power_on',
						ue_id:		ue_id,
						start_time: event.start
					}, {
						message:	'power_off',
						ue_id:		ue_id,
						start_time: event.end
					}]
				});
			});
		});
	},

	/*
	 * sim: config generated by lte.sim.window
	 * ue_ids: in cas of !sim.ue.enabled, apply scripts to this list of UEs
	 */
	generateScripts: function (sim, ue_ids) {

		// Create UE ?
		if (sim.ue.enabled) {
			var ueList = [];
			for (var i = 0; i < sim.ue.count; i++) {
				var ue = {
					"ue_id":		(i + 2),
					"imsi":			lteSim.genString(sim.ue.imsi, i.toString(), 13),
					"imeisv":		lteSim.genString("01234567$d02", i.toString(), 16),
					"K":			lteSim.genString(sim.ue.K, i.toString(16), 32),
					"scripts":		[],
					"ue_category":	sim.ue.category
				}
				if (sim.ue.tun_enabled)
					ue.tun_setup_script = sim.ue.tun_setup_script;
				if (ue.ue_category > 1) {
					ue.forced_ri = 2;
					ue.forced_cqi = 15;
					ue.pdsch_max_its = 1;
				}

				ueList.push(ue);
			}

		// Use UE
		} else {
			var ueList = ue_ids.map((function (ue_id) {
				return {
					"ue_id": ue_id,
					"scripts":	[],
				};
			}).bind(this));
		}

		// Power on/off
		if (sim.power.enabled) {
			this.setOnOff(ueList, sim.power);
			var ipFunc = "setIPAuto";
		} else {
			var ipFunc = "setIP";
		}

		// IP
		ueList.forEach((function (ue) {
			this[ipFunc](ue, sim.scripts);
		}).bind(this));

		// Update ue_id and create full script list
		var scriptList = [];
		var duration = 0;
		ueList.forEach((function (ue) {
			ue.scripts.forEach(function (script) {
				scriptList.push(script);
				duration = Math.max(duration, script.time + script.duration);
			});
		}).bind(this));

		// Sort scripts
		scriptList.sort(function (a, b) { return a.time - b.time; });

		return {
			list:		ueList,
			scripts:	scriptList,
			duration:	duration
		};
	},

	fixScripts: function (scripts) {
		var fix = false;
		for (var i in scripts) {
			var script = scripts[i];
			switch (script.type) {
			case 'cbr_send':
				script.type = 'udp';
				script.direction = 'ul';
				fix = true;
				break;
			case 'cbr_recv':
				script.type = 'udp';
				script.direction = 'dl';
				fix = true;
				break;
			case 'flood_send':
				script.type = 'flood';
				script.direction = 'ul';
				fix = true;
				break;
			case 'flood_recv':
				script.type = 'flood';
				script.direction = 'dl';
				fix = true;
				break;
			}
		}
		return fix;
	}
};

lteLogs.setLogger("SIM", lteSim);


Ext.define("lte.sim.window", {

	extend: 'Ext.window.Window',
	layout: 'fit',
	width: 1000,
	height: 500,

	constructor: function (config) {

		var ref = this._simRef   = config.simRef;
		this._simStore = config.simStore;

		lteLogs.setLogger("SIM", this);

		// Init
		if (ref) {
			this._sim = {
				scripts:	lteLogs.clone(ref.data.scripts),
				name:		ref.data.name,
				ue:			lteLogs.clone(ref.data.ue),
				power:		lteLogs.clone(ref.data.power)
			};
		} else {
			this._sim = {
				name:		"",
				scripts:	[],
				ue:			{},
				power:		{},
			};
		}

		// Default
		lteLogs.merge(this._sim.ue, {
			count: 1,
			category: 3,
			imsi: "001010123456789",
			K: "00112233445566778899aabbccddeeff",
			tun_enabled: false,
			tun_setup_script: "ue-ifup",
			enabled: false
		});
		lteLogs.merge(this._sim.power, {
			caps:		10,
			on_max:		10,
			on_time:	10,
			off_time:	10,
			duration:	30,
			enabled:	false
		});
		this._sim.scripts.forEach(function (script) {
			lteSim.adjustConfig(script);
		});

		this.callParent(arguments);
	},

	initComponent: function () {
		this.callParent(arguments);

		// Script form
		this._scriptForm = Ext.create('Ext.form.Panel', {
			bodyPadding: 5,
			width: '100%',
			defaults: {
				width: '100%',
			},
			items: [],
			autoScroll: true,
			listeners: {
				scope: this,
				validitychange: function(form, valid, eOpts) {
					scriptListGrid.setDisabled(!valid);
					addSimButton.setDisabled(!valid);
				}
			},
		});

		// Script list
		var addScriptButton = Ext.create('Ext.Button', {
			iconCls: 'icon-plus',
			scope: this,
			tooltip: lteLogs.tooltip("Add a script"),
			handler: this._newScript.bind(this),
		});
		var delScriptButton = Ext.create('Ext.Button', {
			iconCls: 'icon-moins',
			scope: this,
			disabled: true,
			tooltip: lteLogs.tooltip("Remove script"),
			handler: function () {
				var index = this._sim.scripts.indexOf(this._selectedScript);
				this._sim.scripts.splice(index, 1);
				this._updateScriptList();
			},
		});
		var scriptListStore = this._scriptListStore = Ext.create('Ext.data.Store', {
			fields: ["type"],
			data: this._sim.scripts
		});
		var scriptListGrid = this._scriptListGrid = Ext.create('Ext.grid.Panel', {
			bbar: Ext.create('Ext.toolbar.Toolbar', {items: [addScriptButton, delScriptButton]}),
			store: scriptListStore,
			width: '100%',
			columns: [{
				text: "Name",
				dataIndex: "name",
				flex: 1
			}],
			listeners: {
				scope: this,
				selectionchange: function(view, selected, eOpts) {
					this._updateScript();
					this._setScript(selected.length > 0 ? selected[0].data : null);
					delScriptButton.setDisabled(!selected.length);
				},
			}
		});

		// Global params
		this._globalForm = Ext.create('Ext.form.Panel', {
			bodyPadding: 5,
			items: [{
				// Create UEs
				xtype:'fieldset',
				title: 'Create UE',
				layout: 'anchor',
				checkboxName: 'ue.enabled',
				checkboxToggle: true,
				collapsed: !this._sim.ue.enabled,
				defaults: {
					xtype: 'numberfield',
					width: '97%',
					labelWidth: 60
				},
				items: [{
					value: this._sim.ue.count,
					fieldLabel: 'Count',
					maxValue: 5000,
					minValue: 1,
					name: 'ue.count',
				}, {
					value: this._sim.ue.imsi,
					fieldLabel: 'IMSI',
					xtype: 'textfield',
					name: 'ue.imsi',
					allowBlank: false,
					minLength: 1,
					maxLength: 16,
					validator: function(val) {
						if (!val.match(/^[\d\$]+/))
							return lteLogs.tooltip("Only igits or $ for index allowed");
						return true;
					}
				}, {
					value: this._sim.ue.category,
					fieldLabel: 'Category',
					name: 'ue.category',
					maxValue: 4,
					minValue: 1,
				}, {
					value: this._sim.ue.K,
					fieldLabel: 'K',
					xtype: 'textfield',
					name: 'ue.K',
					minLength: 1,
					allowBlank: false,
					validator: function(val) {
						if ((val.length < 32 && val.indexOf("$") < 0) ||
							!val.match(/^[\d\$abcdefABCDEF]+$/))
							return lteLogs.tooltip("Only hexadecimal chars or $ for index allowed");
						return true;
					}
				}, {
					xtype: 'fieldcontainer',
					fieldLabel: 'Linux IP',
					layout: 'hbox',
					items: [{
						xtype: 'checkboxfield',
						name: 'ue.tun_enabled',
						checked: this._sim.ue.tun_enabled,
						inputValue: true,
						listeners: {
							scope: this,
							change: function (field, checked) {
								this._globalForm.getForm().findField("ue.tun_setup_script").setDisabled(!checked);
							}
						}
					}, {
						value: this._sim.ue.tun_setup_script,
						xtype: 'textfield',
						name: 'ue.tun_setup_script',
						disabled: !this._sim.ue.tun_enabled,
						tooltip: 'Create TUN interface',
					}]
				}]
			}, {
				// Power
				xtype:'fieldset',
				title: 'Power on/off',
				layout: 'anchor',
				checkboxToggle: true,
				checkboxName: 'power.enabled',
				collapsed: !this._sim.power.enabled,
				defaults: {
					xtype: 'numberfield',
					width: '97%',
				},
				items: [{
					fieldLabel: 'Duration',
					minValue: 10,
					maxValue: 3600 * 4,
					step: 1,
					allowDecimals: true,
					value: this._sim.power.duration,
					name: "power.duration"
				}, {
					fieldLabel: 'Connection attempt/s',
					minValue: 1,
					maxValue: 200,
					value: this._sim.power.caps,
					name: "power.caps",
				}, {
					fieldLabel: 'Max simult. connected UE',
					minValue: 1,
					maxValue: 500,
					allowDecimals: true,
					value: this._sim.power.on_max,
					name: "power.on_max"
				}, {
					fieldLabel: 'Power on duration',
					minValue: 1,
					maxValue: 600,
					allowDecimals: true,
					value: this._sim.power.on_time,
					name: "power.on_time"
				}, {
					fieldLabel: 'Power off duration',
					minValue: 1,
					maxValue: 600,
					allowDecimals: true,
					value: this._sim.power.off_time,
					name: "power.off_time"
				}],
			}],
			autoScroll: true,
		});

		// Top menu
		var addSimButton = Ext.create('Ext.Button', {
			text: this._simRef ? "Modify" : "Add",
			scope: this,
			handler: function() {
				this._addSim(addSimName.getValue());
			}
		});
		var addSimName = Ext.create("Ext.form.field.Text", {
			value: this._sim.name,
			width: 200,
			allowBlank: false,
		});

		this.add({
			layout: "border",
			tbar: {
				bodyPadding: 5,
				items: [addSimButton, addSimName]
			},
			items: [{
				region: "center",
				layout: "fit",
				items: [scriptListGrid],
			}, {
				region: "east",
				layout: "fit",
				items: [this._scriptForm],
				width: 400,
			}, {
				region: 'west',
				layout: "fit",
				width: 370,
				items: [this._globalForm],
			}]
		});
	},

	_addSim: function (name) {

		if (!name) {
			Ext.Msg.alert("Error", "Name is empty");
			return;
		}
		var globalValues = this._globalForm.getForm().getFieldValues();

		if (!this._sim.scripts.length &&
			!globalValues['power.enabled'] &&
			!globalValues['ue.enabled']) {
			Ext.Msg.alert("Error", "Simulation empty");
			return;
		}

		this._updateScript();

		// Update Purge ID
		this._sim.scripts.forEach(function (item) { delete item.id; });

		// Set global vars
		this._sim.name = name;
		for (var i in globalValues) {
			var name = i.split(".");
			if (name.length > 1)
				this._sim[name[0]][name[1]] = globalValues[i];
		}

		if (!this._simRef) {
			this._simStore.add(this._sim);
		} else {
			for (var i in this._sim) {
				this._simRef.set(i, this._sim[i]);
			}
		}
		this._simStore.sync();
		this.close();
	},

	_updateScript: function() {

		var script = this._selectedScript;
		if (!script) return;

		if (this._scriptForm.getForm().isValid()) {
			lteLogs.merge(script, this._scriptForm.getForm().getFieldValues(), true);
			this._scriptListGrid.getView().refresh();
		} else {
			Ext.Msg.alert("Error", "Invalid configuration");
		}
	},

	_newScript: function () {
		var addScriptStore = Ext.create('Ext.data.Store', {
			fields: ["name", "type", "fields"],
			data: lteSim.ipDefinitionList.map((function (def) { return def; }).bind(this))
		});
		var addScriptCombo = Ext.create('Ext.form.field.ComboBox', {
			store: addScriptStore,
			queryMode: 'local',
			valueField: 'type',
			displayField: 'name',
			name: 'type',
			fieldLabel: 'Type',
			allowBlank: false,
			width: '100%',
			listeners: {
				scope: this,
				change: function(me, newValue, oldValue, eOpts) {
					console.log(newValue);

					var length = this._sim.scripts.length;
					for (var i = 0, max = length; i < length; i++) {
						var m = this._sim.scripts[i].name.match(/#(\d+)$/);
						if (m && m.length > 0)
							max = Math.max(max, m[1] - 0);
					}
					addScriptName.setValue(lteSim.getIpDefinition(newValue).name + " #" + max);
				}
			}
		});
		var addScriptName = Ext.create("Ext.form.field.Text", {
			xtype: 'textfield',
			value: '',
			allowBlank: false,
			name: 'name',
			fieldLabel: 'Name',
			width: '100%',
		});
		var addScriptForm = Ext.create('Ext.form.Panel', {
			bodyPadding: 5,
			items: [addScriptCombo, addScriptName],
			autoScroll: true,
			buttons: [{
				text: "Add script",
				scope: this,
				handler: function() {
					if (addScriptForm.isValid()) {
						var script = addScriptForm.getForm().getFieldValues();

						console.log(script);
						this._sim.scripts.push(script);
						lteSim.adjustConfig(script);
						this._updateScriptList();
						window.close();
					}
				}
			}]
		});

		var window = Ext.create('Ext.window.Window', {
			title: 'Add script',
			height: 150,
			width: 400,
			layout: 'fit',
			modal: true,
			resizeable: false,
			items: addScriptForm,
		});
		window.show();
	},

	_updateScriptList: function () {
		this._scriptListStore.loadData(this._sim.scripts);
	},

	_setScript: function (script) {

		var form = this._scriptForm;
		form.removeAll();

		this._selectedScript = script;
		if (!script) return;

		this.info("Set script", script);

		var def = lteSim.getIpDefinition(script.type);

		var items = [{
			xtype: 'textfield',
			name: 'type',
			value: def.name,
			fieldLabel: 'Type',
			editable: false,
			disabled: true,
		}, {
			xtype: 'textfield',
			name: 'name',
			value: script.name,
			fieldLabel: 'Name',
			allowBlank: false,
		}, {
			xtype: 'numberfield',
			name: 'start_delay',
			fieldLabel: 'Start delay',
			value: script.start_delay,
			allowDecimals: true,
			decimalPrecision: 3,
			minValue: 0,
			step: 0.5,
			maxValue: 300,
		}, {
			xtype: 'numberfield',
			name: 'duration',
			fieldLabel: 'Duration',
			maxValue: 3600,
			value: script.duration,
			allowDecimals: true,
			decimalPrecision: 3,
			minValue: 0.5,
			step: 0.5,
		}];

		Object.keys(def.fields).forEach((function (field) {
			switch (field) {
			case "url":
				var item = {
					xtype: 'textfield',
					value: script.url,
					fieldLabel: 'URL',
					allowBlank: false,
					validator: function(val) {
						if (val.match(/^http:\/\/[\w\d]+\.\w+/))
							return true;
						return lteLogs.tooltip("URL required");
					}
				};
				break;

			case 'payload_len':
				var item = {
					xtype: 'numberfield',
					fieldLabel: 'Payload size',
					value: script.payload_len,
					step: 100,
					maxValue: 1500,
					minValue: 12,
				};
				break;

			case 'bit_rate':
				var item = {
					xtype: 'numberfield',
					fieldLabel: 'Bitrate ',
					value: script.bit_rate,
					maxValue: 150000000,
					minValue: 1000,
					step: 100000,
				};
				break;

			case 'delay':
				var item = {
					xtype: 'numberfield',
					fieldLabel: 'Delay',
					maxValue: 60,
					value: script.delay,
					allowDecimals: true,
					decimalPrecision: 1,
					minValue: 0.5,
					step: 0.1,
				};
				break;

			case 'max_delay':
				var item = {
					xtype: 'numberfield',
					fieldLabel: 'Maximum delay',
					maxValue: 60,
					value: script.max_delay,
					allowDecimals: true,
					decimalPrecision: 1,
					minValue: 0,
					step: 0.1,
				};
				break;

			case 'dst_addr':
				var item = {
					xtype: 'textfield',
					fieldLabel: 'Destination',
					value: script.dst_addr,
					validator: function(val) {
						if (val.match(/^\d+\.\d+\.\d+\.\d+$/))
							return true;
						return lteLogs.tooltip("Address IP required");
					}
				};
				break;

			case 'direction':
				var item = {
					xtype: 'radiogroup',
					fieldLabel: 'Direction',
					columns: 3,
					items: [
						{ boxLabel: 'DL/UL', name: 'direction', inputValue: 'all', checked: script.direction === 'all' },
						{ boxLabel: 'DL', name: 'direction', inputValue: 'dl', checked: script.direction === 'dl' },
						{ boxLabel: 'UL', name: 'direction', inputValue: 'ul', checked: script.direction === 'ul' },
					]
				};
				break;

			case 'mean_talking_duration':
				var item = {
					xtype: 'numberfield',
					fieldLabel: 'Mean talking duration',
					maxValue: 60,
					value: script.mean_talking_duration,
					allowDecimals: true,
					decimalPrecision: 1,
					minValue: 1,
					step: 0.1,
				};
				break;

			case 'vaf':
				var item = {
					xtype: 'numberfield',
					fieldLabel: 'Voice activity factor %',
					maxValue: 100,
					value: script.vaf,
					allowDecimals: false,
					//decimalPrecision: 0,
					minValue: 1,
					step: 1,
				};
				break;

			default:
				return;
			}
			item.name = field;
			items.push(item);
		}).bind(this));

		form.add(items);
	}
});



