/*
 * Copyright (C) 2012-2015 Amarisoft
 *
 * Amarisoft LTE Web interface 2015-10-28
 * Icons from http://icocentre.com/
 */

Ext.define('4GLogs.data.Log', {
	extend: 'Ext.data.Model',
	fields: [
		{name: 'log'},
		{name: 'id'},
	]
});

Ext.define('4GLogs.data.Client', {
	extend: 'Ext.data.TreeModel',
	fields: [
		{name: 'name'},
		{name: 'client', type: 'auto'},
		{name: 'persistent', type: 'boolean'}
	],
});


Ext.define('4GLogs.view.Viewport', {
	extend: 'Ext.container.Viewport',
	layout: 'fit'
});

var layerConfig = {
	'PHY':  {color: '#808080', dir: 0x1},
	'MAC':  {color: '#0080FF', dir: 0x1},
	'RLC':  {color: '#FFFF80', dir: 0x1},
	'PDCP': {color: '#A0A0A0', dir: 0x2},
	'RRC':  {color: '#00FF80', dir: 0x1},
	'NAS':  {color: '#80FFC0', dir: 0x3},
	'IP':   {color: '#E0E0E0', dir: 0x3},
	'S1AP': {color: '#80FF00', dir: 0x2},
	'GTPU': {color: '#FF80FF', dir: 0x2},
	'X2AP': {color: '#FF8000', dir: 0x2},
	'SIP':  {color: '#C080FF', dir: 0x1},
	'IMS':  {color: '#C0FF80', dir: 0x1},
	'COM':  {color: '#C000FF', dir: 0x1},
};



Ext.application({
	name: '4GLogs',
	
	launch: function() {

		this.viewport = this.getView('Viewport').create();

		Ext.define('LogProxy', {
			extend: "Ext.data.proxy.Proxy",

			isSynchronous: true,

			scope: this,
			read: function(operation) {

				var start = operation.getStart();
				var limit = operation.getLimit();

				var length = gridLogs.length;
				var end    = Math.min(start + limit, length);

				// Create model on the fly !
				var records = [];
				for (var i = start; i < end; i++) {
					var log = gridLogs[i];
					records.push(Ext.create("4GLogs.data.Log", {log: log, id: log.id}));
				}

				lteLogs.debug("Read", start, end, length);

				operation.setResultSet(new Ext.data.ResultSet({
					records: records,
					count:   records.length,
					total:   length,
					loaded:  true,
				}));
				operation.setSuccessful(true);
			},
		});

		var logsStore = Ext.create('Ext.data.Store', {
			model: '4GLogs.data.Log',
			proxy: Ext.create("LogProxy", {}),
			buffered: true,
			pageSize: 200,
		});

		// Log filters
		var createSrcFilter = Ext.Function.bind(function(label, type) {
			return Ext.create('Ext.button.Button', {
				pressed: true,
				width: 32,
				tooltip: lteLogs.tooltip("Enable/Disable " + label),
				iconCls: "icon-" + type,
				enableToggle: true,
				listeners: {
					scope: this,
					click: function(filter, e, eOpts) {
						lteLogs.updateFilter();
					}
				}
			});
		}, this);

		var createListFilter = function (label, type, data) {
			return Ext.create('Ext.form.field.ComboBox', {
				fieldLabel: label,
				queryMode: 'local',
				valueField: 'value',
				displayField: 'text',
				multiSelect: true,
				width: 140,
				labelWidth: 50,
				labelAlign: 'right',
				labelSeparator: '',
				store: Ext.create('Ext.data.Store', {
					fields: ['value', 'text'],
					data: data
				}),
				tpl: Ext.create('Ext.XTemplate',
					'<tpl for=".">',
					'{value:this.valueRenderer}</div>',
					'</tpl>', {
						valueRenderer: function (v) {
							var format = filterValueFormater(type, v);
							return '<div class="x-boundlist-item" style="' + format.style + '">' + format.display + '</div>';
						}
					}),
				listeners: {
					scope: this,
					change: function(combo, newValue, oldValue, eOpts) {
						if (!filterData.locked) {
							filterData[type] = newValue;
							lteLogs.updateFilter();
						}
					},
					collapse: function () {
						gridLocker.unlock(label);
					},
					expand: function () {
						gridLocker.lock(label);
					}
				}
			});
		};

		var filterComponents = lteLogs.filterComponents = {
			"time": Ext.create("Ext.form.field.Text", {
				fieldLabel: 'Time origin',
				labelWidth: 50,
				value: "0:00:00.000",
				width: 165,
				validateOnChange: true,
				validator: function (value) {
					value = value.match(/^(((\d+):)?(\d+):)?(\d+)(\.(\d+))?$/);
					if (value) {
						var h = value[3] >> 0;
						var m = value[4] >> 0;
						var s = value[5] >> 0;
						var ms = value[7] || "0";
						ms = ((ms - 0) * Math.pow(10, 3 - ms.length)) >> 0;
						filterData.timeOrigin = h * 3600000 + m * 60000 + s * 1000 + ms;
						lteLogs.refreshView();
						return true;
					}
					return false;
				},
				listeners: {
					scope: this,
					blur: function (filter, event, eOpts) {
						filter.setValue(lteLogs.ts2time(filterData.timeOrigin));
					},
				}
			}),
			"UE":  createSrcFilter('UE', "ue"),
			"ENB": createSrcFilter('ENB', "air"),
			"MME":  createSrcFilter('MME', "server"),
			"rnti": createListFilter("RNTI", "rnti", []),
			"info": createListFilter("Info", "info", []),
			"layer": createListFilter("Layer", "layer", Object.keys(layerConfig).map(function (l) { return {value: l, text: l}; })),
			"level": createListFilter("Level", "level", lteLogs.mapFilter(lteLogs.levels, function (l, i) { if (i > 0) return {value: i, text: l}; })),
			/*"msg": Ext.create('Ext.form.field.Text', {
				fieldLabel: 'Message',
				labelWidth: 50,
				labelAlign: 'right',
				labelSeparator: '',
				listeners: {
					scope: this,
					change: function(combo, newValue, oldValue, eOpts) {
						filterData.msg = newValue;
						lteLogs.updateFilter();
					},
				}
			}),*/
		};

		var filterData = {timeOrigin: 0, rnti: [], info: [], layer: [], level: []};
		var filterLog = function(log) {

			var f = filterData;

			// Filter source
			var c = f[log.src];
			if (c === false) {
				log.filtered = true;
				return true;
			}

			// Filter errors
			var e = f.error;
			if (e && (log.level !== 1)) {
				log.filtered = true;
				return true;
			}

			for (var i in filterComponentsData) {
				var data = f[i];
				if (data.length && data.indexOf(log[i]) < 0) {
					log.filtered = true;
					return true;
				}
			}

			// Filter message
			var msg = f.msg;
			if (msg && !log.msg.match(msg)) {
				log.filtered = true;
				return true;
			}

			log.filtered = false;
			return false;
		};

		this.clearFiltersButton = Ext.create('Ext.Button', {
			text: 'Clear Filters',
			scope: this,
			handler: function() {
				lteLogs.lockFilter(true);
				filterComponents.time.setValue("00:00:00.000");
				filterComponents.UE.setPressed(true);
				filterComponents.ENB.setPressed(true);
				filterComponents.MME.setPressed(true);
				for (var i in filterComponentsData) {
					filterComponents[i].clearValue();
				}
				//filterComponents.msg.setValue('');
				lteLogs.lockFilter(false);
			}
		});

		// Log navigation
		this.gotoLogOffsetByParam = function (param, n) {

			var rec = logsGrid.getSelection()[0];
			if (rec) {
				gotoLogByParam(param, rec.get('log')[param], n);
			}
		}

		var gotoLogByParam = function (param, value, n) {
			var rec  = logsGrid.getSelection()[0];
			var index = rec ? logsStore.indexOf(rec) + n : 0;
			while (index >= 0) {
				var log = gridLogs[index];
				if (!log)
					break;

				if (log[param] === value) {
					lteLogs.selectLog(log);
					break;
				}
				index += n;
			}
		};
		this.gotoNextLogByLayer = Ext.Function.bind(this.gotoLogOffsetByParam, this, ["layer", 1]);
		this.gotoPrevLogByLayer = Ext.Function.bind(this.gotoLogOffsetByParam, this, ["layer", -1]);


		this.nextTypeButton = Ext.create('Ext.Button', {
			iconCls: 'icon-right',
			tooltip: lteLogs.tooltip('Goto next log (n)'),
			handler: this.gotoNextLogByLayer
		});
		this.prevTypeButton = Ext.create('Ext.Button', {
			tooltip: lteLogs.tooltip('Goto previous log (b)'),
			iconCls: 'icon-left',
			handler: this.gotoPrevLogByLayer
		});

		// Play/Pause
		var togglePlayPause = function () {
			logState.newLogsPause = !logState.newLogsPause;
			if (logState.newLogsPause) {
				pauseButton.setIconCls("icon-play");
			} else {
				pauseButton.setIconCls("icon-pause");
				logsUpdater.update(true);
			}
		};
		var pauseButton = Ext.create('Ext.Button', {
			iconCls: 'icon-pause',
			tooltip: lteLogs.tooltip('Play/Pause (p)'),
			listeners: {
				scope: this,
				click: togglePlayPause,
			}
		});

		this.showChartButton = Ext.create('Ext.Button', {
			text: 'Analytics',
			scope: this,
			tooltip: lteLogs.tooltip('Show PHY layer charts'),
			iconCls: 'icon-chart',
			handler: function() {
				var win = lteStats.createWindow(curLogs, false);
				win.show();
			}
		});

		errorInfoButton = Ext.create('Ext.Button', {
			scope: this,
			hidden: true,
			iconCls: 'icon-error',
			tooltip: lteLogs.tooltip('Goto next error'),
			handler: function() {
				gotoLogByParam('level', 1, 1);
			}
		});

		warnInfoButton = Ext.create('Ext.Button', {
			scope: this,
			hidden: true,
			iconCls: 'icon-warn',
			tooltip: lteLogs.tooltip('Goto next warning'),
			handler: function() {
				gotoLogByParam('level', 2, 1);
			}
		});

		// Search
		var searchRegexp  = null;
		var searchHighlight = function(text) {
			if (!text) return text;

			if (searchRegexp) {
				text = text.replace(searchRegexp, '<span style="background-color: #C0FFC0; font-weight: bold;">$1</span>');
			}
			return text;
		}
		this.gotoSearch = function (n) {
			var rec   = logsGrid.getSelection()[0];
			var index = rec ? logsStore.indexOf(rec) : -1;

			for (;;) {
				index += n;
				var log = gridLogs[index];
				if (!log)
					break;

				if (log.msg.match(searchRegexp))
					break;

				var rnti = log.rnti;
				if (rnti && rnti.toString(16).match(searchRegexp))
					break;

				if (log.info) {
					var info = lteLogs.id2string(log.info);
					if (info && info.match(searchRegexp))
						break;
				}

				if (log.data) {
					for (var i = 0, length = log.data.length; i < length; i++) {
						if (log.data[i].match(searchRegexp)) {
							break;
						}
					}
					if (i < length)
						break;
				}
			}
			if (log)
				lteLogs.selectLog(log);
		};
		this.gotoNextSearch = Ext.Function.bind(this.gotoSearch, this, [1]);
		this.gotoPrevSearch = Ext.Function.bind(this.gotoSearch, this, [-1]);
		this.nextSearchButton = Ext.create('Ext.Button', {
			iconCls: 'icon-right',
			tooltip: lteLogs.tooltip('Goto next'),
			disabled: true,
			handler: this.gotoNextSearch
		});
		this.prevSearchButton = Ext.create('Ext.Button', {
			tooltip: lteLogs.tooltip('Goto previous'),
			iconCls: 'icon-left',
			disabled: true,
			handler: this.gotoPrevSearch
		});
		this.searchInput = Ext.create('Ext.form.field.Text', {
			fieldLabel: 'Search',
			labelWidth: 50,
			labelAlign: 'right',
			labelSeparator: '',
			triggers: {
				foo: {
					cls: 'icon-search',
					handler: this.gotoNextSearch
				}
            },
			listeners: {
				scope: this,
				change: function(combo, newValue, oldValue, eOpts) {
					if (newValue) {
						this.nextSearchButton.setDisabled(false);
						this.prevSearchButton.setDisabled(false);
						var re = newValue.match(/^\/(.+)\/([gi]*)$/);
						if (re) {
							searchRegexp = new RegExp("(" + info[1] + ")", info[2]);
						} else {
							searchRegexp  = new RegExp("(" + newValue + ")", "gi");
						}
					} else {
						this.nextSearchButton.setDisabled(true);
						this.prevSearchButton.setDisabled(true);
						searchRegexp = null;
					}

					// XXX: disable buttons if empty
					lteLogs.refreshView();
					infoPanelUpdate();
				},
			}
		});

		new Ext.util.KeyMap({
			target: Ext.getBody(),
			key: "n", //Ext.event.Event.RIGHT,
			fn: this.gotoNextLogByLayer,
			ignoreInputFields: true
		});
		new Ext.util.KeyMap({
			target: Ext.getBody(),
			key: "b", //Ext.event.Event.LEFT,
			fn: this.gotoPrevLogByLayer,
			ignoreInputFields: true
		});
		new Ext.util.KeyMap({
			target: Ext.getBody(),
			key: "p", //Ext.event.Event.SPACE,
			fn: togglePlayPause,
			ignoreInputFields: true
		});


		this.filtersToolbar = Ext.create('Ext.toolbar.Toolbar', {
			items: [
				filterComponents.time,
				filterComponents.UE, filterComponents.ENB, filterComponents.MME,
				filterComponents.level, filterComponents.layer, filterComponents.rnti, filterComponents.info,
				'->',
				this.clearFiltersButton]
		});
		this.logToolbar = Ext.create('Ext.toolbar.Toolbar', {
			items: [
				pauseButton,
				'|',
				this.prevTypeButton, this.nextTypeButton, this.showLogButton, errorInfoButton, warnInfoButton,
				'|',
				this.searchInput, this.prevSearchButton, this.nextSearchButton,
				'|',
				this.showChartButton,
				]
		});
		

		// Log grid cell renderers
		var dirRenderer = function(log, place, metaData) {

			logRenderer(log, metaData);

			var dir = log.dir;
			if (!dir) return "&nbsp";

			switch (log.src) {
			case 'MME':
				var img = place === 1;
				break;

			case 'UE':
				var img = place === 0;
				break;

			case 'ENB':
				var img = layerConfig[log.layer].dir & (1 << place);
				break;

			case 'IMS':
				var img = place === 2;
				break;
			}
			if (img) {
				img = dir === lteLogs.DIR_UL ? "right" : "left";
				metaData.style += "padding: 5px 1px 4px 1px;";

				metaData.style += "background-image:url(resources/images/" + img + ".png); background-repeat:no-repeat; background-position:center center; background-size: 6px 10px;";

				return '&nbsp;';
				return "<img src='resources/images/" + img + ".png' height=10>";
			}
			return "&nbsp;";
		};

		var srcRenderer = function(log, src, metaData) {

			logRenderer(log, metaData);
			if (log.src !== src)
				return '&nbsp;';

			metaData.style = "background: " + layerConfig[log.layer].color + '; text-align: center;';

			if (_SELECTED_LOG === log)
				metaData.style += " border-width: 1px 0px; border-style: solid; border-color: #A0A0FF;";

			return log.layer;
		};

		var logRenderer = function (log, metaData) {

			var info = [log.client.getName()];

			// Tooltip
			var data = log.data;
			switch (log.layer) {
				case "PHY":
					if (log.frame)
						info.push("Frame:&nbsp;" + log.frame);
					info.push("Cell:&nbsp;" + log.cell);
					break;
				default:
					break;
			}
			if (info)
				metaData.tdAttr = 'data-qtip="' + info.join("<br/>") + '"';

			// Background
			if (_SELECTED_LOG === log) {
				metaData.style = "background-color: #C0C0FF; font-weight: bold; border-width: 1px 0px; border-style: solid; border-color: #A0A0FF;";

			} else if (data && _SELECTED_DATA) {
				var same = data === _SELECTED_DATA;
				if (!same && data.length === _SELECTED_DATA.length) {
					for (var i = 0; i < data.length; i++) {
						if (data[i] !== _SELECTED_DATA[i])
							break;
					}
					same = i === data.length;
				}
				if (same)
					metaData.style = "background-color: #E0E0FF; font-weight: bold;";
			}
		};

		lteLogs.gridColumnsUpdate = function () {

			var found = {UE: false, ENB: false, MME: false, IMS: false};

			logState.clientList.forEach(function (c) {
				switch (c.getState()) {
				case 'start':
				case 'connected':
					found[c.getModel()] = true;
				}
			});

			var columns = logsGrid.columns;
			columns[2].setVisible(found.UE);
			columns[3].setVisible(found.UE || found.ENB);
			columns[4].setVisible(found.ENB);
			columns[5].setVisible(found.ENB || found.MME);
			columns[6].setVisible(found.MME);
			columns[7].setVisible(found.MME || found.IMS);
			columns[8].setVisible(found.IMS);

		};

		var _SELECTED_LOG = null;
		var _SELECTED_DATA = null;
		var logsGrid = Ext.create('Ext.grid.Panel', {
			store: logsStore,
			loadMask: true,
			viewConfig: {
				stripeRows: true
			},
			dockedItems: [this.filtersToolbar, this.logToolbar],
			columns: {
				defaults: {
					dataIndex: 'log',
					menuDisabled: true,
					scope: this,
				},
				items: [{
					text: 'Time',
					width: 100,
					align: 'right',
					renderer: function(log, metaData, record, rowIndex, colIndex, store, view) {
						logRenderer(log, metaData);
						if (rowIndex > 0) {
							var diff = log.timestamp - store.getAt(rowIndex - 1).get('log').timestamp;
							if (!diff)
								return "-";
						}
						return lteLogs.ts2time(log.timestamp - filterData.timeOrigin);
					}
				}, {
					text: 'Diff',
					width: 70,
					align: 'right',
					renderer: function(log, metaData, record, rowIndex, colIndex, store, view) {
						logRenderer(log, metaData);
						var diff = rowIndex === 0 ? 0 : log.timestamp - store.getAt(rowIndex - 1).get('log').timestamp;
						if (diff)
							return "+" + (diff / 1000).toFixed(3);
						return "";
					}
				}, {
					text: 'UE',
					width: 60,
					hidden: true,
					renderer: function(log, metaData, record, rowIndex, colIndex, store, view) {
						return srcRenderer(log, 'UE', metaData);
					}
				}, {
					text: '',
					width: 11,
					hidden: true,
					renderer: function(log, metaData, record, rowIndex, colIndex, store, view) {
						return dirRenderer(log, 0, metaData);
					}
				}, {
					text: 'ENB',
					width: 60,
					hidden: true,
					renderer: function(log, metaData, record, rowIndex, colIndex, store, view) {
						return srcRenderer(log, 'ENB', metaData);
					}
				}, {
					text: '',
					width: 11,
					hidden: true,
					renderer: function(log, metaData, record, rowIndex, colIndex, store, view) {
						return dirRenderer(log, 1, metaData);
					}
				}, {
					text: 'MME',
					width: 60,
					hidden: true,
					renderer: function(log, metaData, record, rowIndex, colIndex, store, view) {
						return srcRenderer(log, 'MME', metaData);
					}
				}, {
					text: '',
					width: 11,
					hidden: true,
					renderer: function(log, metaData, record, rowIndex, colIndex, store, view) {
						return dirRenderer(log, 2, metaData);
					}
				}, {
					text: 'IMS',
					width: 60,
					hidden: true,
					renderer: function(log, metaData, record, rowIndex, colIndex, store, view) {
						return srcRenderer(log, 'IMS', metaData);
					}
				}, {
					text: 'ID',
					width: 65,
					align: 'right',
					renderer: function(log, metaData, record, rowIndex, colIndex, store, view) {
						logRenderer(log, metaData);
						return filterValueFormater('rnti', log.rnti, true).display;
					}
				}, {
					text: 'Info',
					width: 80,
					renderer: function(log, metaData, record, rowIndex, colIndex, store, view) {
						logRenderer(log, metaData);
						return searchHighlight(lteLogs.id2string(log.info));
					}
				}, {
					text: 'Message',
					flex: 1,
					renderer: function(log, metaData, record, rowIndex, colIndex, store, view) {
						var msg = log.msg;
						if (msg instanceof Array)
							msg = msg.join(" ");
							
						logRenderer(log, metaData);
						msg = [searchHighlight(msg)];

						//var color = log.client.getColor();
						//if (color)
						//	msg.unshift('<span class="clientSquare" style="background:#' + color + ';">&nbsp;</span>');

						switch (log.layer) {
						case 'PHY':
							if (log.frame)
								msg.unshift('<b>' + log.frame + '</b>:');
							break;
						}

						// Display icons
						if (log.level === 1)
							msg.unshift(lteLogs.createIcon('error', 'Error log'));
						else if (log.level === 2)
							msg.unshift(lteLogs.createIcon('warn', 'Warning log'));
						if (log.error || log.crc === false)
							msg.push(lteLogs.createIcon('no', 'Data were not transmitted'));
						else if (log.crc === true)
							msg.push(lteLogs.createIcon('ok', 'Data successfully transmitted'));
						if (log.data)
							msg.push(lteLogs.createIcon('info', 'This log has additional content'));
						if (typeof log.const === 'number')
							msg.push(lteLogs.createIcon('nostar', 'This log has downloadable constellation information'));
						else if (log.const)
							msg.push(lteLogs.createIcon('star', 'This log has constellation information'));

						return msg.join("&nbsp;");
					}
				}]
			},
			listeners: {
				scope: this,
				selectionchange: function(view, selected, eOpts) {
					var rec = selected[0];
					_SELECTED_LOG = rec ? rec.get('log') : null;
					lteLogs.sendEvent({type: 'selectLog', log: _SELECTED_LOG});
					infoPanelUpdate();
				},

				// *************************
				// * Log line context menu *
				// *************************
				cellcontextmenu: function(view, td, cellIndex, record, tr, rowIndex, e, eOpts) {

					var items = [];

					var log = record.get('log');

					var rnti = log.rnti;
					if (rnti) {
						items.push({
							text: 'Show stats...',
							scope: this,
							iconCls: 'icon-chart',
							handler: function() {
								lteStats.createWindow(allLogs, true, rnti).show();
							}
						});

						var updateList = [];
						logState.clientList.forEach(function (client) {
							var func = client.getUpdateLogMethod({rnti: rnti});
							if (func)
								updateList.push(func);
						});
						if (updateList.length) {
							items.push({
								text: 'Update logs...',
								scope: this,
								iconCls: 'icon-sync',
								handler: function() {
									updateList.forEach(function (f) { f(); });
								}
							});
						}

						items.push({xtype: 'menuseparator'});
					}

					for (var i in filterComponentsData) {
						var param = log[i];
						if (param) {
							var filtered = Ext.Array.contains(filterComponents[i].getValue(), param);
							items.push({
								text: (filtered ? 'Clear filter' : 'Filter') + ' by ' + i + " " + filterValueFormater(i, param).display,
								iconCls: filtered ? "icon-minus" : "icon-plus",
								scope: this,
								handler: (function(i, f, d) {
									filterComponents[i].setValue(f ? [] : d);
								}).bind(this, i, filtered, param)
							});
						}
					}

					var ts = log.timestamp;
					items.push({
						text: "Set time origin",
						iconCls: 'icon-clock',
						scope: this,
						handler: function() {
							filterComponents.time.setValue(lteLogs.ts2time(ts));
						}
					});

					/*items.push({
						text: 'Choose a color for ' + log.client.getName(),
						menu: Ext.create('Ext.menu.ColorPicker', {
							value: log.client.getColor() || 'FFFFFF',
							handler: function(cp, color) {
								log.client.setColor(color === 'FFFFFF' ? null : color);
							}
						})
					});*/

					var cItems = log.client.logCellContextMenu(log, infoPanelUpdate);
					if (cItems.length) {
						items.push({xtype: 'menuseparator'});
						items.push.apply(items, cItems);
					}

					var menu = new Ext.menu.Menu({items: items});
					var position = e.getXY();
					e.stopEvent();
					menu.showAt(position);
				},
			},
			viewConfig: {
				listeners: {
					scope: this,
					containermousedown: function(grid, event, eOpts) {
						if (event.button === 0)
							gridLocker.lock("scroll");
					},
					containermouseup: function(grid, event, eOpts) {
						if (event.button === 0)
							gridLocker.unlock("scroll");
					}
				}
			}
		});

		var infoPanelUpdate = function () {
			var record = logsGrid.getSelection()[0];
			if (record) {
				var log  = record.get('log');
				var data = log.data || [];
				var text = 'From: ' + log.client.getName() + '<br />' + 
							'Time: ' + lteLogs.ts2time(log.timestamp) + ' - Source: ' + log.src + '<br /><br />';
				text += 'Message:<br /><pre>' + searchHighlight(log.msg) + "</pre>";

				if (log.const && typeof log.const === 'object') {
					text += '<canvas id="constellation" width="256" height="256"></canvas><br />';
					setTimeout(function () {
						var canvas = document.getElementById("constellation");
						lteLogs.drawConstellation(canvas, log.const);
					}, 100);

				}
				text += 'Data:<br /><pre>' + searchHighlight(data.join("\n")).replace(/</g, '&lt;').replace(/>/g, '&gt;') + "</pre>";
				text += '</div>';

				_SELECTED_DATA = data;

				lteLogs.log = log;
			} else {
				_SELECTED_DATA = null;
				var text = "&nbsp;"
			}

			infoPanel.update(text);
			lteLogs.refreshView();
		};


		
		// Info panel: right side
		var infoPanel = lteLogs.infoPanel = Ext.create('Ext.panel.Panel', {
			autoScroll: true,
			bodyPadding: 10,
			html: 'Click on a row to see it\'s content here.'
		});

		// Client panel on left side: list of sources
		this.clientToolbar = Ext.create('Ext.toolbar.Toolbar', {
			width: '100%',
			items: [
				Ext.create('Ext.Button', {
					text: 'URL',
					scope: this,
					handler: function () {
						Ext.create('lte.client.config', {class: 'lte.client.url', title: 'Create URL client'}).show();
					},
				}),
				Ext.create('Ext.Button', {
					text: 'Add server',
					scope: this,
					handler: function () {
						Ext.create('lte.client.config', {class: 'lte.client.server', title: 'Create server client'}).show();
					},
				}),
				'->',
				{
					xtype: 'filefield',
					name: 'file',
					buttonOnly: true,
					allowBlank: false,
					buttonText: 'Load file',
					labelWidth: 0,
					maxWidth: 80,
					scope: this,
					listeners: {
						boxready: function (myObj, width, height, eOpts) {
							myObj.fileInputEl.set({multiple: 'multiple'});
						},
						change: function (myObj, value, eOpts) {
							if (value) {
								var files = myObj.extractFileInput().files;
								for (var i = 0; i < files.length; i++) {
									addClient(null, {type: "file", name: files[i].name, file: files[i], enabled: true}, false);
								}
								myObj.fileInputEl.set({multiple: 'multiple'});
							}
						}
					}
				}
			],
		});

		// Convert config 2 tree
		var addClient = function (node, cfg, persistent, save, first) {

			if (!node) node = clientGrid.getRootNode();

			// Leaf
			var list = cfg.list;
			if (!list) {

				switch (cfg.type) {
					case "server":
						var client = Ext.create("lte.client.server", cfg);
						break;
					case "url":
						var client = Ext.create("lte.client.url", cfg);
						break;
					case "file":
						var client = Ext.create("lte.client.file", cfg);
						break;
				}

				var nodeCfg = {
					persistent: persistent,
					client:  client,
					name:    cfg.name,
					leaf:    true,
					iconCls: client.getIcon()
				};
				if (first) {
					node.insertChild(0, nodeCfg);
				} else {
					node.appendChild(nodeCfg);
				}
				logState.clientList.push(client);

				if (location.search.match("client=" + cfg.name))
					client.toggleState();

			} else {
				var parent = node.appendChild({
					persistent: persistent,
					name:       cfg.name,
					expanded:   false,
				});
				for (var i in list) {
					addClient(parent, list[i], persistent);
				};
			}

			if (save)
				saveConfig();
		}

		// Convert config 2 tree
		lteLogs.addClient = function (cfg, persistent, save) {
			addClient(null, cfg, persistent, save, true);
		}


		// Save config to local storage
		var saveConfig = lteLogs.saveConfig = function () {

			var translate = function (node) {

				if (node.isLeaf()) {
					return node.getData().client.config;

				} else {
					var list = [];
					node.eachChild(function (c) {
						if (c.getData().persistent)
							list.push(translate(c));
					});
				}
				return {'list': list, name: node.name};
			}
			
			var root = translate(clientGrid.getRootNode());
			localStorage.clients = JSON.stringify(root.list);
		};

		var clientStore = Ext.create('Ext.data.TreeStore', {
			model: '4GLogs.data.Client',
			root: {name: 'root', children: []}
		});

		// Client toolbar
		var selectedClientRecord = null;
		var clientButtons = {
			config: Ext.create('Ext.Button', {
				iconCls: 'icon-config',
				tooltip: lteLogs.tooltip('Configure'),
				listeners: {
					scope: this,
					click: function(button, e, eOpts) {
						var client = selectedClientRecord.get("client");
						if (client && client.isConfigurable()) {
							Ext.create('lte.client.config', {
								client: client,
								title: 'Configure ' + client.getName(),
							}).show();
						}
					}
				}
			}),
			enable: Ext.create('Ext.Button', {
				iconCls: 'icon-ok',
				tooltip: lteLogs.tooltip("Enable/disable this log"),
				listeners: {
					scope: this,
					click: function(button, e, eOpts) {
						selectedClientRecord.get("client").toggleState();
						clientGridUpdate(selectedClientRecord);
					}
				}
			}),
			del: Ext.create('Ext.Button', {
				iconCls: 'icon-delete',
				tooltip: lteLogs.tooltip('Delete'),
					listeners: {
					scope: this,
					click: function(button, e, eOpts) {
						selectedClientRecord.parentNode.removeChild(selectedClientRecord);
						var client = selectedClientRecord.get("client");
						client.destroy();
						lteLogs.updateLogs();
						saveConfig();
					}
				}
			}),
			playPause: Ext.create('Ext.Button', {
				iconCls: 'icon-play',
				tooltip: lteLogs.tooltip('Play/Pause'),
					listeners: {
					scope: this,
					click: function(button, e, eOpts) {
						selectedClientRecord.get("client").playPause();
						clientGridUpdate(selectedClientRecord);
					}
				}
			}),
			rb: Ext.create('Ext.Button', {
				iconCls: 'icon-comp',
				tooltip: lteLogs.tooltip('Ressource blocks'),
				listeners: {
					scope: this,
					click: function(button, e, eOpts) {
						var rb = Ext.create("lte.stats.rb", selectedClientRecord.get("client"));
						var rec = logsGrid.getSelection()[0];
						if (rec)
							rb.setLog(rec.get('log'), true);
					}
				}
			}),
			cut: Ext.create('Ext.Button', {
				iconCls: 'icon-cut',
				tooltip: lteLogs.tooltip('Reset logs'),
				listeners: {
					scope: this,
					click: function(button, e, eOpts) {
						selectedClientRecord.get("client").resetLogs();
					}
				}
			}),
			refresh: Ext.create('Ext.Button', {
				iconCls: 'icon-refresh',
				tooltip: lteLogs.tooltip('Connect'),
				listeners: {
					scope: this,
					click: function(button, e, eOpts) {
						var client = selectedClientRecord.get("client");
						client.toggleState();
						client.toggleState();
					}
				}
			})
		};

		var clientGridUpdate = function (record) {

			var states = {};
			selectedClientRecord = record;
			var client = record ? record.get('client') : null;
			if (client) {
				states.config	= client.isConfigurable();
				states.enable	= true;
				states.del		= record.getData().persistent;
				states.rb		= client.hasRessourceBlocks();
				states.cut		= client.getState() === 'connected' && client.hasLogs();
				states.refresh  = true; //client.getState() === 'error';

				if (client.isRealTime()) {
					clientButtons.playPause.setIconCls(client.isPaused() ? 'icon-play' : 'icon-pause');
					states.playPause = true;
				} else {
					states.playPause = false;
				}

				clientButtons.enable.setIconCls(client.isEnabled() ? 'icon-off' : 'icon-ok');
			}
			for (var i in clientButtons) clientButtons[i].setDisabled(!states[i]);
			clientGrid.getView().refresh();
		};

		// Client grid:
		// - List of client sources to fill log grid
		var clientGrid = this.clientGrid = Ext.create('Ext.tree.Panel', {
			rootVisible: false,
			tbar: {items: [
				clientButtons.config,
				clientButtons.enable,
				clientButtons.refresh,
				clientButtons.playPause,
				clientButtons.rb,
				clientButtons.cut,
				'->',
				clientButtons.del
			]},
			useArrows: true,
			store: clientStore,
			hideHeaders: true,
			columns: [{
				xtype: 'treecolumn', //this is so we know which column will show the tree
				dataIndex: 'name',
				flex: 1,
				renderer: function(value, metaData, record, rowIndex, colIndex, store, view) {
					var client = record.get("client");
					if (client) {
						metaData.tdAttr = 'data-qtip="' + lteLogs.tooltip(client.getInfo()) + '"';
						record.data.iconCls = client.getIcon();

						var iconList = [];
						if (client.isEnabled()) {
							iconList.push({icon: "ok", tip: "Enabled"});
							var cs = client.getState();
							if (cs === "connected")		iconList.push({icon: "lightning", tip: "Connected"});
							if (cs === "connecting")	iconList.push({icon: "lightning-red", tip: "Connecting"});
							if (cs === "error")			iconList.push({icon: "problem", tip: "Error"});
							if (cs === "loading")		iconList.push({icon: "lightning-red", tip: "Loading"});
							if (client.isRealTime()) {
								iconList.push(client.isPaused() ?
									{icon: "pause", tip: "Paused"} :
									{icon: "play", tip: "Play"});
							}
						}

						value = client.getName() + "&nbsp;&nbsp;&nbsp;" + 
								iconList.map(function (item) { return "<img src='data:image/gif;base64,R0lGODlhAQABAID/AMDAwAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==' class='x-tree-icon icon-" + item.icon + "' title='" + item.tip + "'>"; }).join("&nbsp;");
					}
					return value;
				}
			}],
			listeners: {
				scope: this,
				selectionchange: function(view, selected, eOpts) {
					clientGridUpdate(selected[0]);
				},
				celldblclick: function(grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
					var client = record.get("client");
					if (client) client.toggleState();
				}
			},
		})
		
		lteLogs.refreshClientGrid = function () {
			clientGridUpdate(selectedClientRecord);
		};

		lteLogs.load = Ext.Function.bind(function (l) {
			this.viewport.setLoading(l);
		}, this);

		// **************************************************************
		// * Logs update
		// **************************************************************
		var logState = {
			clientList:			[],
			newLogsPause:		false,
			resetMetadata:		false,
			minLevelDetected:	10,
			newLogs:			[],
			filter:				false,
		};

		// External API
		lteLogs.updateLogs = function (params) {

			// Update params
			logsUpdater.update(true);
		};

		lteLogs.getLogs = function (client) {
			return allLogs.filter(function (log) { return log.client === client; });
		},

		// Shortcuts
		lteLogs.updateFilter = function () {
			if (logState.filter !== 'lock') {
				logState.filter = true;
				logsUpdater.updateNow();
			}
		};
		lteLogs.lockFilter = function (state) {
			if (state)
				logState.filter = 'lock';
			else {
				logState.filter = true;
				logsUpdater.updateNow();
			}
		};
		lteLogs.refreshView = function () {
			logsGrid.getView().refreshView();
		};

		lteLogs.selectLog = function (log) {

			var index = curLogs.indexOf(log);
			var range = _getLogsGridVisibleRange();
			var min   = logsStore.indexOf(range[0]);
			var max   = logsStore.indexOf(range.pop());
			var rec   = logsGrid.getSelection()[0];
			var cur   = rec ? logsStore.indexOf(rec) : -1;

			lteLogs.info("Scroll", min, max, cur, index);

			// Inside
			if (cur >= min && cur <= max) {
				min = index + min - cur;
			} else {
				min = index - ((max - min) >> 1);
			}

			logsUpdater.lock("select");
			logsGrid.getView().bufferedRenderer.scrollTo(min, false, function () {
				lteLogs.info("End fo scroll, index = " + index + ", min = " + min);
				logsGrid.setSelection(index);
				logsUpdater.unlock("select");
			});
		};

		// Logs state
		var allLogs			= [];	// All logs
		var curLogs			= [];	// Filtered logs
		var gridLogs		= [];	// Displayed logs

		var gridLocker = lteLogs.gridLocker = Ext.create("lte.updater", {
			name:			"Grid.locker",
			scope:			this,
			updateDelay:	100,
			async:			true,
			handler:		function () {

				// Copy list
				gridLogs = curLogs.slice();

				// Update metadata
				_updateMetadata();

				logState.newLogs.length = 0;

				// No logs, just clear
				if (!gridLogs.length) {
					// Hack to avoid events to fail
					logsGrid.getSelectionModel().clearSelections();
					logsStore.clearData();
					logsGrid.view.bufferedRenderer.doAttemptLoad();
					return;
				}

				// Keep selection if possible
				var selectedLog    = logsGrid.getSelection()[0];
				var selectedOffset = -1;
				if (selectedLog)
					logsGrid.getSelectionModel().clearSelections();

				// Get current view bounds
				var range = _getLogsGridVisibleRange();
				for (var i in range) {
					var id = range[i].get('id');
					if (selectedLog === range[i]) {
						selectedOffset = i;
						var selectedLogId = id;
					}
					range[i] = id;
				}
				lteLogs.debug("Update before range", range, selectedLogId, selectedOffset);

				// Lock logs update as allLogs will be used
				logsUpdater.lock("GridLocker");

				// Reload store
				logsStore.reload();

				// Async
				Ext.defer(function () {
					// Try to get previously displayed logs
					var newRange = [];
					var scrollTo = -1;
					var select   = false;

					var curLogsIndex	= 0;
					var curLogsLength	= curLogs.length;
					var allLogsIndex	= 0;
					var allLogslength	= allLogs.length;
					var rangeLength		= range.length;
					for (var i = 0; i < rangeLength; i++) {
						var id = range[i];

						// Look for log
						for (var a = allLogsIndex; a < allLogslength; a++) {
							var log = allLogs[a];
							if (log.id === id) {
								if (!log.filtered) {
									while (log !== curLogs[curLogsIndex]) curLogsIndex++;

									if (id === selectedLogId) {
										scrollTo = Math.max(curLogsIndex - selectedOffset, 0);
										select   = curLogsIndex;
										lteLogs.debug("Scroll to selection", curLogsIndex, scrollTo);
										range.length = 0;
										break;
									}
									newRange.push(curLogsIndex);
								}
								allLogsIndex = a + 1;
								break;
							}
						}
					}

					logsGrid.getView().refreshView();
					if (scrollTo < 0) {
						// Nothing matches, just refresh
						if (!newRange.length) {
							lteLogs.info("Just refresh, don't know where to focus");
							logsGrid.getView().refreshScroll();
							Ext.Function.defer(function () {
								logsGrid.getView().refreshView();
								logsUpdater.unlock("GridLocker");
							}, 10);
							return;
						}

						scrollTo = Math.round(Ext.Array.mean(newRange) - (rangeLength >> 1));
					}
					scrollTo = Math.min(Math.max(0, scrollTo), logsStore.getTotalCount() - 1);

					lteLogs.info("Refresh at", scrollTo);
					try {
						logsGrid.getView().bufferedRenderer.scrollTo(scrollTo, false, function () {
							Ext.Function.defer(function () {
								if (select !== false)
									logsGrid.setSelection(select);
								lteLogs.info("End of scroll");
								logsUpdater.unlock("GridLocker");
							}, 1);
						});
					} catch (e) {
						lteLogs.error("Error while scrolling to", scrollTo, e);
						logsUpdater.unlock("GridLocker");
					}

				}, 200, this);
			}
		});

		var logsUpdater = Ext.create("lte.updater", {
			name:			"Logs.updater",
			scope:			this,
			updateDelay:	1000,
			async:			true,
			handler:		function () {

				lteLogs.debug("Update logs");

				var t0 = new Date() - 0;
				var updateGrid = false;
				var resetCurLogs = false;

				// Filter current
				if (logState.filter) {
					for (var i = 0; i < allLogs.length; i++) {
						filterLog(allLogs[i]);
					}
					resetCurLogs			= true;
					updateGrid				= "now";
					logState.resetMetadata	= true;
					logState.filter			= false;
				}

				// Get new logs from each client
				if (!logState.newLogsPause) {
					var newLogs = [];

					var clientList = logState.clientList;
					for (var i = clientList.length; i--;) {
						var client = clientList[i];

						var state = client.getLogs();

						// Reset current ?
						if (!state || state.reset) {
							lteLogs.debug("Reset logs", client.getName());
							curLogs					= curLogs.filter(function (log) { return log.client !== client; });
							allLogs					= allLogs.filter(function (log) { return log.client !== client; });
							updateGrid				= updateGrid || true;
							logState.resetMetadata	= true;
						}

						if (!state) {
							clientList.splice(i, 1);
						} else if (state.logs.length) {
							lteLogs.debug("Add logs", client.getName());
							newLogs = newLogs.concat(state.logs);
						}
					};
					if (newLogs.length) {
						logState.newLogs = logState.newLogs.concat(newLogs);

						// Filter new logs
						for (var i = 0; i < newLogs.length; i++) {
							filterLog(newLogs[i]);
						}

						allLogs = _addNewLogs(newLogs, allLogs);
						updateGrid		= updateGrid || true;
					}
				}

				// Too much logs ?
				var toRemove = allLogs.length - MAX_LOGS;
				if (toRemove > 0) {
					lteLogs.info("Remove", toRemove, "logs");
					var remove = allLogs.splice(0, toRemove);
					if (!resetCurLogs) {
						var count = 0;
						for (var i = 0; i < remove.length; i++) {
							if (!remove[i].filtered)
								count++;
						}
						if (count <= curLogs.length)
							curLogs.splice(0, count);
						else
							resetCurLogs = true;
					}
					updateGrid = updateGrid || true;
				}

				// Reset curLogs
				if (resetCurLogs) {
					curLogs.length = 0;
					for (var i = 0, length = allLogs.length; i < length; i++) {
						var log = allLogs[i];
						if (!log.filtered)
							curLogs.push(log);
					}
				} else if (newLogs.length) {
					var cList = [];
					for (var i = 0; i < newLogs.length; i++) {
						var log = newLogs[i];
						if (!log.filtered)
							cList.push(log);
					}
					curLogs = _addNewLogs(newLogs, curLogs);
				}

				lteLogs.allLogs = allLogs;
				lteLogs.curLogs = curLogs;

				lteLogs.prof("Update logs in", (new Date() - t0), "ms");

				// Update grid ?
				if (updateGrid) {
					logsTab.setTitle('Logs: ' + curLogs.length + " / " + allLogs.length);
					if (updateGrid === "now")
						gridLocker.updateNow();
					else
						gridLocker.update(true);
				}
			}
		});

		var _updateMetadata = function () {

			var minLevel = logState.minLevelDetected;
			if (logState.resetMetadata) {
				logState.minLevelDetected = 10;
				for (var i in filterComponentsData)
					if (filterComponentsData[i].cur) filterComponentsData[i].cur = {};
				var logList = allLogs;
				logState.resetMetadata = false;
			} else {
				var logList = logState.newLogs;
			}

			var l = logList.length;
			while (l--) {
				var log = logList[l];
				for (var j in filterComponentsData) {
					var type = log[j];
					if (type !== undefined) {
						var cur = filterComponentsData[j].cur;
						if (cur !== undefined) cur[type] = true;
					}
				}
				logState.minLevelDetected = Math.min(logState.minLevelDetected, log.level);
			}

			// Less
			if (minLevel < logState.minLevelDetected) {
				if (minLevel <= 1)
					errorInfoButton.setVisible(false);
				if (minLevel <= 2)
					warnInfoButton.setVisible(false);
			} else if (minLevel > logState.minLevelDetected) {
				if (logState.minLevelDetected <= 1)
					errorInfoButton.setVisible(true);
				if (logState.minLevelDetected <= 2)
					warnInfoButton.setVisible(true);
			}

			filterData.locked = true;
			for (var i in filterComponentsData) {
				var data = filterComponentsData[i];
				// List has changed
				if (data.cur && !Ext.Object.equals(data.cur, data.last)) {

					var curList = data.cur;
					var fData   = filterData[i];
					var select  = [];
					for (var j in curList) {
						if (fData.indexOf(j) >= 0)
							select.push(j);
					}
					filterComponents[i].getStore().loadData(Object.keys(curList).map(function (v) {
						
						return filterValueFormater(i, v);
					}));
					filterComponents[i].select(select);
					data.last = Ext.Object.merge({}, data.cur);
				}
			}
			filterData.locked = false;
		}

		var _getLogsGridVisibleRange = lteLogs.getVisibleRange = function() {

			var view  = logsGrid.getView();
			var range = [];
			var box   = view.getBox();
			var nodes = view.getNodes();

			for (var i in nodes) {
				var node = nodes[i];
				var rect = node.getBoundingClientRect();
				if (rect.top >= box.top && rect.top < box.bottom) {
					var r = view.getRecord(node);
					range.push(r);
				}
			}

			return range;
		};

		var filterComponentsData = {
			"layer": {},
			"level": {},
			"rnti":  {"last": {}, "cur": {}},
			"info":  {"last": {}, "cur": {}},
		};
		var filterValueFormater = function (type, value, highLight) {
			switch (type) {
			case "rnti":
				if (value) {
					value = value - 0;
					var str = value.toString(16);
					var text = '0x' + str;
					var display = '<font color="#c0c0c0">0x</font>' + (highLight ? searchHighlight(str) : str);
				} else {
					var value = '';
				}
				break;
			case "layer":
				var style = 'border: 1px solid; border-color: ' + layerConfig[value].color + ';';
				var display = value;
				break;
			case "level":
				var text = lteLogs.levels[value];
				var display = '<img src="resources/images/' + text + '.png" height="13"> ' + text;
				break;
			case 'info':
				value = value - 0;
				var text = lteLogs.id2string(value);
				var display = (highLight ? searchHighlight(text) : text);
				break;
			default:
				var display = (highLight ? searchHighlight(value) : value);
			}
			return {
				style: style || '',
				text: text || value,
				display: display || value,
				value: value
			};
		}

		var getLogIndexByTimestamp = function(list, timestamp) {
			var l = list.length;
			var b = l - 1;
			var a = 0;
			for (; a <= b;) {

				var i = (a + b) >> 1;
				var ts_i = list[i].timestamp;

				if (timestamp < ts_i) { // Before middle
					b = i - 1;
				} else if (timestamp > ts_i) { // After middle
					a = i + 1;
				} else {
					while (++i < l && list[i].timestamp === timestamp);
					return i;
				}
			}
			return a;
		};

		// Job
		var _addNewLogs = function (srcList, dstList) {

			var srcLength = srcList.length;

			var t0 = new Date() - 0;

			// Try to insert
			var t0 = new Date() - 0;
			var dstLength = dstList.length;
			if (dstLength > 200000 || srcLength < 50000) {
				// Sort new data
				srcList.sort(function sortLogs(a, b) { return a.timestamp - b.timestamp || a.id - b.id; });
				var t1 = new Date() - 0;

				// Insert
				var a = getLogIndexByTimestamp(dstList, srcList[0].timestamp);

				for (var i = 0; i < srcLength; i++) {
					var log = srcList[i];
					var ts  = log.timestamp;

					for (; a < dstLength; a++) {
						var ts_a = dstList[a].timestamp;
						if (ts < ts_a) break;
					}
					if (a === dstLength) {
						while (i < srcLength) {
							dstList.push(srcList[i++]);
						}
						break;
					}
					dstList.splice(a, 0, log);
					a++;
					dstLength++;
				}

			// Compute everything
			} else {
				dstList = dstList.concat(srcList);
				var t1 = new Date() - 0;
				dstList.sort(function sortLogs(a, b) { return a.timestamp - b.timestamp || a.id - b.id; });
				dstLength = dstList.length;
			}

			lteLogs.prof(srcLength + " log(s) added", (t1 - t0) + "ms", (new Date() - t1) + "ms", dstLength);
			return dstList;
		};

		// **************************************************************
		// * Logs update end
		// **************************************************************


		var tabPanel = Ext.create('Ext.tab.Panel', {
			height: 400,
			items: [],
		});
		lteLogs.addTab = function (tab, active) {
			var tab = tabPanel.add(tab);
			if (active)
				tabPanel.setActiveTab(tab);
			return tab;
		};

		gridLocker.lock("tab");
		var logsTab = lteLogs.addTab({
			'title': 'No logs loaded yet',
			'iconCls': 'icon-logs',
			'layout': 'border',
			'items': [{
				region: 'east',
				width: 400,
				split: true,
				collapsible: true,
				collapsed: false,
				header: false,
				layout: 'fit',
				items: infoPanel
			}, {
				region: 'center',
				layout: 'fit',
				items: [logsGrid]
			}],
			listeners: {
				activate: function () {
					gridLocker.unlock("tab");
				},
				deactivate: function () {
					gridLocker.lock("tab");
				}
			}
		});

		this.borderContainer = Ext.create('Ext.container.Container', {
			height: 'auto',
			layout: 'border',
			items: [{
				title: "Amarisoft LTE Web Interface 2015-10-28",
				tools: [{
					type: 'help',
					handler: function(e, toolEl, panel, tc) {
						var win = new Ext.Window({
							title: 'Documentation',
							html: '<iframe src="doc/ltewww.html" width="100%" height="100%" />',
							maximizable: true,
							height: 500,
							width: 900,
							modal: true,
							plain:true,
						});
						win.show();
					}
				}],
				tbar: this.clientToolbar,
				region: 'west',
				layout: 'fit',
				width: 320,
				split: true,
				collapsible: true,
				collapsed: false,
				items: clientGrid,
			}, {
				region: 'center',
				layout: 'fit',
				items: tabPanel
			}]
		});

		this.viewport.add(this.borderContainer);

		Ext.Ajax.request({
			url: 'loglist.php',
			scope: this,
			success: function(response, opts) {
				var list = Ext.decode(response.responseText);

				for (var i in list) {
					addClient(null, list[i], false);
				}
			},
		});
		
		// Load last known config
		if (localStorage.clients) {
			// Recover from local storage
			var config = JSON.parse(localStorage.clients);
			if (config instanceof Array) {
				for (var i in config) {
					addClient(null, config[i], true, false);
				}
			}
		}
		logsStore.load();
		clientGridUpdate(null);
	}
});

var lteLogs = {

	_logs: {},
	_logDefaultLevel: localStorage.debug >> 0,
	_logsMethods: ["error", "warn", "info", "debug", "prof"],
	_startDate: new Date() * 1,

	_log: function (module, id, log) {

		log.ts = new Date() - this._startDate;

		if (module.list.push(log) > 20)
			module.list.shift();

		if (log.level & module.level) {
			if (log.level & 0x1 && module.level === 0x1) {
				for (var i in module.list) {
					this._logDisplay(id, module.list[i]);
				}
				module.list = [];
			} else {
				this._logDisplay(id, log);
			}
		}
	},

	_logDisplay: function(id, log) {
		var time  = this.ts2time(log.ts);
		if (log.level & 0x1) {					// Error
			var style = "background: red";
			var index = 0;
		} else if (log.level & 0x2) {			// Warning
			var style = "background: yellow";
			var index = 1;
		} else if (log.level & 0x10) {			// Prof
			var style = "background: #00ff00";
			var index = 4;
		} else {
			var style = "";
			var index = Math.floor(Math.log2(log.level));
		}
		var args = ["%c[" + time + "][" + this._logsMethods[index].toUpperCase() + "][" + id + "]", style];
		args.push.apply(args, log.args);
		console.log.apply(console, args);
	},

	setLogger: function (name, instance) {
		var module = this._logs[name] = {level: this._logDefaultLevel, list: []};

		this._logsMethods.forEach((function (id, i) {
			instance[id] = (function () {
				this._log(module, name, {level: (1<<i), args: arguments});
			}).bind(this);
		}).bind(this));
	},

	tooltip: function (txt) {
		//return 'data-qtip="' + txt + '"';
		return txt ? txt.replace(/ /g, "&nbsp;") : '';
	},

	merge: function (dst, src, override) {
		for (var i in src) {
			if (override || !dst.hasOwnProperty(i))
				dst[i] = src[i];
		}
		return dst;
	},

	clone: function (o) {
		if (typeof o !== "object" && o !== null) return o;
		var clone = o instanceof Array ? [] : {};
		for (var i in o) {
			clone[i] = this.clone(o[i]);
		}
		return clone;
	},

	padLeft: function (txt, c, len) {
		txt = ""+txt;
		while (txt.length < len) txt = c + txt;
		return txt;
	},

	ts2time: function (ts) {
		var sign = "";
		if (ts < 0) {
			sign = "-";
			ts = -ts;
		}
		var ms = (ts % 1000) >> 0;
		ts = (ts / 1000) >> 0;
		var s = ts % 60;
		ts = (ts / 60) >> 0;
		var m = ts % 60;
		var h = (ts / 60) >> 0;
		return sign + h + ":" + Ext.String.leftPad(m, 2, "0") + ":" + Ext.String.leftPad(s, 2, "0") + "." + Ext.String.leftPad(ms, 3, "0");
	},

	ts2time2: function (date) {
		var today_abs = new Date();
		today_abs.setHours(0); today_abs.setMinutes(0); today_abs.setSeconds(0); today_abs.setMilliseconds(0);
		return this.ts2time(date - today_abs);
	},

	levels: ["none", "error", "warn", "info", "debug"],

	mapFilter: function (array, func) {
		var res = [];
		for (var i = 0, length = array.length; i < length; i++) {
			var item = func(array[i], i);
			if (item !== undefined)
				res.push(item);
		}
		return res;
	},

	drawConstellation: function (canvas, constel) {
		var ctx = canvas.getContext("2d");
		ctx.fillStyle="black";
		ctx.fillRect(0, 0, 255, 255);
		ctx.fillStyle="#ffffff";
		ctx.globalAlpha=0.2;
		for (var i = 0; i < constel.byteLength; ) {
			var x = constel[i++] + 128;
			var y = constel[i++] + 128;
			ctx.fillRect(x, y, 1, 1);
		}
	},

	createIcon: function (icon, tooltip) {
		return '<img src="resources/images/' + icon + '.png" height=12 title="' + tooltip + '">';
	},


	// Constants
	DIR_NONE:	0,
	DIR_UL:		1,
	DIR_DL:		2,
	DIR_FROM:	3,
	DIR_TO:		4,

	_stringIDs: {},
	_stringList: [],
	string2id: function (str) {

		var id = this._stringIDs[str];
		if (!id) {
			id = this._stringIDs[str] = this._stringList.push(str);
		}
		return id;
	},

	id2string: function (id) {
		if (id > 0) return this._stringList[id - 1] || '';
		return '';
	},

	// Events
	_eventListeners: {},
	_eventListenerId: 0,

	registerEventListener: function (type, cb) {
		var id = this._eventListenerId++;
		this._eventListeners[id] = {type: type, cb: cb};
		return id;
	},

	unregisterEventListener: function (id) {
		delete this._eventListeners[id];
	},

	sendEvent: function (event) {

		var type = event.type;
		for (var i in this._eventListeners) {
			var el = this._eventListeners[i];
			switch (el.type) {
			case type:
			case '*':
				el.cb(event);
				break;
			}
		}
	},

	getMouseWheelEvent: function () {
		return (/Firefox/i.test(navigator.userAgent)) ? "DOMMouseScroll" : "mousewheel";
	},

	getMouseWheelDelta: function (event) {
		if (event.detail)
			return event.detail * -120;
		else
			return event.wheelDelta;
	},

	exportFile: function (data, filename, mimetype) {

		var blob = new Blob([data], { type: mimetype });
		if (navigator.msSaveBlob) { // IE 10+
			navigator.msSaveBlob(blob, filename);
		} else {
			var link = document.createElement("a");
			if (link.download !== undefined) { // feature detection
				// Browsers that support HTML5 download attribute
				var url = URL.createObjectURL(blob);
				link.setAttribute("href", url);
				link.setAttribute("download", filename);
				link.style = "visibility:hidden";
				document.body.appendChild(link);
				link.click();
				document.body.removeChild(link);
			}
		}
	},
};

lteLogs.setLogger("DEFAULT", lteLogs);

var globalLogId = 0;




Ext.define("lte.updater", {

	constructor: function (config) {

		this._name				= config.name || "Locker",
		this._updateHandler		= config.handler;
		this._updateScope		= config.scope;
		this._updateDelay		= config.updateDelay - 0;
		this._autoDelay			= config.autoDelay - 0;
		this._updateAsync		= !!config.async;
		this._dirty				= !!config.dirty;
		this._lockCount			= config.lock >> 0;
		this._lockers			= {};
	},

	destroy: function () {
		if (this._updateTimer)
			clearTimeout(this._updateTimer);
	},

	lock: function (locker) {
		if (locker) {
			if (this._lockers[locker])
				return false;

			this._lockers[locker] = true;
		}
		this._lockCount++;
		return true;
	},

	unlock: function (locker) {
		if (locker) {
			if (!this._lockers[locker])
				return false;

			delete this._lockers[locker];
		}

		this._lockCount--;

		if (!this._lockCount) {
			this.update();
		} else if (this._lockCount < 0) {
			lteLogs.error("Bad count for", this._name);
		}
		return true;
	},

	isPending: function () {
		return this._updateTimer;
	},

	isLocked: function () {
		return this._lockCount > 0;
	},

	update: function (dirty) {

		if (dirty) {
			this._dirty = true;
		} else if (!this._dirty) {
			return false;
		}

		if (this._lockCount || this._updateTimer || this._updating)
			return false;

		if (this._updateAsync)
			this._updateLater(1, false);
		else
			this._update(false);
	},

	updateNow: function () {
		if (this._updateTimer)
			clearTimeout(this._updateTimer);

		this._update(false);
	},

	_update: function (delayed) {

		this._dirty = false;
		this._updating = true;
		this._updateHandler.call(this._updateScope, delayed);
		this._updating = false;

		// Auto
		if (this._autoDelay) {
			if (this._autoTimer)
				clearTimeout(this._autoTimer);
			this._autoTimer = Ext.Function.defer(function () {
				this._autoTimer = 0;
				this.update(true);
			}, this._autoDelay, this);
		}

		if (this._updateDelay > 0)
			this._updateLater(this._updateDelay, true);
		return true;
	},

	_updateLater: function (delay, delayed) {
		this._updateTimer = Ext.Function.defer(function () {
			this._updateTimer = 0;
			if (this._dirty && !this._lockCount) {
				this._update(delayed);
			}

		}, delay, this);
	},
});



