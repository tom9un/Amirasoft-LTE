/*
 * Copyright (C) 2012-2014 Amarisoft
 *
 * Amarisoft LTE Web interface 2015-10-28
 */

var lteStats = {

	_createFromLogs: function (allLogs, filter, param2series) {

		// Filter relevant logs and format them
		var t0 = new Date();
		for (var i = 0, length = allLogs.length; i < length; i++) {
			var log  = allLogs[i];
			var rnti = log.rnti;

			// Filter
			if (filter && rnti !== filter) continue;
			if (log.error) continue;

			// For each wanted parameter
			for (var paramId in param2series) {

				var value = log[paramId];
				if (value === undefined) continue;

				var serie = param2series[paramId];
				if (serie.crc && log.crc === false) continue;

				switch (serie.global) {
				case 'only':
					this._addLog2Serie(serie, log, 0);
					break;
				case true:
					this._addLog2Serie(serie, log, rnti);
					if (rnti)
						this._addLog2Serie(serie, log, 0);
					break;
				default:
					if (rnti)
						this._addLog2Serie(serie, log, rnti);
					break;
				}
			}
		}
		this.prof("Read", allLogs.length, "logs for stats in ", new Date() - t0, "ms");
	},

	_addLog2Serie: function (serie, log, rnti) {
		var logs = serie.logs[rnti];
		if (!logs) {
			serie.logs[rnti] = [log];
		} else {
			logs.push(log);
		}
	},

	createWindow: function createWindow(allLogs, defState, filter) {

		// Charts definition
		var chartDefinitions = [{
			title: 'Throughput',
			unit: 'Brate',
			series: {
				"TB_LEN_1":	{title: "UL <rnti>", crc: true, avg: 'time', global: true},
				"TB_LEN_2":	{title: "DL <rnti>", crc: true, avg: 'time', global: true},
				"SDU_LEN1":	{title: "IP UL <rnti>", avg: 'time', global: true},
				"SDU_LEN2":	{title: "IP DL <rnti>", avg: 'time', global: true},
				"MAC_PAD1":	{title: "UL padding <rnti>", avg: 'time', global: 'only'},
				"MAC_PAD2":	{title: "DL padding <rnti>", avg: 'time', global: 'only'},
			},
		}, {
			title: 'SNR',
			unit: 'dB',
			series: {
				"SNR_SRS":		{title: "SRS <rnti>"},
				"SNR_PUCCH":	{title: "PUCCH <rnti>"},
				"SNR_PUSCH":	{title: "PUSCH <rnti>"},
			}
		}, {
			title: 'MCS',
			series: {
				"MCS_1":		{title: "UL <rnti>"},
				"MCS_2":		{title: "DL <rnti>"},
			}
		}, {
			title: "CQI",
			series: {
				"cqi":			{title: "<rnti>"},
			}
		}, /*{
			title: "BER",
			series: {
				"ber":			{title: "<rnti>"},
			}
		},*/ {
			title: "Timing advance",
			series: {
				"ta":			{title: "<rnti>"},
			}
		}, {
			title: "Rank indicator",
			series: {
				ri:			{title: "<rnti>"},
			}
		}, {
			title: "UL buffer",
			unit: 'Bsize',
			series: {
				ul_buffer_size:			{title: "UL buffer size <rnti>"},
			}
		}, {
			title: "Power head room",
			unit: ' dB',
			series: {
				phr:			{title: "PHR <rnti>"},
			}
		}, {
			title: 'Retransmissions',
			unit: ' retx/s',
			series: {
				retx:			{title: "Retransmission <rnti>", avg: 'time', global: true},
			}
		}];

		// Fill chart definitions with logs splitted
		var param2series = {};
		chartDefinitions.forEach(function (chart) {
			for (var paramId in chart.series) {
				var serie = chart.series[paramId];
				serie.logs = {}; // 1 array for each rnti
				param2series[paramId] = serie;
			}
		});
		this._createFromLogs(allLogs, filter, param2series);

		// Enable/disable
		var rntisState = {};
		for (var paramId in param2series) {
			var serie = param2series[paramId];
			for (var rnti in serie.logs) {

				var logs = serie.logs[rnti];
				if (logs.length > 1) {
					var r = rntisState[rnti];
					if (!r) r = rntisState[rnti] = {state: false, count: 0};
					r.count += logs.length;
				} else {
					delete serie.logs[rnti]; // XXX: remove for real time update
				}
			}
		}

		// Create chart
		var createChartTab = (function (chartDef) {

			// Get series and fields (At least 2 points !)
			var series = [];
			for (var paramId in chartDef.series) {
				var serie = chartDef.series[paramId];

				for (var rnti in serie.logs) {
					if (!rntisState[rnti].state) continue;

					var logs = serie.logs[rnti];
					if (logs.length < 1) continue; // At least 2 points

					var serieId = rnti + paramId;
					var rnti = rnti - 0;
					series.push({
						serie:		serie,
						serieId:	serieId,
						paramId:	paramId,
						rnti:		rnti,
						logs:		logs
					});
				}
			}
			if (!series.length)
				return false;

			// Create chart
			var chart = chartDef.chart = Ext.create('lte.graph', {
				title: chartDef.title,
				chartDef: chartDef,
				mySeries: series,
				graph: {
					axis: {
						x: {unit: 'time'},
						y: {unit: chartDef.unit || ''}
					}
				}
			});

			series.forEach(function (serie) {
				chart.addSerie(serie.serieId, {
					title: serie.serie.title.replace("<rnti>", serie.rnti ? serie.rnti.toString(16) : ''),
				});
			});

			return chart;

		}).bind(this);

		// Update chart
		var avg_time = 250;
		var sel_chart = null;
		var updateChart = (function (chart) {

			if (!chart) {
				if (!sel_chart) return false;
				chart = sel_chart;
			} else {
				sel_chart = chart;
			}

			var t0 = new Date();

			chart.graph.reset();
			chart.lock();

			// Filter each serie
			var series = chart.mySeries;
			series.forEach(function (serie) {
				var logs	= serie.logs;
				var paramId = serie.paramId;

				var avg = serie.serie.avg;
				var data = [];
				var ts = logs[0].timestamp;
				for (var i = 0, length = logs.length; i < length;) {

					var alog  = 0; // Average log
					var count = 0;
					for (; i < length; i++) {
						var log = logs[i];
						if (log.timestamp - ts > avg_time) break;

						alog += log[paramId];
						count++;
					}

					switch (avg) {
					case 'time':
						alog *= 1000 / avg_time;
						break;

					default:
						if (count > 0)
							alog /= count;
						break;
					}

					data.push({x: ts, y: alog, logs: logs});
					ts += avg_time;
				}

				chart.addValues(serie.serieId, data);
			});
			chart.unlock();
				
			this.prof("Average stats in", new Date() - t0, 'for', chart.chartDef.title);

		}).bind(this);

		// Select RNTIs
		var storeData = Object.keys(rntisState);
		storeData.sort(function (a, b) { return (a >> 0) - (b >> 0); });
		var rntiGrid = Ext.create('Ext.grid.Panel', {
			frameHeader: false,
			store: {
				fields: ['label', 'id'],
				data: storeData.map(function (rnti) {
					rnti = rnti - 0;
					return { id: rnti, label: (rnti ? rnti.toString(16) : 'Global') + ' (' + rntisState[rnti].count + ')' };
				}),
			},
			columns: [{
				text: "RNTI",
				dataIndex: "label",
				flex: 1
			}],
			allowDeselect: true,
			multiSelect: true,
			listeners: {
				scope: this,
				selectionchange: function(view, selected, eOpts) {

					// Reset and set
					for (var rnti in rntisState) { rntisState[rnti].state = false; }
					selected.forEach(function (r) { rntisState[r.get('id')].state = true; });

					// Replace chart
					var t0 = new Date();
					var region = win.getComponent("chart");
					region.removeAll();

					var chartList = [];
					var activeTab = 0;
					for (var i in chartDefinitions) {
						var chartDef = chartDefinitions[i];
						var chart = createChartTab(chartDef);
						if (chart) {
							if (chartDef.selected) activeTab = chartList.length;
							chartList.push(chart);
						}
					}

					var tab = region.add(Ext.create('Ext.tab.Panel', {
						items: chartList,
						activeTab: activeTab,
						listeners: {
							tabchange: function(tabPanel, newCard, oldCard, eOpts) {
								oldCard.chartDef.selected = false;
								newCard.chartDef.selected = true;
								updateChart(newCard);
							}
						}
					}));
					updateChart(chartList[activeTab]);
					this.prof("Update chart in ", new Date() - t0, "ms");
				},
			}
		});

		var win =  Ext.create('Ext.window.Window', {
			title: 'Analytics',
			width: 1000,
			height: 600,
			constraint: true,
			layout: 'border',
			maximizable: true,
			items: [{
				region: 'west',
				layout: 'fit',
				width: 140,
				split: true,
				//collapsible: true,
				//collapsed: false,
				items: rntiGrid,
			}, {
				region: 'center',
				id: 'chart',
				layout: 'fit',
				tbar: [{
					xtype: 'numberfield',
					anchor: '100%',
					fieldLabel: 'Average time',
					value: avg_time,
					step: 10,
					maxValue: 10000,
					minValue: 10,
					listeners: {
						scope: this,
						change: function(num, newValue, oldValue, eOpts) {
							if (newValue && num.isValid()) {
								avg_time = newValue;
								updateChart();
							}
						}
					}
				}],
				items: []
			}],
			listeners: {
				scope: this,
				show: function () {
					if (defState)
						rntiGrid.setSelection(0);
				}
			}
		});
		return win;
	},

	_stats: {},


	setStats: function(id, msg) {

		var now = new Date() * 1;

		var chart = this._stats.chart;
		if (!chart) {
			var chart = this._stats.chart = Ext.create('lte.graph', {
				title: 'Stats',
				iconCls: 'icon-chart',
				graph: {
					axis: {
						y: {
							min: 0,
							max: 100,
							unit: '%'
						},
						x: {
							unit: 'date',
							auto: 'max',
							min: now,
							max: now + 300000,
						}
					}
				}
			});
			lteLogs.addTab(chart);
		}

		var item = {};

		// CPU
		for (var i in msg.cpu) {
			var name = id + i;
			item[name] = msg.cpu[i];

			chart.addSerie(name, {
				title: id + " cpu load (" + i + ")",
				values: [{x: now, y: msg.cpu[i]}]
			});
		}
		chart.update();
	},
};

lteLogs.setLogger("STATS", lteStats);

