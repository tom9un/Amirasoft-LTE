Ext.define("lte.mme.tab", {

	extend: 'Ext.panel.Panel',
	layout: 'fit',

	constructor: function (config) {
		this._client = config.client;

		this.callParent(arguments);
	},

	listeners: {
		activate: function () {
			this._updater.update(true);
			this._updater.unlock();
		},
		deactivate: function () {
			this._updater.lock();
		},
		close: function () {
			this._updater.destroy();
		},
	},

	lteUpdate: function() {
		this._updater.update(true);
	},

	initComponent: function () {
		this.callParent(arguments);

		var store = Ext.create('Ext.data.Store', {
			fields: ["imsi", "imeisv", "m_tmsi", "registered"]
		});

		var grid = Ext.create('Ext.grid.Panel', {
			store: store,
			columns: [{
				text: "IMSI",
				dataIndex: "imsi",
				width: 150
			}, {
				text: 'IMEISV',
				dataIndex: 'imeisv',
				width: 150
			}, {
				text: 'M-TMSI',
				dataIndex: 'm_tmsi',
			}, {
				text: 'Registered',
				dataIndex: 'registered',
				type: 'boolean'
			}],
		});

		this._updater = Ext.create("lte.updater", {
			scope:			this,
			updateDelay:	1000,
			dirty:			true,
			lock:			1,
			handler:		function () {
				this._client.sendMessage({message: 'ue_get'}, function (msg) {
					store.loadData(msg.ue_list);
				});
			}
		});

		this.add(grid);
	},
});



