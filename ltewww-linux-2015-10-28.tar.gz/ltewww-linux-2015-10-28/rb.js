/*
 * Copyright (C) 2012-2014 Amarisoft
 *
 * Amarisoft LTE Web interface 2015-10-28
 */

Ext.define("lte.stats.rb", {

	constructor: function (client) {

		lteLogs.setLogger(client.getName() + ".rb", this);

		// Create cetts from config
		var clientCells = client.getParams('cells');
		var cells = this.cells = {};
		for (var cell_id in clientCells) {
			cells[cell_id] = lteLogs.merge({logs: []}, clientCells[cell_id]);
		}

		// Parse logs and found cells
		var logs  = lteLogs.getLogs(client);
		for (var i = 0, length = logs.length; i < length; i++) {
			var log = logs[i];
			if (log.layer !== "PHY") continue;

			var cell_id = log.cell;
			if (cell_id === undefined) continue;

			var cell = cells[cell_id];
			if (cell) cell.logs.push(log);
			else      this.error("Unknown cell", cell_id);
		}

		this._rbList = [];

		var win = this._win = this._createWindow();
		win.show();

		this._selectLogEventId = lteLogs.registerEventListener('selectLog', this._selectLogEvent.bind(this));
	},

	_selectLogEvent: function (event) {
		this.setLog(event.log, true);
	},

	setLog: function (log, move) {
		if (log !== this._selectedLog) {
			var ts = log.timestamp;

			this._selectedLog = log;
			for (var i = 0; i < this._rbList.length; i++) {
				if (log === this._rbList[i].log) {
					if (this._rbList[i].displayed) {
						move = false;
						break;
					}
				}
			}
			if (move)
				this.setTime(ts);

			this._update();
		}
	},

	setTime: function (ts) {
		for (var i = 0; i < this._max_x; i++) {
			ts0 = this.ts_list[i];
			if (ts0 !== undefined && ts <= ts0) {
				this._slider.setValue(i - 10);
				return;
			}
		}
	},

	channelColor: {
		"PUSCH": "red",
		"PDSCH": "blue",
		"PMCH":  "#00ffff",
		"PUCCH": "green",
		"PRACH": "yellow",
	},

	// Area config
	grid_x:		0,
	grid_y:		0,
	grid_z:		0,

	// Legend
	legend_n:	1,
	legend_w:	200,
	legend_h:	20,

	// Block value
	rb_w:		14,
	rb_h:		10,
	rb_x_offset: 0,
	ts_offset: 0,

	_createWindow: function () {
		// Create slider
		var slider = this._slider = Ext.create('Ext.slider.Single', {
			width: '100%',
			value: 0,
			increment: 1,
			minValue: 0,
			maxValue: this._max_x,
			tipText: Ext.Function.bind(function (thumb) {
				var value = slider.getValue() + this.rb_x_offset;
				var frame = (value / 10) >> 0;
				var subf  = value % 10;
				var time = lteLogs.ts2time(value);
				return "Frame #" + frame + ", sub frame " + subf + "<br/>Time: " + time;
			}, this),
			listeners: {
				scope: this,
				change: function(slider, newValue, thumb, eOpts) {
					this.grid_x = newValue * this.grid_rb_w;
					this._update();
				}
			}
		});

		// Create draw container
		var container = Ext.create('Ext.panel.Panel', {
			html: '<canvas></canvas>',
			listeners: {
				scope: this,
				afterlayout: function(slider, newValue, thumb, eOpts) {
					var canvas = this._canvas;

					canvas.addEventListener(lteLogs.getMouseWheelEvent(), this._mouseWheelEvent.bind(this), false);
					canvas.addEventListener("mousedown", this._mouseDownEvent.bind(this), false);
					canvas.addEventListener("mousemove", this._mouseMoveEvent.bind(this), false);
					canvas.addEventListener("mouseout", this._mouseOutEvent.bind(this), false);
					canvas.addEventListener("mouseup", this._mouseUpEvent.bind(this), false);

					this._toolTip = Ext.create('Ext.tip.ToolTip', {
						target: canvas,
						trackMouse: true,
						autoHide: true,
					});
				},
				resize: function(cont, width, height) {
					var canvas = this._canvas = container.el.down("canvas").dom;
					canvas.width = width;
					canvas.height = height;
					this._update();
				}
			}
		});

		// Cell selection
		var cellCombo = this._cellCombo = Ext.create('Ext.form.field.ComboBox', {
			store: {
				fields: ["cell_id"],
				data: Object.keys(this.cells).map(function (cell_id) { return {cell_id: cell_id}; }),
			},
			width: 90,
			queryMode: 'local',
			valueField: 'cell_id',
			displayField: 'cell_id',
			labelWidth: 30,
			fieldLabel: 'Cell',
			allowBlank: false,
			listeners: {
				scope: this,
				change: function(me, newValue, oldValue, eOpts) {
					this._resetLogs();
					this._update();
				}
			}
		});

		var dlRadio = this._dlRadio = Ext.create('Ext.form.field.Radio', {
			bodyPadding: 5,
			checked: true,
			name: 'dir',
			boxLabel: 'DL',
			width: 40,
			listeners: {
				scope: this,
				change: function(radio, newValue, oldValue, eOpts) {
					this._resetLogs();
				}
			}
		});
		var ulRadio = this._ulRadio = Ext.create('Ext.form.field.Radio', {
			bodyPadding: 5,
			name: 'dir',
			boxLabel: 'UL',
			width: 40,
		});

		var autoSizeButton = Ext.create('Ext.button.Button', {
			width: 32,
			tooltip: lteLogs.tooltip("Adjust zoom"),
			iconCls: "icon-zoom",
			listeners: {
				scope: this,
				click: function(filter, e, eOpts) {
					this._autoSize = true;
					this._update();
				}
			}
		});

		var timeFormater = function (value) {
			value = value.match(/^(((\d+):)?(\d+):)?(\d+)(\.(\d+))?$/);
			if (value) {
				var h = value[3] >> 0;
				var m = value[4] >> 0;
				var s = value[5] >> 0;
				var ms = value[7] || "0";
				ms = ((ms - 0) * Math.pow(10, 3 - ms.length)) >> 0;
				return h * 3600000 + m * 60000 + s * 1000 + ms;
			}
			return null;
		};

		var timeSelector = this.timeSelector = Ext.create("Ext.form.field.Text", {
			fieldLabel: 'Time',
			labelWidth: 30,
			value: "0:00:00.000",
			width: 165,
			validateOnChange: true,
			validator: function (value) {
				return timeFormater(value) !== null;
			},
			listeners: {
				scope: this,
				blur: function (filter, event, eOpts) {
					var ts = timeFormater(filter.getValue());
					this._slider.setValue(ts - this.ts_offset);
				},
			}
		});


		this._autoSize = true;
		var height = document.body.clientHeight || window.innerHeight;

		cellCombo.select(Object.keys(this.cells)[0]);
		return  Ext.create('Ext.window.Window', {
			title: 'Ressource Block Allocation',
			width: 1000,
			minWidth: 500,
			minHeight: Math.min(500, height),
			maxHeight: height,
			height: height,
			constraint: true,
			maximizable: true,
			layout: 'fit',
			tbar: {items: [autoSizeButton, cellCombo, dlRadio, ulRadio, '|', timeSelector]},
			bbar: {items: [slider]},
			items: [container],

			listeners: {
				scope: this,
				close: function(panel, eOpts) {
					//this._selectLogEventId = lteLogs.registerEventListener('selectLog', this._selectLogEvent.bind(this));
				}
			}
		});
	},

	_prachConfig: [
		[~1, [1]],
		[~1, [4]],
		[~1, [7]],
		[~0, [1]],
		[~0, [4]],
		[~0, [7]],
		[~0, [1, 6]],
		[~0, [2, 7]],
		[~0, [3, 8]],
		[~0, [1, 4, 7]],
		[~0, [2, 5, 8]],
		[~0, [3, 6, 9]],
		[~0, [0, 2, 4, 6, 8]],
		[~0, [1, 3, 5, 7, 9]],
		[~0, [1, 2, 3, 4, 5, 6, 7, 8, 9]],
		[~1, [9]]
	],

	_resetLogs: function () {

		var cell_id = this._cellCombo.getSelectedRecord().get('cell_id');
		var cell = this.cells[cell_id];
		var mode = cell.mode;

		switch (mode) {
		case "TDD":
			this._ulRadio.setVisible(false);
			this._dlRadio.setVisible(false);
			break;
		default:
			this._ulRadio.setVisible(true);
			this._dlRadio.setVisible(true);
			break;
		}
		if (this._dlRadio.getValue()) {
			this.rb_count = cell.n_rb_dl;
			var dir = lteLogs.DIR_DL;
		} else {
			this.rb_count = cell.n_rb_ul;
			var dir = lteLogs.DIR_UL;
		}

		// Init
		var max_x    = 0;
		var last_x   = 0;
		var offset_x = undefined;
		var ts_list = this.ts_list = [];
		var rbList = this._rbList;
		rbList.length = 0;

		// Parse logs
		var logs = cell.logs;
		for (var i = 0, length = logs.length; i < length; i++) {
			var log = logs[i];
			if (mode !== "TDD" && log.dir !== dir) continue;

			var x = (log.frame * 10) >> 0;

			// Loop ?
			if (offset_x !== undefined) {
				var diff = x - last_x;
				if (diff < -10000)
					offset_x += 10240;
				else if (diff > 10000)
					offset_x -= 10240;
			}

			switch (lteLogs.id2string(log.channel)) {
			case "PRACH":
				if (mode !== "TDD" && cell.prach_freq_offset) {

					// Get x
					var cfg = this._prachConfig[cell.prach_config_index % 16];
					var sub = cfg[1];
					var x1  = Infinity;
					var s   = sub.length;
					var f   = Math.floor(log.frame) & cfg[0];
					while (x1 >= x) {
						if (--s < 0) {
							s = sub.length - 1;
							f = (f - 1) & cfg[0];
						}
						x1 = f * 10 + sub[s];
					}
					x = x1;

					// First entry
					if (offset_x === undefined) {
						offset_x = -x;
						this.rb_x_offset = x;
						this.ts_offset = log.timestamp;
					}
					var rb_x = x + offset_x;
					var format = Math.floor(cell.prach_config_index / 16);
					var n = ([1, 2, 2, 3])[format];
					max_x = Math.max(max_x, rb_x + n);
					rbList.push({x0: rb_x, x1: rb_x + n, y0: cell.prach_freq_offset, y1: cell.prach_freq_offset + 6, log: log, slot: 3});
				}
				break;

			default:
				var rb_list = log.rb_list;
				if (rb_list) {
					// First entry
					if (offset_x === undefined) {
						offset_x = -x;
						this.rb_x_offset = x;
						this.ts_offset = log.timestamp;
					}

					var rb_x = x + offset_x;

					for (var r = 0, rb_count = rb_list.length; r < rb_count;) {
						var y0 = rb_list[r++];
						var y1 = rb_list[r++];
						var sl = rb_list[r++];
						rbList.push({x0: rb_x, x1: rb_x + 1, y0: y0, y1: y1, log: log, slot: sl});
					}
					max_x = Math.max(max_x, rb_x);
				}
				break;
			}
			last_x = x;
			ts_list[x + offset_x] = log.timestamp;
		}
		this._max_x = max_x + this.rb_x_offset;

		this._update();
	},

	_update: function() {

		var canvas = this._canvas;
		if (!canvas)
			return;

		// Available drawing height (rb + axes)
		var width  = canvas.width - 5;
		var height = canvas.height - this.legend_h * (this.legend_n + 1);

		var rb_c = this.rb_count;
		var h_c = 5;

		if (this._autoSize) {
			this.grid_z = Math.floor(height / (rb_c + h_c) * this.rb_w / this.rb_h - this.rb_w);
			this._autoSize = false;
		}

		// Set zoom out limit (rb_w must be at least 4
		this.grid_z = this.grid_z = Math.max(4, this.rb_w + this.grid_z) - this.rb_w;

		// Resource block size
		var rb_w = this.grid_rb_w = this.rb_w + this.grid_z;
		var rb_h = Math.max(this.grid_rb_h = Math.floor(this.rb_h * rb_w / this.rb_w), Math.floor(height / (rb_c + h_c)));

		// Grid offset
		height = Math.min(height - h_c * rb_h, rb_c * rb_h);
		var grid_x = this.grid_x = Math.max(Math.min(this.grid_x, this._max_x * rb_w - width), 0);
		var grid_y = this.grid_y = Math.max(Math.min(this.grid_y, rb_c * rb_h - height), 0);

		var t0 = new Date();

		//console.log("Update", width, height, grid_x, grid_y, rb_w, rb_h);

		// Init context
		var ctx = canvas.getContext("2d");
		ctx.setTransform(1, 0, 0, 1, 0, 0); // Reset transform
		ctx.fillStyle		= 'black';
		ctx.strokeStyle		= 'black';
		ctx.textBaseline	= 'middle';
		ctx.textAlign		= 'center';
		ctx.clearRect(0, 0, canvas.width, canvas.height);

		ctx.save();
		ctx.fillStyle = '#f0f0f0';
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		ctx.restore();

		// Error pattern
		var errorSize = 3;
		var errorCanvas = document.createElement('canvas');
		errorCanvas.width  = errorSize;
		errorCanvas.height = errorSize;
		var errorCtx = errorCanvas.getContext('2d');
		errorCtx.strokeStyle = '#f0f0f0';
		errorCtx.beginPath();
		errorCtx.moveTo(0, errorSize);
		errorCtx.lineTo(errorSize, 0);
		errorCtx.stroke();
		var errorPattern = ctx.createPattern(errorCanvas, "repeat");

		// Update slider value
		this._slider.setMaxValue(this._max_x - Math.ceil(width / rb_w));

		var rb_x0 = Math.floor(grid_x / rb_w);
		var rb_y0 = Math.floor(grid_y / rb_h);
		var rb_x1 = Math.min(Math.ceil((grid_x + width) / rb_w), this._max_x - 1);
		var rb_y1 = Math.min(Math.ceil((grid_y + height) / rb_h), rb_c - 1);

		var font_max = 16;
		var font_rb_h = Math.min(rb_h, font_max);

		// Draw frame/sub frame
		ctx.save();
		ctx.beginPath();
		ctx.rect(20, 0, width - 20, height + h_c * rb_h);
		ctx.strokeStyle = 'white';
		ctx.clip();
		for (var rb_x = rb_x0; rb_x <= rb_x1; rb_x++) {
			var x = rb_x * rb_w - grid_x + 20;

			var f = rb_x + this.rb_x_offset;
			ctx.font = font_rb_h + "px Arial";
			ctx.fillText(f % 10, x + rb_w / 2, height + rb_h / 2 + 1);

			ctx.beginPath();
			ctx.moveTo(x, 0);
			ctx.lineTo(x + 0.5, height);
			ctx.stroke();
			if (!(f % 10)) {
				ctx.save();
				ctx.strokeStyle = 'black';
				ctx.beginPath();
				ctx.moveTo(x + 0.5, height);
				ctx.lineTo(x + 0.5, height + rb_h * h_c);
				ctx.stroke();
				ctx.font = Math.min(Math.floor(rb_h * 1.5), font_max) + "px Arial";
				ctx.fillText(((f / 10) >> 0) & 1023, x + 5 * rb_w, height + rb_h * 2);
				ctx.fillText(lteLogs.ts2time(this.ts_offset + rb_x), x + 5 * rb_w, height + rb_h * 4);
				ctx.restore();
			}
		}
		ctx.restore();

		// Time
		var time = lteLogs.ts2time(this.ts_offset + rb_x0);
		this.timeSelector.setValue(time);
		
		// Draw rb #
		ctx.save();
		ctx.font = font_rb_h + "px Arial";
		ctx.beginPath();
		ctx.rect(0, 0, width, height);
		ctx.strokeStyle = 'white';
		ctx.clip();
		for (var rb_y = rb_y0; rb_y <= rb_y1; rb_y++) {
			var y = rb_y * rb_h - grid_y;

			ctx.beginPath();
			ctx.moveTo(20, y + 0.5);
			ctx.lineTo(width, y + 0.5);
			ctx.stroke();
			ctx.fillText(rb_c - rb_y - 1, 10, y + rb_h / 2);
		}
		ctx.restore();

		// Draw RB
		var selectedLog = this._selectedLog;
		var selectedRB = null;
		ctx.save();
		ctx.translate(0, 1);
		ctx.textBaseline = 'top';
		ctx.beginPath();
		ctx.rect(20, 0, width - 20, height);
		ctx.stroke();
		ctx.clip();
		var rb_list = this._rbList;
		for (var i = 0; i < rb_list.length; i++) {
			var rb = rb_list[i];

			rb.displayed = false;
			if (rb.x0 > rb_x1 || rb.x1 <= rb_x0)
				continue;

			var x0 = Math.max(rb_x0, rb.x0) * rb_w - grid_x + 20;
			var x1 = Math.min(rb_x1, rb.x1) * rb_w - grid_x + 20;
			var y0 = Math.max(rb_y0, rb_c - rb.y1) * rb_h - grid_y;
			var y1 = Math.min(rb_y1 + 1, rb_c - rb.y0) * rb_h - grid_y;

			if (x0 < x1 && y0 < y1) {
				var log = rb.log;

				if (!(rb.slot & 0x1))
					x0 += rb_w / 2;
				if (!(rb.slot & 0x2))
					x1 -= rb_w / 2;

				rb.displayed = true;
				rb.draw_x0 = x0;
				rb.draw_x1 = x1;
				rb.draw_y0 = y0;
				rb.draw_y1 = y1;

				ctx.fillStyle = this.channelColor[lteLogs.id2string(log.channel)];
				ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
				if (log.crc === false || log.error) {
					ctx.fillStyle = errorPattern;
					ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
				}
				if (log === selectedLog) {
					selectedRB = {x: x0, y: y0, w: x1 - x0, h: y1 - y0};
				} else {
					ctx.strokeStyle = '#808080';
					ctx.strokeRect(x0, y0, x1 - x0, y1 - y0);
				}
			}
		}
		if (selectedRB) {
			ctx.strokeStyle = 'black';
			ctx.strokeRect(selectedRB.x, selectedRB.y, selectedRB.w, selectedRB.h);
		}
		ctx.restore();

		// Legend
		var size			= this.legend_h - 6;
		ctx.font			= Math.min(font_max, size) + "px Arial";
		ctx.textBaseline	= 'middle';
		ctx.textAlign		= 'left';
		var top = canvas.height - (this.legend_n + 0.5) * this.legend_h;
		var n = 0;
		for (var i in this.channelColor) {

			x = Math.floor(n / this.legend_n) * this.legend_w + 10;
			y = top + (n % this.legend_n) * this.legend_h + 3;

			ctx.fillStyle = this.channelColor[i];
			ctx.fillRect(x, y, size, size);
			ctx.strokeRect(x, y, size, size);
			ctx.fillStyle = 'black';
			ctx.fillText(i, x + this.legend_h, y + size / 2);
			n++;
		}

		this.prof("Draw RB in", new Date() - t0, "ms");
	},

	_getLogs: function (event) {
		var canvas = event.target;
		var rect = canvas.getBoundingClientRect();
		var x = event.clientX - rect.left;
        var y = event.clientY - rect.top;
		
		var list = [];
		var rb_list = this._rbList;
		for (var i = 0; i < rb_list.length; i++) {
			var rb = rb_list[i];
			if (rb.displayed && x >= rb.draw_x0 && x < rb.draw_x1 && y >= rb.draw_y0 && y < rb.draw_y1)
				list.push(rb.log);
		}
		return list;
	},

	// Scroll

	// Wheel: zoom in/out
	_mouseWheelEvent: function (event) {
		var delta = lteLogs.getMouseWheelDelta(event);
		var offset = delta / Math.abs(delta);
		if (offset) {
			this.grid_z += offset;
			this._update();
		}
	},

	// Down
	_mouseDownEvent: function (event) {
		if (event.button === 0) {
			this._move = {
				x:		event.layerX + this.grid_x,
				y:		event.layerY + this.grid_y,
				x0:		event.layerX,
				y0:		event.layerY,
			};
		}
	},

	// Move
	_mouseMoveEvent: function (event) {
		if (this._move) {
			this.grid_x = this._move.x - event.layerX;
			this.grid_y = this._move.y - event.layerY;
			this._update();
		} else {
			var logs = this._getLogs(event);
			if (logs.length) {
				this._toolTip.update(logs.map(function (log) { return log.msg; }).join('<br/>'));
				this._toolTip.show([event.clientX, event.clientY]);
			} else {
				this._toolTip.hide();
			}
		}
	},

	// Out
	_mouseOutEvent: function (event) {
		//this._move = undefined;
		this._toolTip.hide();
	},

	// Up
	_mouseUpEvent: function (event) {
		if (event.button === 0 && (!this._move || (Math.abs(event.layerX - this._move.x0) < 2 && Math.abs(event.layerY - this._move.y0) < 2))) {
			var log = this._getLogs(event)[0];
			if (log) {
				this.setLog(log);
				lteLogs.selectLog(log);
			}
		}
		this._move = undefined;
	},
});




