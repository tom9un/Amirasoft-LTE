Ext.define("lte.ims.tab", {

	extend: 'Ext.panel.Panel',
	layout: 'fit',

	constructor: function (config) {
		this._client = config.client;
		this.callParent(arguments);
	},

	listeners: {
		activate: function () {
			this._updater.unlock();
		},
		deactivate: function () {
			this._updater.lock();
		},
		close: function () {
		},
	},

	lteUpdate: function() {
		this._updater.update(true);
	},

	initComponent: function () {
		this.callParent(arguments);

		var usersUpdate = function (list) {
			var usersHash = {};
			list.forEach(function (user) {usersHash[user.impi] = user; });
			for (var i = usersStore.getCount(); i--;) {

				var record = usersStore.getAt(i);
				var impi   = record.get('impi');
				var user   = usersHash[impi];
				if (user) {
					record.set(user);
					delete usersHash[impi];
				}
			}

			usersStore.add(Object.keys(usersHash).map(function (impi) { return usersHash[impi]; }));
		}

		// Catch update events
		this._client._msgHandler.users_update = (function (msg) {
			usersUpdate(msg.users);
		}).bind(this);

		// Update UE list
		this._updater = Ext.create("lte.updater", {
			scope:			this,
			updateDelay:	1000,
			dirty:			true,
			lock:			1,
			handler:		function () {
				this._client.sendMessage({message: 'users'}, function (msg) {
					usersUpdate(msg.users);
				});
			}
		});


		var usersStore = Ext.create('Ext.data.Store', {
			fields: ["impi", "sms", "dialogs", "bindings"]
		});

		var usersGrid = Ext.create('Ext.grid.Panel', {
			store: usersStore,
			selModel: {
				mode: "MULTI"
			},
			viewConfig:{
				markDirty: false
			},
			columns: [{
				text: "IMPI",
				dataIndex: "impi",
				width: 250
			}, {
				text: 'SMS',
				dataIndex: 'sms',
				width: 70
			}, {
				text: "Bindings",
				dataIndex: "bindings",
				flex: 1,
				renderer: function(bindings, metaData, record, rowIndex, colIndex, store, view) {
					return bindings.map(function (b) { return b.uri.replace(/</, "&lt;").replace(/>/, "&gt;"); }).join(",");
				},
			}, {
				text: "Dialogs",
				dataIndex: "dialogs",
				flex: 1,
				renderer: function(dialogs, metaData, record, rowIndex, colIndex, store, view) {
					if (!dialogs)
						return "&nbsp;";
					return dialogs.map(function (dlg) { return dlg.remote; }).join(",");
				},
			}],
			listeners: {
				scope: this,
				cellcontextmenu: function(myGrid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
					var items = [];

					items.push({
						text: "Send SMS",
						scope: this,
						iconCls: 'icon-ue',
						handler: function() {
							Ext.Msg.prompt('Send SMS', 'Please enter SMS:', function(btn, text) {
								if (btn == 'ok') {
									this._client.sendMessage({message: 'sms', text: text, impi: record.get('impi')}, (function (r) {
									}).bind(this));
								}
							}, this);
						}
					});
			
					var menu = new Ext.menu.Menu({items: items});
					var position = e.getXY();
					e.stopEvent();
					menu.showAt(position);
				}
			}
		});
		
		this.add(usersGrid);
	},
});



