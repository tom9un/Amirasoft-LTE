/*
 * Copyright (C) 2012-2015 Amarisoft
 *
 * Amarisoft LTE Web interface 2015-10-28
 */

Ext.define("lte.client", {

	constructor: function (config) {
		lteLogs.setLogger(config.name, this);

		this.config			= config;
		this._logs			= [];
		this._logCount		= 0;
		this._components	= {};
		this._params		= {cells: {}};
		this._state			= "stop";

		this._lastHarq = {}; // Store last log on harq

		// Default
		this._dirConverter = {
			'UL': lteLogs.DIR_UL,
			'DL': lteLogs.DIR_DL,
			'-': lteLogs.DIR_NONE,
		};

		if (config.enabled)
			this.start();

		this._eventListeners = {};
		this._eventListenerId = 0;
	},

	start: function () {
		this._setState("start");
	},

	stop: function () {
		this._setState("stop");
	},

	destroy: function () {
		if (this.config.enabled)
			this.toggleState();
		this._setState("destroy");
	},

	_reset: function () {
		if (this._logCount) {
			this._resetFlag		= true;
			this._logs.length	= 0;
			this._has_rb		= false;
			this._logCount = 0;
			this._lastHarq = {};
			lteLogs.updateLogs();
			lteLogs.refreshClientGrid();
		}
	},

	_setState: function (state) {
		if (state !== this._state) {
			this.debug("State change", this._state, state);

			this._state = state;
			switch (state) {
			case "stop":
				this._reset();
				this.closeComponents();
				lteLogs.gridColumnsUpdate();
				break;

			case "start":
			case "connected":
				lteLogs.gridColumnsUpdate();
				break;

			case "loading":
			case "connecting":
				break;

			case "destroy":
				this.closeComponents();
				return;
			}
			lteLogs.refreshClientGrid();
		}
	},

	registerEventListener: function (type, cb) {
		var id = this._eventListenerId++;
		this._eventListeners[id] = {type: type, cb: cb};
		return id;
	},

	unregisterEventListener: function (id) {
		delete this._eventListeners[id];
	},

	sendEvent: function (event) {

		var type = event.type;
		for (var i in this._eventListeners) {
			var el = this._eventListeners[i];
			switch (el.type) {
			case type:
			case '*':
				el.cb(event);
				break;
			}
		}
	},

	/* stop
	 * start
	 * loading
	 * connecting
	 * connected
	 * error
	 */
	getState: function () {
		return this._state;
	},

	isRealTime: function () {
		return false;
	},

	isEnabled: function () {
		return this.config.enabled;
	},

	isConfigurable: function () {
		return false;
	},

	hasRessourceBlocks: function () {
		return this._has_rb;
	},

	toggleState: function () {
		if (!this.config.enabled) {
			this.config.enabled = true;
			this.start();
		} else {
			this.config.enabled = false;
			this.stop();
		}
		lteLogs.refreshClientGrid();
		lteLogs.saveConfig();
	},

	hasLogs: function () {
		return this._logCount > 0;
	},

	getParams: function (id) {
		return this._params[id];
	},

	getLogs: function () {

		if (this._state === "destroy")
			return null;

		var state = {
			logs:	this._logs,
			reset:	this._resetFlag,
		};
		this._resetFlag = false;
		this._logs  = [];
		return state;
	},

	logCellContextMenu: function (log) {
		return [];
	},

	getUpdateLogMethod: function (filter) {
		return null;
	},

	addComponent: function addComponent(id, comp) {
		var prev = this._components[id];
		if (prev)
			prev.close();
		this._components[id] = comp;
	},

	getComponent: function getComponent(id) {
		return this._components[id];
	},

	closeComponent: function closeComponent(id) {
		var comp = this._components[id];
		if (comp) {
			delete this._components[id];
			comp.close();
		}
	},

	closeComponents: function closeComponents() {
		var list = this._components;
		this._components = {}; // Reset first to avoid recursion
		for (var id in list) {
			list[id].close();
		}
	},

	textLogsAdd: function(lines) {

		var t0 = new Date() - 0;
		var _regExpStart	= new RegExp(/^([\d:\.]+) \[([\w\d]+)\] (UL|DL|-|TO|FROM)\s+(.*)/); // date [layer] dir
		var _regExpHeader1	= new RegExp(/^([\da-f]+)\s+([\da-f\-]+)\s+(.+)/); // cell rnti
		var _regExpHeader2	= new RegExp(/^([\da-f\-]+)\s+(.+)/); // rnti

		var _regExpHeader	= new RegExp(/^        /);
		var _regExpDate		= new RegExp(/(\d+):(\d+):([\d\.]+)/);

		// Parse comment
		var cell = null;
		var length = lines.length;
		for (i = 0; i < length; i++) {
			var line = lines[i], info;
			if (line[0] !== "#") break;

			if (!cell) {
				if (info = line.match(/lte(\w+) version ([\d-]+)/i)) {
					this.setModel(info[1].toUpperCase());
					this._version = info[2];
				}
			}

			// Cell
			if (info = line.match(/Cell 0x(\d+): (.*)/)) {

				var cell_id = parseInt(info[1], 16);
				cell = this._params.cells[cell_id] = {};

				var list = info[2].split(/\s+/);
				for (var j in list) {
					var params = list[j].split("=");
					cell[params[0]] = params[1];
				}

			// Cell params
			} else if (cell) {
				if (info = line.match(/([UD]L): (.*)/)) {
					var dir = info[1];
					var list = info[2].split(/\s+/);
					for (var j in list) {
						var params = list[j].split("=");
						cell[params[0]] = params[1] - 0;
					}
				}
			}
		}

		// Model not found
		if (!this.config.model) {
			var name = this.config.name;
			if (name.match(/ue/i))
				this.setModel('UE');
			else if (name.match(/enb/i))
				this.setModel('ENB');
			else if (name.match(/mbms/i))
				this.setModel('MBMS');
			else if (name.match(/ims/i))
				this.setModel('IMS');
			else
				this.setModel('MME');
		}
		var model = this.config.model;

		var log  = null;
		var logs = [];
		for (; i < length; i++) {

			// Parse line
			var line = lines[i];
			var info = line.match(_regExpStart);
			if (!info) {
				if (log) {
					if (!log.data)
						log.data = [""];
					log.data[0] += line.replace(_regExpHeader, "") + "\n";
				}
				continue;
			}

			// Time
			var time = info[1];
			var date = time.match(_regExpDate);
			if (date) {
				var timestamp = Math.round(date[1] * 3600000 + date[2] * 60000 + date[3] * 1000);
			} else {
				var timestamp = time * 1000;
			}

			var layer = info[2];
			var msg   = info[4];

			log = {
				'timestamp':	timestamp,
				'src':			model,
				'layer':		layer,
				'dir':			this._dirConverter[info[3]] | 0,
				'info':			undefined,
				'rnti':			0,
				'cell':			undefined,
				'msg':			msg,
			};

			switch (layer) {
			case 'S1AP':
			case 'X2AP':
			case 'GTPU':
			case 'SIP':
			case 'IMS':
			case 'COM':
				break;
			default:
				if (info = msg.match(_regExpHeader1)) {
					log.cell = parseInt(info[1], 16);
					log.rnti = parseInt(info[2], 16) || 0;
					log.msg  = info[3];
				} else if (info = msg.match(_regExpHeader2)) {
					log.rnti = parseInt(info[1], 16) || 0;
					log.msg  = info[2];
				}
				break;
			}

			if (logs.push(log) + this._logCount >= MAX_LOGS) {
				this.error('Too much logs');
				break;
			}
		}

		this._logListParse(logs);

		this.prof('Load file in', new Date() - t0, 'ms');
	},

	getIcon: function () {
		return 'icon-' + this.config.type;
	},

	getName: function () {
		return this.config.name;
	},

	setName: function (name) {
		this.config.name = name;
	},

	getInfo: function () {

		var info = this._info;
		if (this._version) info += ", v" + this._version;
		return info;
	},

	getModel: function () {
		return this.config.model;
	},

	setModel: function (model) {

		this.config.model = model;

		switch (model) {
		case 'MME':
		case 'IMS':
			this._dirConverter.TO = lteLogs.DIR_DL;
			this._dirConverter.FROM = lteLogs.DIR_UL;
			break;
		default:
			this._dirConverter.TO = lteLogs.DIR_UL;
			this._dirConverter.FROM = lteLogs.DIR_DL;
			break;
		}

		lteLogs.gridColumnsUpdate();
	},

	_regExpPhy: new RegExp(/^\s*([\d\.\-]+) (\w+): (.+)/),
	_regExpInfo1: new RegExp(/^([A-Z\d]+): (.+)/),
	_regExpInfo2: new RegExp(/^([\w\d]+) (.+)/),
	_regExpParams: new RegExp(/\s+|=|:/),
	_regExpIP: new RegExp(/^(\S+)\s+(\S+)\s+(.*)/),
	_regExpSDULen: new RegExp(/SDU_len=(\d+)/),
	_regExpSIPReq: new RegExp(/^(\S+) (.+)/),
	_regExpSIPResp: new RegExp(/^SIP\/2\.0 (\d+) (\S+) (.+)/),

	_logListParse: function (list) {
		var info;

		for (var i = 0, length = list.length; i < length; i++) {

			var log = list[i];
			var msg = log.msg;

			// Parse message
			switch (log.layer) {
			case "PHY":
				info = msg.match(this._regExpPhy);
				if (!info) {
					this.warn("Bad PHY log", log);
					break;
				}

				var dir = log.dir;
				log.frame	= parseFloat(info[1]);
				var channel = info[2];
				var msg		= log.msg = info[3];

				var rb_start = undefined;
				var rb_list  = undefined;
				var retx     = false;
				var harq     = -1;
                                var rb_p = undefined;
                                var rb_shift = undefined;

				// Parse arg=value list
				var args = msg.split(this._regExpParams);
				for (var m = 0, count = args.length; m < count;) {
					var param = args[m++];
					var value = args[m++];

					switch (param) {
					case 'n_prb':
					case 'l_crb':
						if (rb_start !== undefined) {
							if (!rb_list) rb_list = [];
							rb_list.push(rb_start, rb_start + (value - 0), 3);
						}
						break;

					case 'rb_start':
						rb_start = value - 0;
						break;
                                                
					case 'type':
					case 'ber':
					case 'ta':
					case 'ri':
					case 'const':
					case 'sequence_index':
						log[param] = value - 0;
						break;

					case 'snr':
						log['SNR_' + channel] = parseFloat(value);
						break;

					case 'format':
						log.format = value;
						break;

                                        case 'p':
                                            rb_p = value - 0;
                                            break;

                                        case 'shift':
                                            rb_shift = value - 0;
                                            break;
                                            
					case 'bitmap':
						var rb_count = this._params.cells[log.cell].n_rb_dl;
                                                var P, n_bits, bitmap, n;
                                                /* XXX: compute once */
						if (rb_count <= 10)
                                                    P = 1;
						else if (rb_count <= 26)
                                                    P = 2;
						else if (rb_count <= 63)
                                                    P = 3;
						else
                                                    P = 4;
                                                n_bits = Math.ceil(rb_count / P);
                                                bitmap = value - 0;

                                                if (rb_p !== undefined && rb_shift !== undefined) {
                                                    /* type 1 alloc */
                                                    var n_bits_1, P, j1, delta;
                                                    n_bits_1 = n_bits - 1;
                                                    if (P <= 2)
                                                        n_bits_1--;
                                                    else
                                                        n_bits_1 -= 2;
                                                    if (rb_shift) {
                                                        /* XXX: compute once */
                                                        delta = Math.floor((rb_count - 1) / (P * P)) * P;
                                                        j1 = Math.floor((rb_count - 1) / P) % P;
                                                        if (rb_p < j1)
                                                            delta += P;
                                                        else if (rb_p == j1)
                                                            delta += 1 + (rb_count - 1) % P;
                                                        delta -= n_bits_1;
                                                    } else {
                                                        delta = 0;
                                                    }
                                                    for (var j = 0; j < n_bits_1; j++) {
                                                        if (bitmap & (1 << (n_bits_1 - 1 - j))) {
                                                            if (!rb_list) rb_list = [];
                                                            j1 = j + delta;
                                                            n = Math.floor(j1 / P) * P * P + rb_p * P + (j1 % P);
                                                            rb_list.push(n, n + 1, 3);
                                                        }
                                                    }
                                                } else {
                                                    /* type 0 alloc */
                                                    for (var j = n_bits - 1, n = 0; n < rb_count; j--, n = next) {
							var next = n + P;
							if (bitmap & (1 << j)) {
                                                            if (!rb_list) rb_list = [];
                                                            rb_list.push(n, Math.min(next, rb_count), 3);
							}
                                                    }
                                                }
						break;

					case 'n':
						if (channel === 'PUCCH') {
							var params = this._params.cells[log.cell];
							if (!params) {
								console.log(this._params);
							}
							var n = value - 0;
							switch (log.format) {
							case '1':
							case '1A':
							case '1B':
								var c = params.cyclic_prefix ? 2 : 3;
								var mod  = (c * params.n_cs_an / params.delta_pucch_shift) | 0;
								var mod1 = (c * 12 / params.delta_pucch_shift) | 0;
								if (n < mod)
									n = params.n_rb_cqi;
								else
									n = (((n - mod) / mod1) | 0) + params.n_rb_cqi + (params.n_cs_an ? 1 : 0);
								break;
							case '2':
							case '2A':
							case '2B':
								n = (n / 12) | 0;
								break;
							case '3':
								n = (n / 5) | 0;
								break;
							default:
								n = 0;
								break;
							}
							var slot = n & 1;
							n = n >> 1;
							if (!rb_list) rb_list = [];
							rb_list.push(n, n + 1, slot ? 2 : 1, params.n_rb_ul - n - 1, params.n_rb_ul - n, slot ? 1 : 2);
						}
						break;

					case 'tb_len':
						var len = value >> 0;
						param = 'TB_LEN_' + dir;
						log[param] = (log[param] >> 0) + len;
						break;

					case 'sf':
						log.frame = parseFloat(value);
						break;

					case 'crc':
						log.crc = value === 'OK';
						break;

					case 'retx':
						log.retx = 1;
						retx = true;
						break;

					case 'cqi':
						log.cqi = parseInt(value, 2);
						break;

					case 'mcs':
						log['MCS_' + dir] = value - 0;
						break;

					case 'harq':
						harq = log.harq = value - 0;
						break;

					case 'n_rb_dl':
						var cell = this._params.cells[log.cell];
						if (!cell) cell = this._params.cells[log.cell] = {};
						cell.n_rb_dl = value - 0;
						cell.n_rb_ul = value - 0;
						break;
					}
				}
				if (isNaN(log.frame)) {
					log.frame = undefined;
				}
				if (rb_list) {
					log.rb_list = rb_list;
					if (!this._has_rb) {
						this._has_rb = true;
						lteLogs.refreshClientGrid();
					}
				}

				log.channel = log.info = lteLogs.string2id(channel);

				// Retransmission needed
				if (harq >= 0 && channel === 'PDSCH') {
					var id = harq + log.rnti * 8;
					if (retx) {
						var prev = this._lastHarq[id];
						if (prev) prev.error = true;
					} else  {
						this._lastHarq[id] = log;
					}
				}
				break;

			case 'RRC':
			case 'NAS':
				if (info = msg.match(this._regExpInfo1)) {
					log.info = lteLogs.string2id(info[1]);
					log.msg  = info[2];
				}
				break;

			case 'RLC':
			case 'PDCP':
				if (info = msg.match(this._regExpInfo2)) {
					log.info = lteLogs.string2id(info[1]);
					log.msg  = info[2];
				}
				break;

			case 'IP':
				if (info = msg.match(this._regExpIP)) {
					log.info = lteLogs.string2id(info.splice(2, 1)[0]);
					log.msg  = info.join(" ");
				}
				break;

			case 'MAC':
				var args = msg.split(this._regExpParams);
				var type = '';
				for (var m = 0, count = args.length; m < count;) {
					var param = args[m++];
					var value = args[m++];

					switch (param) {
					case 'ph':
						log.phr = value - 23;
						break;
					case 'b':
						switch (type) {
						case 'SBSR':
							log.ul_buffer_size = this._bsr_table[value];
							break;
						case 'LBSR':
							log.ul_buffer_size = this._bsr_table[value] + this._bsr_table[args[m++]] + this._bsr_table[args[m++]] + this._bsr_table[args[m++]];
							break;
						}
						break;
					case 'len':
						switch (type) {
						case 'PAD':
							log['MAC_PAD' + log.dir] = value - 0;
							break;
						}
						break;
					default:
						if (value === '')
							type = param;
						break;
					}
				}
				break;

			case 'GTPU':
				var sdu_len = msg.match(this._regExpSDULen);
				if (sdu_len) {
					log['SDU_LEN' + log.dir] = sdu_len[1] - 0;
				}
				break;

			case 'SIP':
				if (info = msg.match(this._regExpSIPResp)) {
					log.info = lteLogs.string2id(info[1]);
					log.msg = info[2] + ' from ' + info[3];
				} else if (info = msg.match(this._regExpSIPReq)) {
					log.info = lteLogs.string2id(info[1]);
					log.msg = info[2];
				}
				break;

			case 'S1AP':
			case 'X2AP':
			case 'COM':
				break;

			default:
				this.warn("Unknown layer", log.layer, msg);
				break;
			}

			log.id = globalLogId++;
			log.client = this;
			this._logs.push(log);
			this._logCount++;

		} /* End of list loop */
		if (length)
			lteLogs.updateLogs();
	},


	_bsr_table: [
		0,
		10,
		12,
		14,
		17,
		19,
		22,
		26,
		31,
		36,
		42,
		49,
		57,
		67,
		78,
		91,
		107,
		125,
		146,
		171,
		200,
		234,
		274,
		321,
		376,
		440,
		515,
		603,
		706,
		826,
		967,
		1132,
		1326,
		1552,
		1817,
		2127,
		2490,
		2915,
		3413,
		3995,
		4677,
		5476,
		6411,
		7505,
		8787,
		10287,
		12043,
		14099,
		16507,
		19325,
		22624,
		26487,
		31009,
		36304,
		42502,
		49759,
		58255,
		68201,
		79846,
		93479,
		109439,
		128125,
		150000,
		/* Note: we put a large enough values for +infinity, but not
		            so large to avoid overflows when doing additions of buffer
		            sizes */
		172000,
	]

});


Ext.define("lte.client.url", {

	extend: 'lte.client',

	constructor: function (config) {
		this.callParent(arguments);
		this._info = config.url;
	},

	start: function () {

		this._setState("loading");

		var url = this.config.url + "?nocache=" + (new Date() - 0);
		lteLogs.load(true);

		var remaining = null;
		lteLogs.httpDowload(url, (function (text, eof) {

			// Error
			if (!text) {
				this._setState("error");
				lteLogs.load(false);
				return false;
			}

			var lines = text.split(/[\r\n]/);

			if (remaining)
				lines[0] = remaining + lines[0];

			if (!eof)
				remaining = lines.pop();

			this.textLogsAdd(lines);

			if (this._logCount >= MAX_LOGS) {
				this._setState("start");
				lteLogs.load(false);
				return false;
			}

			if (eof) {
				this._setState("start");
				lteLogs.load(false);
			}

			return true;

		}).bind(this));
	},

	getUrl: function () {
		return this.config.url;
	},

	setUrl: function (url) {
		if (this.config.url !== url) {
			this.config.url = url;
			if (this.config.enabled) {
				this.stop();
				this.start();
			}
		}
	},

	isConfigurable: function () {
		return !this.config.locked;
	},

	logCellContextMenu: function (log, cb) {

		var items = [];

		if (typeof log.const === 'number') {
			items.push({
				text: "Get constellation",
				iconCls: 'icon-star',
				scope: this,
				handler: function() {

					Ext.Ajax.request({
						url: this.config.url + ".bin/const_" + lteLogs.padLeft(log.const, "0", 6) + ".bin?nocache=" + (new Date() * 1),
						scope: this,
						binary: true,
						success: function(response, opts) {
							if (response.responseBytes) {
								log.const = new Int8Array(response.responseBytes);
							} else {
								log.const = null;
							}
							if (cb)
								cb();
						},
						failure: function(response, opts) {
							Ext.Msg.alert(this.config.name, "Can't load constellation");
						}
					});
				}
			});
		}
		return items;
	},

});

/*
 * Down load by chunk
 * cb(<chunk: text>, <end of file: boolean>)
 */
lteLogs.httpDowload = function (url, cb) {

	var chunkSize = 100000000;

	// First HEAD request
	var xhr = new XMLHttpRequest();
	xhr.open("HEAD", url);
	//xhr.setRequestHeader("Range", "bytes=0-");
	xhr.onreadystatechange = function () {

		if (xhr.readyState !== 4) return;

		if (xhr.status < 200 || xhr.status >= 300) {
			lteLogs.error("Can't load", url);
			return cb(null, true);
		}

		var length = xhr.getResponseHeader("content-length") - 0;
		if (!length) {
			var range = xhr.getResponseHeader("Accept-Ranges");
			if (!range || !range.match(/bytes/)) {

				lteLogs.warn("File does not accept chunk load0", url);
				var oneshot = true;
			}
		} else if (length <= chunkSize) {
			oneshot = true;
		}

		if (oneshot) {
			lteLogs.debug("Download oneshot", url);
			xhr = new XMLHttpRequest();
			xhr.open("GET", url);
			xhr.onreadystatechange = function () {
				if (xhr.readyState !== 4) return;
				cb(xhr.responseText, true);
				xhr = null;
			}
			xhr.send();
			return;
		}

		var position = 0;
		var data = "";
		var dlChunk = function () {

			var xhr = new XMLHttpRequest();
			xhr.open("GET", url);

			// Set range
			var to = Math.min(length || Infinity, position + chunkSize) - 1;
			xhr.setRequestHeader("Range", "bytes=" + position + "-" + to);

			lteLogs.debug("Download chunk", position, to);
			xhr.onreadystatechange = function () {
				if (xhr.readyState !== 4) return;

				var range = xhr.getResponseHeader("Content-Range");
				if (range && (range = range.match(/(\d+)-(\d+)\/(\d+)/))) {

					if (!length) length = range[3] - 0;

					var l = range[2] - range[1] + 1;

					position += l;
					if (position < length) {
						if (!cb(xhr.responseText, false)) {
							xhr = null;
							return;
						}
						return dlChunk();
					}
				}
				cb(xhr.responseText, true);
				xhr = null;
			}
			xhr.send();
		};
		dlChunk();
	}
	xhr.send();
};


Ext.define("lte.client.file", {

	extend: 'lte.client',

	constructor: function (config) {
		this.callParent(arguments);
		this._info = config.file.name + " (" + config.file.size + "B)";
	},

	start: function () {

		this._setState("loading");

		var file = this.config.file;
		if (file) {
			lteLogs.load(true);
			var reader = new window.FileReader();
			reader.onload = (function fileRead(e) {
				var bb = reader.result;

				if (bb) {
					var tmp = "";

					for (var i = 0, length = bb.byteLength; i < length;) {

						var size = Math.min(length - i, 200000000);
						var chunk = (new Int8Array(bb)).subarray(i, i + size);

						var text = tmp + (new TextDecoder()).decode(chunk);

						i += size;
						var lines = text.split(/[\r\n]/);
						if (i < length)
							tmp = lines.pop();
						this.textLogsAdd(lines);
					}

					this._setState("start");
				} else {
					this._setState("error");
				}
				lteLogs.load(false);
			}).bind(this);

			//reader.readAsText(file);
			reader.readAsArrayBuffer(file);
		}
	}
});



Ext.define("lte.client.server", {

	extend: 'lte.client',

	constructor: function (config) {
		this.callParent(arguments);
		this._info = config.address;
		this._msgQueue = {};
		this._msgFifo = [];
		this._msgHandler = {};
	},

	_msgId: 0,

	_msgBatchSize: 100,

	getIcon: function () {
		return {
			UE: 'icon-ue',
			ENB: 'icon-air',
			MME: 'icon-server',
			IMS: 'icon-server',
		}[this.config.model];
	},

	start: function () {
		this._setState("connecting");
		try {
			var socket = new WebSocket('ws://' + this.config.address);
		} catch (e) {
		};

		socket.onopen    = Ext.Function.bind(this._onSocketOpen, this, [socket], 0);
		socket.onclose   = Ext.Function.bind(this._onSocketClose, this, [socket], 0);
		socket.onmessage = Ext.Function.bind(this._onSocketMessage, this, [socket], 0);
		socket.onerror   = Ext.Function.bind(this._onSocketError, this, [socket], 0);
		
		socket.binaryType = 'arraybuffer';

		this.addComponent("socket", socket);
		lteLogs.refreshClientGrid();
	},

	resetLogs: function () {
		this.sendMessage({message: 'log_reset'}, function (resp) {
			this._reset();
		});
	},

	stop: function () {
		this._setState("stop");
		this._stopTimers();
	},

	_stopTimers: function () {
		if (this._reconnnectTimer) {
			this.debug("Stop reconnection timer");
			clearTimeout(this._reconnnectTimer);
			this._reconnnectTimer = null;
		}
		if (this._statsTimer) {
			clearTimeout(this._statsTimer);
			this._statsTimer = 0;
			this._resetStats();
		}
		if (this._msgDeferTimer) {
			clearTimeout(this._msgDeferTimer);
			this._msgDeferTimer = 0;
		}
	},

	_resetStats: function () {
		lteStats.setStats(this.getName(), {cpu: {global: 0}});
	},

	isPaused: function () {
		return !!this.config.pause;
	},

	isRealTime: function () {
		return true;
	},

	isConfigurable: function () {
		return true;
	},

	// Toggle play/pause
	playPause: function () {
		if (this.config.pause) {
			this.config.pause = false;
			if (this.getState() === "connected")
				this._logGet();
		} else {
			this.config.pause = true;
		}

		lteLogs.saveConfig();
	},

	getAddress: function () {
		return this.config.address;
	},

	setAddress: function (address) {
		if (this.config.address !== address) {
			this.config.address = address;
			if (this.config.enabled) {
				this.stop();
				this.start();
			}
		}
	},

	getUpdateLogMethod: function (filter) {

		if (!this.getState() === "connected")
			return null;

		return (function () {
			this._logGet(lteLogs.merge({
				min: 0,
				max: 8192,
			}, filter));
		}).bind(this);
	},

	logCellContextMenu: function (log, cb) {

		var items = [];

		if (!this.getState() === "connected")
			return items;

		if (typeof log.const === 'number') {
			items.push({
				text: "Get constellation",
				iconCls: 'icon-star',
				scope: this,
				handler: function() {
					this.sendMessage({message: 'log_bin_get', type: 'const', idx: log.const}, function (resp) {

						if (resp.__binary__) {
							log.const = new Int8Array(resp.__binary__.shift());
						} else {
							log.const = null;
						}
						if (cb)
							cb();
					});
				}
			});
		}
		return items;
	},

	_logGet: function (params) {

		var config = this.config;
		if (config.pause)
			return;

		if (!params) {
			var layers = {};
			Object.keys(config.logs.layers).forEach(function (l) {
				layers[l] = config.logs.layers[l].filter;
			});
			params = {
				timeout: 1,
				min: 64,
				max: 2048,
				layers: layers
			};
		}
		params.message = 'log_get';

		this._logGetId = this.sendMessage(params,
			(function (msg) {

				var count = this._logCount;

				if (msg.discontinuity)
					this.warn("Discontinuity in logs", msg.discontinuity);

				var logs = msg.logs;
				if (logs) {
					this.info("Logs received", logs.length);
					if (logs instanceof Array) {
						for (var i = 0, length = logs.length; i < length; i++) {
							var log = logs[i];
							log.msg = log.data.shift();
							if (!log.data.length) log.data = undefined;
							log.dir = this._dirConverter[log.dir] | 0;
						}
						this._logListParse(logs);
					}
				}

				if (!count && this._logCount)
					lteLogs.refreshClientGrid();

				// Update only if last request
				if (this._logGetId === msg.message_id)
					this._logGet();

			}).bind(this)
		);
	},

	sendMessageList: function (msg, cb) {

		var length = msg.length;
		var recv   = [];

		var cbs = function (index, resp, id) {
			recv[index] = resp;
			if (!resp.notification)
				length--;

			cb(recv, resp, index, !length);
		}

		for (var i = 0; i < length; i++) {
			recv[i] = null;
			this.sendMessage(msg[i], cbs.bind(this, i));
		}
	},

	// cb(resp, message_id)
	sendMessage: function (msg, cb) {

		// Check
		var socket = this.getComponent("socket");
		if (!socket || socket.readyState !== socket.OPEN) return;
		if (!msg) return;
		if (typeof cb !== 'function') cb = null;

		var id = msg.message_id = ++this._msgId;
		if (cb)
			this._msgQueue[id] = cb;

		if (this._msgDeferTimer) {
			clearTimeout(this._msgDeferTimer);
			this._msgDeferTimer = 0;
		}

		this.debug(this._info, "Send message", msg);
		if (this._msgFifo.push(msg) < this._msgBatchSize) {
			this._msgDeferTimer = Ext.Function.defer(this._sendMessageNow, 1, this);
		} else {
			this._sendMessageNow();
		}
		return id;
	},

	_sendMessageNow: function () {

		if (this._msgFifo.length === 1) {
			var msg = JSON.stringify(this._msgFifo.shift());
		} else {
			var msg = JSON.stringify(this._msgFifo);
			this._msgFifo.length = 0;
		}
		this.debug("Send message", msg);
		this.getComponent("socket").send(msg);
		this._msgDeferTimer = 0;
	},

	getLogsConfig: function() {
		return this.config.logs;
	},

	setLogsConfig(config, save) {

		var myConfig = this.config.logs;
		var logs = {count: config.count, layers: {}};

		Object.keys(config.layers).forEach(function (l) {
			logs.layers[l] = {level: config.layers[l].level, max_size: config.layers[l].max_size};
		});

		this.sendMessage({message: 'config_set', logs: logs}, function (msg) {

			if (save) {
				lteLogs.merge(myConfig, config, true);
				lteLogs.saveConfig();
				this._logGet();
			}
		});
	},

	_onSocketOpen: function (socket) {
		this.info('Connection open: ' + this.config.name);

		this._stopTimers();
		this._msgFifo.length = 0;

		var logConfig = this.config.logConfig;
		if (logConfig) {
			this.sendMessage({message: 'config_set', logs: logConfig}, function (msg) {
			});
		}

		/* Get config */
		this.sendMessage({message: 'config_get'}, function (config) {

			this.info("Config received");

			this._reset();

			// Store client config
			var myConfig = this.config;
			var firstCon	= !myConfig.logs;
			myConfig.logs	= lteLogs.merge(myConfig.logs || {}, config.logs);
			this._name		= config.name;
			this.setModel(config.type);

			// Default filtered config
			var layers = myConfig.logs.layers;
			Object.keys(layers).forEach(function (l) {
				if (layers[l].filter === undefined) {
					switch (l) {
					case 'NAS':
					case 'RRC':
						layers[l].filter = 'debug';
						break;
					default:
						layers[l].filter = 'warn';
						break;
					}
				}
			});

			if (config.profiling)
				this._profilingAvailable = true;

			this.setLogsConfig(myConfig.logs, false);
			this._logGet();

			var tab = this._openMainTab(config);

			if (tab.setClientConfig)
				tab.setClientConfig(config);
			
			this._params.cells = config.cells || {};

			this._setState("connected");

			if (firstCon)
				Ext.create('lte.client.config', {
					client: this,
					title: 'Please configure logs',
					firstConnection: true,
				}).show();
		});
	},

	_onSocketClose: function (socket, event) {
		this.info("Close socket");

		var curSocket = this.getComponent("socket");

		if (curSocket === socket) {
			lteLogs.refreshClientGrid();
			this._stopTimers();
			this.closeComponents();
			curSocket = null;
		} else {
			this.warn("Close deffered");
		}

		if (!curSocket && this.config.enabled) {
			this.debug("Start reconnection timer");
			if (this.getState() !== "stop")
				this._setState("error");
			this._reconnnectTimer = setTimeout(this.start.bind(this), 15000);
		}
	},

	_onSocketError: function (socket, event) {
		this._setState("error");
		this.warn(event);
	},

	_onSocketMessage: function (socket, event) {

		// Parse message
		try {
			var data = event.data;
			if (data instanceof ArrayBuffer) {
				var list = [];
				for (var i = 0; i < data.byteLength;) {
					var len = (new Int32Array(data.slice(i,i+4)))[0];
					list.push(data.slice(i+4,i+4+len));
					i += 4 + len;
				}
				var msg = JSON.parse(String.fromCharCode.apply(null, new Int8Array(list.shift())));
				msg.__binary__ = list;

			} else {
				var msg = JSON.parse(data);
			}

			if (msg.error) {
				Ext.Msg.alert(this.config.name, msg.error);
				return;
			}
		} catch (e) {
			this.error("JSON error", e, event, event.data);
			return;
		}

		// Check message handler by id
		var id = msg.message_id;
		var cb = this._msgQueue[id];
		if (cb) {
			// Delete if not progress message
			if (!msg.notification)
				delete this._msgQueue[id];
			this.debug("Response received", id, msg);
			return cb.call(this, msg, id);
		}

		// Check message handler by name
		var name = msg.message;
		var handler = this._msgHandler[name];
		if (handler)
			return handler.call(this, msg);

		switch (name) {
			case "ue_update":
				break;

			default:
				this.error("Unknown message", name, msg);
				break;
		}
	},

	_openMainTab: function () {

		if (!this.config.model) return;

		// Already instanciated ?
		if (this.getComponent("mainTab"))
			return;

		lteLogs.client = this;
		
		var buttons = [];

		var refreshButton = Ext.create('Ext.Button', {
			text: 'Refresh',
			scope: this,
			iconCls: 'icon-refresh',
			handler: function() { tab.lteUpdate(); }
		});
		buttons.push(refreshButton);

		var tab = Ext.create('lte.' + this.config.model.toLowerCase() + '.tab', {
			'title': this.config.name,
			'iconCls': this.getIcon(),
			'client': this,
			'tbar': Ext.create('Ext.toolbar.Toolbar', {items: buttons}),
		});
		lteLogs.addTab(tab);

		this.addComponent("mainTab", tab);

		this._updateStats(true);
		return tab;
	},

	_updateStats: function (first) {
		
		this.sendMessage({message: 'stats'}, (function (resp) {

			var tab = this.getComponent("mainTab");
			if (!tab) return;

			// Schedule next
			this._statsTimer = Ext.Function.defer(this._updateStats, 500, this);

			// First call will reset stats
			if (first) {
				this._resetStats();
				return;
			}

			this.sendEvent({type: 'stats', data: resp});

			lteStats.setStats(this.getName(), resp);

		}).bind(this));
	},

	profileReset: function () {
		if (this._profilingAvailable)
			this.sendMessage({message: 'prof_reset'}, function () {});
	},
	profileDump: function () {
		if (this._profilingAvailable)
			this.sendMessage({message: 'prof_dump'}, function () {});
	},
});






