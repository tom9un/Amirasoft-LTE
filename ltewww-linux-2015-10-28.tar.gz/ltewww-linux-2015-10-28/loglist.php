<?php
/*
 * Copyright (C) 2012-2014 Amarisoft
 *
 * Amarisoft LTE Web interface 2015-10-28
 */

function FileCmp($a, $b)
{
    if ($a->type == $b->type) {
        return $a->name < $b->name ? -1 : 1;
    }
    if ($a->type == 'url')
        return 1;

    return -1;
}

function Parse(&$node, $name, $file, $url)
{
    if (!file_exists($file))
        return false;

    if (is_dir($file)) {
        $dh  = opendir($file);
        if (!$dh)
            return false;

        $list = array();
        while (false !== ($subfile = readdir($dh))) {
            if ($subfile[0] != ".") {
                Parse($list, $subfile, $file . "/" . $subfile, $url . "/" . $subfile);
            }
        }

        if (count($list) > 0) {
            $obj = new stdClass;
            $obj->name = $name;
            $obj->type = 'folder';
            $obj->list = $list;
            #echo $file.":\n".json_encode($obj, JSON_PRETTY_PRINT);
            $node[] = $obj;
        }

    # File
    } else {
        $obj = new stdClass;
        $obj->name = $name;
        $obj->url  = $url;
        $obj->type = 'url';
        $obj->locked = true;
        $node[] = $obj;
    }

    usort($node, "FileCmp");

    return true;
}

$logs = array();

$live = new stdClass;
$live->name = "Live";
$live->type = "live";
$live->list = array();
Parse($live->list, "mme.log", "/tmp/mme.log", "live/mme.log");
Parse($live->list, "enb0.log", "/tmp/enb0.log", "live/enb0.log");
Parse($live->list, "ue0.log", "/tmp/ue0.log", "live/ue0.log");
$logs[] = $live;

Parse($logs, "Backup", "backup", "backup");
Parse($logs, "Store", "store", "store");

echo json_encode($logs);
#echo json_encode($logs, JSON_PRETTY_PRINT);

?>


