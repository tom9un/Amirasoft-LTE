
Ext.define("lte.graph", {

	extend: 'Ext.panel.Panel',
	layout: 'border',

	items: [{
		region: 'center',
		layout: 'fit',
		border: 0,
		html: '<canvas></canvas>',
	}],

	seriesSide: 'west',

	constructor: function (config) {
		this.callParent(arguments);

		this._lockCount = 1;

		this.graph = new Graph(Ext.Object.merge({x: {}, y:{}}, config.graph));
		this.graph.onOver = this.onOver.bind(this);
		this.graph.title = this.title;

		for (i in config.graph.series) {
			this._addSerie(i, config.graph.series[i]);
		}
	},

	initComponent: function () {
		this.callParent(arguments);

		var serieStore = this._serieStore = Ext.create('Ext.data.Store', {
			fields: ['config', 'on', 'serieId'],
			data: []
		});

		var serieGrid = this._serieGrid = Ext.create('Ext.grid.Panel', {
			store: serieStore,
			padding: 10,
			border: 0,
			bodyStyle: {
				background: '#f0f0f0',
			},
			viewConfig:{
				markDirty: false
			},
			width: '100%',
			hideHeaders: true,
			columns: [{
				dataIndex: 'config',
				flex: 1,
				width: '100%',
				scope: this,
				renderer: function(config, metaData, record, rowIndex, colIndex, store, view) {
					var id = record.get('serieId');
					var color = record.get('on') ? this.graph.getSerieColor(id) : '#f0f0f0';
					metaData.style = 'background-color: ' + color + '; font-weight: bold;';
					return config.title || id;
				}
			}],
			listeners: {
				scope: this,
				cellclick: function(grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
					var id = record.get('serieId');
					var on = record.get('on');
					on = !on;
					record.set('on', on);
					this.graph.setSerie(id, on);
					this.update();
				}
			}
		});

		this.add({
			region: this.seriesSide,
			layout: 'fit',
			width: 250,
			bodyStyle: {
				background: '#f0f0f0',
			},
			border: 0,
			items: [serieGrid],
		});
	},

	onOver: function (id, value, info, posX, posY) {
		
		if (id) {
			var serie = this._serieStore.findRecord('serieId', id);
			if (!serie) return;

			this._tooltip.update(lteLogs.tooltip(info.title + '<br/><b>' + info.y + '</b> at ' + info.x));
			this._tooltip.show([posX + 10, posY + 10]);
		} else {
			this._tooltip.hide();
		};
		if (this.graph.highlight(value))
			this.update();
	},

	listeners: {
		resize: function (container) {
			var canvas = this._canvas;
			if (!this._canvas) {
				canvas = this._canvas = this.el.down("canvas").dom;
				this._tooltip = Ext.create('Ext.tip.ToolTip', {
					target: canvas,
					trackMouse: false,
					autoHide: false,
				});
				canvas.addEventListener(lteLogs.getMouseWheelEvent(), this._mouseWheelEvent.bind(this), false);
				canvas.addEventListener("mousedown", this._mouseDownEvent.bind(this), false);
				canvas.addEventListener("mousemove", this._mouseMoveEvent.bind(this), false);
				canvas.addEventListener("mouseout", this._mouseOutEvent.bind(this), false);
				canvas.addEventListener("mouseup", this._mouseUpEvent.bind(this), false);
			}
			var width = canvas.parentNode.clientWidth;
			var height = canvas.parentNode.clientHeight;
			canvas.width  = width;
			canvas.height = height;
			this.update();
		},
		activate: function () {
			this.unlock();
		},

		deactivate: function() {
			this.lock();
		},
	},

	addSerie: function (id, cfg) {

		if (this.graph.addSerie(id, cfg)) {
			this._addSerie(id, cfg);
		}
	},

	_addSerie: function (id, cfg) {
		this._serieStore.add([{config: cfg, on: cfg.enabled !== false, serieId: id}]);
	},

	addValues: function (id, values) {
		if (this.graph.addValues(id, values)) {
			if (!this._lockCount)
				this.update();
			return true;
		}
		return false;
	},

	lock: function () {
		this._lockCount++;
	},

	unlock: function () {
		if (!--this._lockCount) {
			this.update();
		}
	},

	update: function () {
		if (!this._updateTimer) {
			this._updateTimer = setTimeout((function () {
				this._updateTimer = 0;

				var canvas = this._canvas;
				if (canvas)
					this.graph.draw(canvas, 0, 0, canvas.width, canvas.height);

			}).bind(this), 100);
		}
	},

	_mouseWheelEvent:	function (event) { if (this.graph.mouseWheelEvent(event)) this.update(); },
	_mouseDownEvent:	function (event) { this.graph.mouseDownEvent(event); },
	_mouseMoveEvent:	function (event) { if (this.graph.mouseMoveEvent(event)) this.update(); },
	_mouseUpEvent:		function (event) { this.graph.mouseUpEvent(event); },
	_mouseOutEvent:		function (event) { this.graph.mouseOutEvent(event); },

});






var Graph = function (config)
{
	if (!config)
		config = {};

	this._series		= {};
	this._seriesList	= [];
	this._margin		= Ext.Object.merge({
		top: 10,
		bottom: 70,
		left: 70,
		right: 10
	}, config.margin);

	// Axis
	var axisCfg = Ext.Object.merge({x: {}, y: {}}, config.axis);
	this._axis = {};
	for (var i in axisCfg) {
		this._axis[i] = {_default: axisCfg[i]};
	}
	this._yAxisName = config.y;

	this.reset();

	for (var i in this._axis) {
		this._updateAxis(this._axis[i], 0, 100);
	}

	for (var id in config.series) {
		this.addSerie(id, config.series[id]);
	}

	if (config.onOver) this.onOver = config.onOver;
}

Graph.prototype.reset = function ()
{
	var axis = this._axis;

	for (var i in axis) {
		var cfg = axis[i]._default;

		var a = axis[i] = {
			from:		cfg.hasOwnProperty('min') ? cfg.min : 0,
			to:			cfg.hasOwnProperty('max') ? cfg.max : 0,
			min:		Number.NEGATIVE_INFINITY,
			max:		Number.POSITIVE_INFINITY,
			stepFrac:	10,
			stepMin:	50,
			auto:		'fit',
			grad:		true,
			unit:		'',
			n_series:	0,
			name:		i
		};

		for (var j in a) {
			if (cfg.hasOwnProperty(j))
				a[j] = cfg[j];
		}
		a.count = 0;
		a._default = cfg;

		if (!cfg.hasOwnProperty('min')) a.min = a.from;
		if (!cfg.hasOwnProperty('max')) a.max = a.to;
	}

	for (var i in this._series) {
		var s = this._series[i];
		s.values = [];
		if (s.enabled) s.y.n_series++;
		s.x = axis[s.x.name];
		s.y = axis[s.y.name];
	}

	this._yAxis = axis[this._yAxisName] || axis.y;
};

Graph.prototype._addToAxis = function (a, v) {

	switch (a.auto) {
	case 'fit':
		if (!a.count++) {
			a.min = a.from = Math.min(
				a._default.hasOwnProperty('min') ? a.min : Number.POSITIVE_INFINITY,
				a._default.hasOwnProperty('from') ? a.from : Number.POSITIVE_INFINITY,
				v);
			a.max = a.to = Math.max(
				a._default.hasOwnProperty('max') ? a.max : Number.NEGATIVE_INFINITY,
				a._default.hasOwnProperty('to') ? a.to : Number.NEGATIVE_INFINITY,
				v);
		} else {
			a.min = a.from = Math.min(v, a.min);
			a.max = a.to   = Math.max(v, a.max);
		}
		break;

	case 'max':
		if (a.to === a.max && v > a.to) {
			a.from += v - a.to;
			a.to = a.max = v;
		}
		break;

	case 'min':
		if (a.from === a.min && v < a.from) {
			a.to += v - a.from;
			a.from = a.min = v;
		}
		break;
	}
};

Graph.prototype._updateAxis = function (a, offset, size)
{
	switch (a.auto) {
	case 'fit':
		if (a.to > a.max) a.max = a.to;
		if (a.from < a.min) a.min = a.from;
		break;
	case 'max':
		var diff = a.to - a.max;
		if (diff > 0) {
			a.from += diff;
			a.max = a.to;
		}
		a.from = Math.max(a.from, a.min);
		break;
	case 'min':
		// XXX
		break;
	default:
		var len = Math.min(a.to - a.from, a.max - a.min);
		var diff = a.min - a.from;
		if (diff > 0) {
			a.from += diff;
		} else {
			diff = a.to - a.max;
			if (diff > 0)
				a.from -= diff;
		}
		a.to = a.from + len;
		break;
	}

	// Window size
	var len = a.to - a.from;
	if (!len)
		len = a.to || 1;

	// Compute step
	var step = Math.pow(10, Math.floor(Math.log(len) / Math.log(10))) / a.stepFrac;

	var to   = a.to + step;
	var from = Math.floor(a.from / step) * step;
	var to   = Math.ceil(a.to / step) * step;

	if (to === from) {
		from -= step;
		to += step;
	}

	var scale = size / (to - from);

	a.graph = {
		scale:	scale, // From unit to pixels

		// In pixels
		size:	size,
		offset: offset,
		step:	Math.ceil(a.stepMin / scale / step) * step,

		// In axis unit
		from:	from,
		to:		to,
	};
};


Graph.prototype.addValues = function (id, values) {

	var s = this._series[id];
	if (!s) return false;

	// Shortcuts
	var ax = s.x;
	var ay = s.y;
	var sValues = s.values;

	for (var i = 0; i < values.length; i++) {
		var value = values[i];

		// XXX: check sort
		sValues.push(value);

		this._addToAxis(ax, value.x);
		this._addToAxis(ay, value.y);
	}
	return true;
};

Graph.prototype._axisFormat = function (v, unit)
{
	switch (unit) {
	case 'time':
		var h = Math.floor(v / 3600000);
		v -= h * 3600000;
		var m = Math.floor(v / 60000);
		v -= m * 60000;
		var s = Math.floor(v / 1000);
		v -= s * 1000;
		return ("0" + h).slice(-2) + ":" +
				("0" + m).slice(-2) + ":" +
				("0" + s).slice(-2) + "." +
				("00" + v).slice(-3);

	case 'date':
		v = new Date(v);
		return ("0" + v.getHours()).slice(-2) + ":" +
				("0" + v.getMinutes()).slice(-2) + ":" +
				("0" + v.getSeconds()).slice(-2) + "." +
				("00" + v.getMilliseconds()).slice(-3);

	case 'Brate':
		v *= 8;
		// Fallthrough

	case 'brate':
		if (v > 1e6) return ((v / 1e6).toPrecision(3) - 0) + "Mbps";
		if (v > 1e3) return ((v / 1e3).toPrecision(3) - 0) + "Kbps";
		return (v.toPrecision(3) - 0) + "bps";

	case 'bsize':
		v /= 8;
		// Fallthrough

	case 'Bsize':
		if (v > 1e6) return ((v / 1e6).toPrecision(3) - 0) + "MB";
		if (v > 1e3) return ((v / 1e3).toPrecision(3) - 0) + "KB";
		return (v.toPrecision(3) - 0) + "B";
	}
	return (v.toPrecision(2) - 0) + unit;
}


Graph.prototype._axisRender = function (ctx, axis, v)
{
	var value = this._axisFormat(v, axis.unit);

	switch (axis.unit) {
	case 'time':
	case 'date':
		ctx.rotate(Math.PI / 4);
		ctx.textBaseline	= 'top';
		ctx.textAlign		= 'left';
		ctx.fillText(value, 0, 0);
		break;
	default:
		ctx.fillText(value, 0, 0);
		break;
	}
}

Graph.prototype._defaultColorIndex = 0;
Graph.prototype._defaultColor = [
	'#ff0000',
	'#00ff00',
	'#00C0ff',
	'#ffc000',
	'#4040ff',
	'#ff00ff',
	'#808080',
	'#008000',
	'#00ffc0',
	'#c0ff00',
];

Graph.prototype.addSerie = function (id, config)
{
	var s = this._series[id];
	if (!s) {
		s = Ext.Object.merge({
			values: [],
			id: id,
			enabled: true,
			size: 2,
			x: 'x',
			y: 'y'
		}, config);

		if (!s.color) s.color = this._defaultColor[this._defaultColorIndex++];
		s.x = this._axis[s.x];
		s.y = this._axis[s.y];

		if (!s.x || !s.y) {
			return false;
		}

		if (s.enabled) s.y.n_series++;

		this._series[id] = s;
		this._seriesList.push(s);
		return true;
	}

	var values = config.values;
	if (values)
		this.addValues(id, values);
	return false;
};

Graph.prototype.getSerieColor = function(id)
{
	return this._series[id].color;
}

Graph.prototype.getSerieTitle = function(id)
{
	return this._series[id].title;
}


Graph.prototype.setSerie = function (id, enabled)
{
	var s = this._series[id];
	if (s && s.enabled !== enabled) {
		s.enabled = enabled;
		if (enabled) s.y.n_series++;
		else         s.y.n_series--;
		return true;
	}
	return false;
};

Graph.prototype._setWindow = function (a, from, len)
{
	if (!len) len = a.to - a.from;
	else      len = Math.min(len, a.max - a.min);

	if (from < a.min) {
		from = a.min;
	} else {
		var to = from + len;
		if (to > a.max)
			from = a.max - len;
	}
	a.from = from;
	a.to   = from + len;
};

Graph.prototype.getValues = function (id)
{
	return this._series[id].values.slice();
}

Graph.prototype._bgColor = '#f0f0f0';
Graph.prototype._gridColor = '#ffffff';


/************
 *** Draw ***
 ************/
Graph.prototype.draw = function (canvas, cx, cy, cw, ch)
{
	if (!canvas)
		return false;

	var t0 = new Date();

	var ax = this._axis.x;
	var ay = this._yAxis;
	if (!this._yAxis.n_series) {
		for (var i in this._axis) {
			if (this._axis[i].n_series > 0) {
				ay = this._axis[i];
				break;
			}
		}
	}

	// Graph rectangle
	var margin = this._margin;
	var width = cw - margin.left - margin.right;
	var height = ch - margin.top - margin.bottom;

	// Update all axis
	for (var i in this._axis) {
		if (i === 'x')
			this._updateAxis(ax, cx, width);
		else
			this._updateAxis(this._axis[i], cy, height);
	}

	var graphX = ax.graph;
	var graphY = ay.graph;

	// Coordinates
	var x0		= graphX.from;
	var x1		= graphX.to;
	var sW		= graphX.scale;
	var stepX	= graphX.step;
	var xr		= ax.renderer;

	var y0		= graphY.from;
	var y1		= graphY.to;
	var sH		= graphY.scale;
	var stepY	= graphY.step;
	var yr		= ay.renderer;

	var setX = function (x) { return (x - x0) * sW; };
	var setY = function (y) { return height - (y - y0) * sH; };

	var ctx = canvas.getContext("2d");

	// Clear and place
	ctx.save();
	ctx.lineWidth = 1;
	ctx.beginPath();
	ctx.rect(cx, cy, cw, ch);
	ctx.fillStyle = this._bgColor;
	ctx.fillRect(cx, cy, cw, ch);
	ctx.clip();

	ctx.translate(cx + margin.left + 0.5, cy + margin.top + 0.5);

	// Grid
	ctx.fillStyle		= 'black';
	ctx.textBaseline	= 'top';
	ctx.textAlign		= 'center';
	ctx.strokeStyle		= this._gridColor;
	for (var x = Math.ceil(x0 / stepX) * stepX; x < x1; x += stepX) {
		var myX = Math.round(setX(x));
		ctx.beginPath();
		ctx.moveTo(myX, 0);
		ctx.lineTo(myX, height);
		ctx.stroke();
		if (ax.grad) {
			ctx.save();
			ctx.translate(myX, height + 5);
			this._axisRender(ctx, ax, x);
			ctx.restore();
		}

	}
	ctx.textBaseline	= 'middle';
	ctx.textAlign		= 'right';
	ctx.strokeStyle		= this._gridColor;
	for (var y = Math.ceil(y0 / stepY) * stepY; y <= y1; y += stepY) {
		var myY = Math.round(setY(y));
		ctx.beginPath();
		ctx.moveTo(0, myY);
		ctx.lineTo(width, myY);
		ctx.stroke();
		if (ay.grad) {
			ctx.save();
			ctx.translate(-5, myY);
			this._axisRender(ctx, ay, y);
			ctx.restore();
		}
	}

	// Frame
	ctx.beginPath();
	ctx.strokeStyle = 'black';
	ctx.rect(0, 0, width, height);
	ctx.stroke();
	ctx.clip();

	// Highlight
	var hlValue = this._highlightedValue;
	var hlSerie = null;

	// Series
	for (var s = 0, length = this._seriesList.length; s < length; s++) {
		var serie  = this._seriesList[s];
		var values = serie.values;
		if (!serie.enabled) continue;
		if (!values.length) continue;

		ctx.beginPath();
		ctx.lineWidth	= serie.size;
		ctx.strokeStyle	= serie.color;
		var firstValue	= null;

		// Move to first value
		for (var i = 0; i < values.length; i++) {
			var value = values[i];
			var x = value.x;

			if (x > x0)
				break;
			firstValue = value;
		}
		if (!firstValue) {
			firstValue = values[0];
		}

		/* Use axis */
		var axis = serie.y;
		ctx.moveTo(setX(firstValue.x), height - this._setY(axis, firstValue.y));

		if (hlValue === firstValue)
			hlSerie = serie;

		// Draw lines
		for (;i < values.length; i++) {
			var value = values[i];
			var x = value.x;
			ctx.lineTo(setX(x), height - this._setY(axis, value.y));

			if (hlValue === value)
				hlSerie = serie;

			if (x > x1)
				break;
		}
		ctx.stroke();
	}

	if (hlSerie) {
		ctx.beginPath();
		ctx.arc(setX(hlValue.x), height - this._setY(hlSerie.y, hlValue.y), 3, 0, 2 * Math.PI, false);
		ctx.fillStyle = hlSerie.color;
		ctx.fill();
		ctx.lineWidth = 1;
		ctx.strokeStyle = '#000000';
		ctx.stroke();
	}

	ctx.restore();

	t0 = new Date() - t0;
	if (t0 > 500)
		console.log("Render", this.title, t0);
	return true;
};

Graph.prototype._setY = function(a, v)
{
	return (v - a.graph.from) * a.graph.scale;
}

Graph.prototype._eventToPosition = function (event)
{
	var rect = event.target.getBoundingClientRect();

	var ax = this._axis.x;
	var ay = this._axis.y;
	var m  = this._margin;
	var x  = event.clientX - rect.left - m.left - ax.graph.offset;
	var y  = event.clientY - rect.top - m.top - ay.graph.offset;

	var pos = {
		x: x,
		y: y,
		in: x >= 0 && x <= ax.graph.size && y >= 0 && y <= ay.graph.size,
		init: {}
	};

	for (var i in this._axis) {
		pos.init[i] = this._axis[i].from
	}
	return pos;
}


// Wheel: zoom in/out
Graph.prototype.mouseWheelEvent = function (event)
{
	var move = this._eventToPosition(event);
	if (move.in) {
		var delta = lteLogs.getMouseWheelDelta(event);
		var offset = delta / Math.abs(delta);
		var ax = this._axis.x;

		this._setWindow(ax, ax.graph.from + offset * ax.stepMin / ax.graph.scale, 0);
		return true;
	}
};

// Down
Graph.prototype.mouseDownEvent = function (event)
{
	var move = this._eventToPosition(event);
	if (move.in)
		this._move = move;
};

// Move
Graph.prototype.mouseMoveEvent = function (event)
{
	var pos = this._eventToPosition(event);

	// Scroll into window
	if (this._move) {
		for (var i in this._axis) {
			var a = this._axis[i];
			if (i === 'x')
				this._setWindow(a, this._move.init.x + (this._move.x - pos.x) / a.graph.scale, 0);
			else
				this._setWindow(a, this._move.init[i] + (pos.y - this._move.y) / a.graph.scale, 0);
		}
		return true;

	// Highlight ?
	} else if (this.onOver) {

		// x is same for all series
		var ax = this._axis.x;
		var rX = 10 / ax.graph.scale;
		var x = pos.x / ax.graph.scale + ax.graph.from;

		// Look into all series
		for (var s = this._seriesList.length; s--;) {
			var serie = this._seriesList[s];
			if (!serie.enabled) continue;

			var ay = serie.y;
			var rY = 10 / ay.graph.scale;
			var y = ay.graph.to - pos.y / ay.graph.scale;
			var values = serie.values;

			for (var i = 0; i < values.length; i++) {
				var value = values[i];
				if (Math.abs(value.x - x) < rX && Math.abs(value.y - y) < rY) {

					this.onOver(serie.id, value, {
							x: this._axisFormat(value.x, ax.unit),
							y: this._axisFormat(value.y, ay.unit),
							title: serie.title,
						},
						event.clientX + (value.x - x) * ax.graph.scale,
						event.clientY - (value.y - y) * ay.graph.scale
					);

					// Move to top
					this._seriesList.splice(s, 1);
					this._seriesList.push(serie);
					return true;
				}
			}
		}
		this.onOver(null, null);
	}
	return false;
}

Graph.prototype.highlight = function (value)
{
	if (this._highlightedValue !== value) {
		this._highlightedValue = value;
		return true;
	}
	return false;
};

// Out
Graph.prototype.mouseOutEvent = function (event)
{
	this._move = undefined;
	this.onOver(null, null);
};

// Up
Graph.prototype.mouseUpEvent = function (event)
{
	this._move = undefined;
};


