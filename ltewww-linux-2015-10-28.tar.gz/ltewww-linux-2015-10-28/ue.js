Ext.define("lte.ue.tab", {

	extend: 'Ext.panel.Panel',
	layout: 'border',
	
	constructor: function (config) {
		this._client = config.client;

		// Listen events
		this._listenerId = this._client.registerEventListener('*', this._eventListener.bind(this));

		this.callParent(arguments);
	},

	listeners: {
		activate: function () {
			this._updater.unlock();
			this._chart.unlock();
		},
		deactivate: function () {
			this._updater.lock();
			this._chart.lock();
		},
		close: function () {
			this._updater.destroy();
			this._client.unregisterEventListener(this._listenerId);
		},
	},

	lteUpdate: function() {
		this._updater.update(true);
	},

	initComponent: function () {
		this.callParent(arguments);

		// Update UE list
		this._updater = Ext.create("lte.updater", {
			scope:			this,
			updateDelay:	1000,
			dirty:			true,
			lock:			1,
			handler:		function () {

				this._client.sendMessage({message: 'ue_get'}, function (msg) {

					var ueHash = {};
					msg.ue_list.forEach(function (ue) {ueHash[ue.ue_id] = ue; });
					for (var i = ueStore.getCount(); i--;) {

						var record = ueStore.getAt(i);
						var ue_id  = record.get("ue_id");
						var ue     = ueHash[ue_id];
						if (ue) {
							record.set(ue);
							delete ueHash[ue_id];
						} else {
							ueStore.removeAt(i);
						}
					}

					ueStore.add(Object.keys(ueHash).map(function (ue_id) { return ueHash[ue_id]; }));
				});
			}
		});

		// Catch ue_update events
		this._client._msgHandler.ue_update = (function (msg) {
			this._updater.update(true);
		}).bind(this);

		var ueStore = Ext.create('Ext.data.Store', {
			fields: ["imsi", "ue_id", "category", "power_on", "timing_advance", "rnti", "rrc_state", "emm_state", "ip"]
		});

		var ueGrid = Ext.create('Ext.grid.Panel', {
			store: ueStore,
			selModel: {
				mode: "MULTI"
			},
			viewConfig:{
				markDirty: false
			},
			columns: [{
				xtype: 'actioncolumn',
				width: 30,
				text: "",
				dataIndex: 'power_on',
				items: [{
					scope: this,
					getClass: function (state, meta, rec, rowIndex, colIndex, store) {
						return state ? 'icon-ok' : 'icon-off';
					},
					tooltip: lteLogs.tooltip('Power on/off'),
					handler: function(view, rowIndex, colIndex, item, e, record) {
						this._client.sendMessage({
							message: record.get('power_on') ? 'power_off' : 'power_on',
							ue_id: record.get('ue_id'),
						}, function (resp) {
						});
					}
				}],
			}, {
				text: "ID",
				dataIndex: "ue_id",
				width: 120
			}, {
				text: "IMSI",
				dataIndex: "imsi",
				width: 150
			}, {
				text: 'RNTI',
				dataIndex: 'rnti',
				renderer: function (value) { return value.toString(16); },
				width: 70
			}, {
				text: 'Cat.',
				dataIndex: 'category',
				width: 65
			}, {
				text: 'RRC',
				dataIndex: 'rrc_state',
				width: 110
			}, {
				text: 'EMM',
				dataIndex: 'emm_state',
			}, {
				text: 'TA',
				dataIndex: 'timing_advance',
			}, {
				text: 'IP',
				dataIndex: 'ip',
				width: 120
			}],
			listeners: {
				scope: this,
				selectionchange: function () {
					updateSimButtons();
				},
				cellcontextmenu: function(myGrid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
					var items = [];

					var power_on = record.get("power_on");
					items.push({
						text: power_on ? 'Power off': 'Power on',
						scope: this,
						iconCls: power_on ? 'icon-off' : 'icon-ok',
						handler: function() {
							this._client.sendMessage({message: power_on ? 'power_off' : 'power_on', ue_id: record.get('ue_id')});
						}
					});
					// Connect to PDN
					items.push({
						text: 'Connect pdn',
						scope: this,
						iconCls: 'icon-dial',
						handler: function() {
							Ext.Msg.prompt('PDN Connect', 'Please enter APN:', function(btn, text) {
								if (btn == 'ok') {
									this._client.sendMessage({message: 'pdn_connect', apn: text, ue_id: record.get('ue_id')});
								}
							}, this);
						}
					});
					if (record.get("rrc_state") === "connected") {
						items.push({
							text: 'RRC reestablishment',
							scope: this,
							iconCls: 'icon-sync',
							handler: function() {
								this._client.sendMessage({message: 'rrc_reest', ue_id: record.get('ue_id')});
							}
						});
					}

					// Simulation
					for (var i = simNb = 0, length = simStore.getCount(); i < length; i++) {
						var sim = simStore.getAt(i);
						if (sim.get("ue").enabled) continue;
						if (!simNb++)
							items.push({xtype: 'menuseparator'});
						items.push({
							text: 'Start simulation ' + sim.get('name'),
							iconCls: 'icon-play',
							scope: this,
							handler: (function(sim, ue_id) {
								this._createUESimTab(sim, [ue_id]);
							}).bind(this, sim.getData(), record.get("ue_id"))
						});
					};

					var menu = new Ext.menu.Menu({items: items});
					var position = e.getXY();
					e.stopEvent();
					menu.showAt(position);

					myGrid.select(record);
				}
			}
		});

		// Simulation
		var simStore = Ext.create('Ext.data.Store', {
			fields: ["name", "scripts", "ue", "power"],
			proxy: {
				type: 'localstorage',
				id  : 'simLists'
			},
			listeners: {
				scope: this,
				load: function (s, records, success, eOpts) {
					if (success) {
						var sync = false;
						for (var i in records) {
							var data = records[i].getData();
							if (lteSim.fixScripts(data.scripts)) {
								sync = true;
								data = lteLogs.clone(data); // Must be different
								for (var j in data) {
									records[i].set(j, data[j]);
								}
							}
						}
						if (sync)
							simStore.sync();
					}
				}
			}
		});
		var newSimButton = Ext.create('Ext.Button', {
			text: 'Add',
			iconCls: 'icon-plus',
			scope: this,
			handler: function () {
				Ext.create("lte.sim.window", {
					title: "Add simulation",
					simRef: null,
					simStore: simStore,
				}).show();
			}
		});
		var delSimButton = Ext.create('Ext.Button', {
			text: 'Remove',
			iconCls: 'icon-moins',
			scope: this,
			disabled: true,
			handler: function () {
				var record = simGrid.getSelection();
				simStore.remove(record[0]);
				simStore.sync();
			}
		});
		var editSimButton = Ext.create('Ext.Button', {
			text: 'Edit',
			scope: this,
			iconCls: 'icon-report',
			disabled: true,
			handler: function () {
				Ext.create("lte.sim.window", {
					title: "Edit simulation",
					simRef: simGrid.getSelection()[0],
					simStore: simStore,
				}).show();
			}
		});
		var runSimButton = Ext.create('Ext.Button', {
			text: 'Run',
			iconCls: 'icon-play',
			scope: this,
			disabled: true,
			handler: function () {
				this._createUESimTab(simGrid.getSelection()[0].getData(),
									 ueGrid.getSelection().map(function (rec) { return rec.get("ue_id"); }));
			}
		});
		var copySimButton = Ext.create('Ext.Button', {
			text: 'Copy',
			iconCls: 'icon-copy',
			scope: this,
			disabled: true,
			handler: function () {
				var sim = simGrid.getSelection()[0];
				var copy = lteLogs.clone(sim.getData());
				delete copy.id;
				copy.name = copy.name + " (copy)";
				simStore.add(copy);
			}
		});

		var exportSimButton = Ext.create('Ext.Button', {
			text: 'Export',
			iconCls: 'icon-download',
			scope: this,
			disabled: true,
			handler: function () {
				this._exportSim(simGrid.getSelection()[0].getData(),
								ueGrid.getSelection().map(function (rec) { return rec.get("ue_id"); }));
			}
		});

		var simGrid = Ext.create('Ext.grid.Panel', {
			store: simStore,
			tbar: Ext.create('Ext.toolbar.Toolbar', {
				items: [runSimButton, editSimButton, copySimButton, newSimButton, delSimButton, exportSimButton]
			}),
			columns: [{
				text: "Name",
				dataIndex: "name",
				flex: 1
			}, {
				text: "Dur.",
				dataIndex: "power",
				align: 'right',
				width: 60,
				renderer: function(power, metaData, record, rowIndex, colIndex, store, view) {
					if (power.enabled)
						return power.duration;
					var scripts = record.get("scripts");
					return scripts.reduce(function (d, s) { return Math.max(d, s.start_delay + s.duration); }, 0) || "&nbsp;";
				}
			}, {
				text: "UE",
				dataIndex: "ue",
				align: 'right',
				renderer: function(ue, metaData, record, rowIndex, colIndex, store, view) {
					return ue.enabled > 0 ? ue.count : "&nbsp;";
				},
				width: 50
			}, {
				text: "IP",
				dataIndex: "scripts",
				align: 'right',
				renderer: function(scritps, metaData, record, rowIndex, colIndex, store, view) {
					return scritps.length;
				},
				width: 50
			}, {
				text: "Power",
				dataIndex: "power",
				renderer: function(power, metaData, record, rowIndex, colIndex, store, view) {
					if (power.enabled)
						return power.caps + " caps, " + power.on_time + "/" + power.off_time + " on/off";
					return "&nbsp;";
				},
				flex: 1,
			}],
			listeners: {
				scope: this,
				selectionchange: function(view, selected, eOpts) {
					updateSimButtons();
				},
			}
		});
		var updateSimButtons = function () {
			var selected = simGrid.getSelection();
			delSimButton.setDisabled(!selected.length);
			editSimButton.setDisabled(!selected.length);
			copySimButton.setDisabled(!selected.length);

			var ready = !(selected.length && (selected[0].get("ue").enabled || ueGrid.getSelection().length));
			runSimButton.setDisabled(ready);
			exportSimButton.setDisabled(ready);
		};

		Ext.Function.defer(function () {simStore.load();}, 100);


		this.add({
			region: 'center',
			layout: 'fit',
			items: [ueGrid],
		});
		this.add({
			title: 'Simulation',
			iconCls: 'icon-report',
			collapsed: false,
			collapsible: true,
			split: true,
			layout: 'fit',
			region: 'east',
			width: 500,
			items: [simGrid],
		});

		var now = new Date() - 0;
		var chart = this._chart = Ext.create('lte.graph', {
			graph: {
				axis: {
					x: {
						unit: 'date',
						auto: 'max',
						min: now,
						max: now + 300000,
					},
					y: {
						unit: 'brate'
					},
					z: {
					}
				},
				series: lteLogs.ueSeries
			}
		});
		this.add({
			region: 'south',
			layout: 'fit',
			height: 300,
			split: true,
			items: [chart],
		});
		lteLogs.toto = chart;
	},

	_eventListener: function (event) {

		switch (event.type) {
		case 'stats':
			var chart = this._chart;
			if (!chart) return;

			var now = new Date() - 0;
			for (var cell_id in event.data.cells) {
				var data = event.data.cells[cell_id];
				for (var id in data) {
					chart.addValues(id, [{
						x: now,
						y: data[id]
					}]);
				}
				break; // XXX: handle multiple cells
			}
			break;
		}
	},

	_exportSim: function (sim, ue_ids) {
		var gen = lteSim.generateScripts(sim, ue_ids);

		// UE config
		var ue_db = gen.list.map(function (ue) {
			// Generate events from message
			var events = [];
			for (var i = 0; i < ue.scripts.length; i++) {
				var script = ue.scripts[i];
				for (var j = 0; j < script.msg.length; j++) {
					var msg = script.msg[j];
					var event = lteLogs.clone(msg);
					event.event = msg.message;
					delete event.ue_id;
					delete event.message;
					events.push(event);
				}
			}
			events.sort(function (a, b) { return a.start_time - b.start_time; });

			return {
				//log_filename: '/tmp/ue' + ue.ue_id + '.log',
				imsi: ue.imsi,
				K: ue.K,
				ue_category: 3,
				half_duplex: false,
				//position: [300, 0],
				//speed: 0,
				//direction: 0,
				//noise_power: -100,
				//power: 20,
				sim_events: events
			};
		});
		var mme_db = gen.list.map(function (ue) {
			return {
				imsi: ue.imsi,
				K: ue.K,
				amf: 0x9001, // XXX
				sqn: "000000000000", // XXX
			}
		});

		// Export
		var file = sim.name.replace(/[ \/]/g, '-');
		lteLogs.exportFile('ue_list: ' + JSON.stringify(ue_db, null, 2), file + '.ue.cfg', 'text/json;charset=utf-8;');
		lteLogs.exportFile('ue_db: ' + JSON.stringify(mme_db, null, 2), file + '.mme.cfg', 'text/json;charset=utf-8;');

	},

	// Create UE main tab
	_createUESimTab: function (sim, ue_ids) {
		var tab = Ext.create('lte.ue.sim', {
			title: this._client.getName() + ": " + sim.name,
			sim: sim,
			ue_ids: ue_ids,
			client: this._client
		});
		lteLogs.addTab(tab);
	},
});



Ext.define("lte.ue.sim", {

	extend: 'Ext.panel.Panel',
	layout: 'border',
	closable: true,
	iconCls: 'icon-report',

	constructor: function (config) {
		this._client	= config.client;
		this._sim		= config.sim;
		this._ue_ids	= config.ue_ids || [];
		this._startDate = new Date();

		// Listen events
		this._listenerId = this._client.registerEventListener('*', this._eventListener.bind(this));

		this.callParent(arguments);
	},

	listeners: {
		activate: function () {
			this._updater.unlock();
		},
		deactivate: function () {
			this._updater.lock();
		},
		close: function () {
			this._updater.destroy();
			this._client.unregisterEventListener(this._listenerId);
		},
	},

	addLog: function(category, name, msg) {
		this._logStore.add({
			time:	new Date(),
			cat:	category,
			name:	name,
			msg:	msg,
		});
	},

	addScriptLog: function (script, msg) {
		this.addLog(script.category, script.name, msg);
	},

	initComponent: function () {
		this.callParent(arguments);

		lteLogs.sim = this;
		
		this._restartButton = Ext.create('Ext.Button', {
			text: 'Retry',
			iconCls: 'icon-refresh',
			scope: this,
			disabled: true,
			handler: function () {
				this._logStore.loadData([]); // Reset
				this._startTest();
			}
		});

		this._exportButton = Ext.create('Ext.Button', {
			text: 'Export',
			iconCls: 'icon-download',
			scope: this,
			handler: function () {
				this._exportReport();
			}
		});

		// Logs
		var logResetButton = Ext.create('Ext.Button', {
			text: 'Reset',
			iconCls: 'icon-cut',
			scope: this,
			handler: function () {
				this._logStore.loadData([]);
			}
		});
		this._logStore = Ext.create('Ext.data.Store', {
			fields: ['time', 'cat', 'name', 'msg', 'ue_id'],
			data: []
		});
		var logGrid = Ext.create('Ext.grid.Panel', {
			store: this._logStore,
			width: '100%',
			columns: [{
				text: 'Ellapsed',
				dataIndex: 'time',
				width: 90,
				renderer: (function(value, metaData, record, rowIndex, colIndex, store, view) {
					return lteLogs.ts2time(value - this._startDate);
				}).bind(this)
			}, {
				text: '#',
				dataIndex: 'cat',
				width: 65,
			}, {
				text: 'Name',
				dataIndex: 'name',
				width: 120,
			}, {
				text: 'Message',
				dataIndex: 'msg',
				flex: 1
			}]
		});


		// Generate scripts
		var gen = lteSim.generateScripts(this._sim, this._ue_ids);
		var ueList = this._ueList = gen.list;
		var scriptList = this._scriptList = gen.scripts;
		this._duration = gen.duration;

		// Initialize display
		ueList.forEach((function (ue) {
			var sList = ue.scripts.filter(function (script) { return script.ip; });

			var curList = [];
			for (var i = 0; i < sList.length; i++) {
				var s0 = sList[i];

				s0.overlapList	= [];
				s0.overlapMax	= 0;

				// Purge
				for (var j = curList.length; j--;) {
					var s1 = curList[j];
					if (s1.time + s1.duration <= s0.time)
						curList.splice(j, 1);
				}

				var n = curList.push(s0);

				for (var j = 0; j < curList.length; j++) {
					var s1 = curList[j];
					s1.overlapMax = Math.max(n, s1.overlapMax);
					s1.overlapList.push(s0);
					s0.overlapList.push(s1);
				}
			}
			
			var hUE = this._hUE;
			var tMargin = this._timeMargin;
			var sMargin = this._scriptMargin;
			for (var i = 0; i < ue.scripts.length; i++) {
				var script = ue.scripts[i];

				var x0 = (script.time + tMargin) * this._tScale;
				var x1 = x0 + script.duration * this._tScale;

				switch (script.type) {
				case 'power':
					script.x0 = x0;
					script.x1 = x1;
					script.y0 = 0;
					script.y1 = hUE;
					break;

				default:
					if (script.ip) {
						var n = script.overlapList.reduce(function (a, b) { return Math.max(a, b.overlapMax); }, script.overlapMax);

						var used = new Array(n); // Count me !
						script.overlapList.forEach(function (s) { if (s.overlapIndex !== undefined) used[s.overlapIndex] = true});
						for (var j = 0; j < n && used[j] !== undefined; j++);
						script.overlapIndex = j;

						script.x0 = x0;
						script.x1 = x1;
						script.y0 = Math.floor(j * hUE / n) + (sMargin >> 1);
						script.y1 = Math.floor(++j * hUE / n) - (sMargin >> 1);
					}
					break;
				}
			}
		}).bind(this));

		this.add({
			region: 'west',
			layout: 'fit',
			width: 550,
			split: true,
			tbar: {items:[logResetButton, this._restartButton, this._exportButton]},
			items: [logGrid],
		});
		this.add({
			split: true,
			layout: 'fit',
			region: 'center',
			items: [this._createSimReport()]
		});

		// Create UE ?
		this._client.info("Start sim ", this._sim.name, "for", ueList.length);
		if (this._sim.ue.enabled) {

			var addScript = {
				message:	"ue_add",
				text:		"Create UEs",
				list:		ueList.map(function (ue) {
					var cfg = {};
					for (var i in ue) {
						if (i !== "scripts")
							cfg[i] = ue[i];
					}
					return cfg;
				})
			};

			this._client.sendMessage(addScript, (function (resp) {

				var info = resp.info;
				for (var i = 0; i < info.length; i++) {
					if (!info[i].match(/UE #\d+ already created/)) {
						Ext.Msg.alert('Error', info[i]);
						return;
					}
				}
				this._startTest();

			}).bind(this));

		} else {
			this._startTest();
		}
	},


	_setScriptResult: function (script, results) {

		var globalRatio = 0;
		var log  = [];
		switch (script.type) {
		case "ping":
			var report = results[0].report;
			log.push(report.recv + "/" + report.sent + " replies");
			if (report.sent > 0)
				globalRatio = report.recv / report.sent;
			break;

		case "udp":
		case "rtp":
		case "flood":
		case "voip":
			var ok = 0;
			var total = 0;
			for (var i = 0; i < results.length; i++) {
				var result = results[i];
				var report = result.report;
				var msg = script.msg[i];

				total += report.sent;
				ok += report.recv;
				switch (msg.message) {
				case 'cbr_recv':
				case 'flood_recv':
					if (report.sent > 0) {
						var ratio = report.recv / report.sent;
						log.push('DL: ' + Math.floor(ratio * 100) + '%, ' + report.recv + '/' + report.sent + ' packet(s) received');
					}
					break;

				case 'cbr_send':
				case 'flood_send':
					if (report.sent > 0) {
						var ratio = report.recv / report.sent;
						log.push('UL: ' + Math.floor(ratio * 100) + '%, ' + report.recv + '/' + report.sent + ' packet(s) transfered');
					}
					break;
				}
			}
			if (total > 0)
				globalRatio = ok / total;
			break;

		case "http":
			var report = results[0].report;
			var rate = report.duration > 0 ? (8 * report.rx_size / report.duration / 1000000).toFixed(3) : 0;
			log.push(rate + " Mbps, " + (report.rx_size / 1000000).toFixed(3) + " MB, " + report.connections + " connection(s)");
			globalRatio = report.rx_size ? 1 : 0;
			break;
		}
		var r = lteLogs.padLeft(Math.round((1 - globalRatio) * 255).toString(16), "0", 2);
		var g = lteLogs.padLeft(Math.round(globalRatio * 255).toString(16), "0", 2);
		var b = lteLogs.padLeft(Math.round(32).toString(16), "0", 2);

		script.ratio	= globalRatio;
		script.log		= log.join('<br/>');
		script.color	= "#" + r + g + b;
		script.status	= "done";

		this.addScriptLog(script, Math.floor(globalRatio * 100) + '%');
	},


	_scriptMessageCallback: function (script, respList, resp, index, end) {

		switch (script.type) {
		case 'power':
			if (resp.message === 'power_on') {
				this.addScriptLog(script, "Power on");
				script.status = 'start';
				script.log    = 'On';
			} else {
				this.addScriptLog(script, "Power off");
				script.status = 'done';
				script.log    = 'Off';
			}
			break;

		default:
			// Notification received
			if (resp.notification) {
				if (resp.notification === 'start' && script.status !== 'start') {
					this.addScriptLog(script, "Start");
					script.status = 'start';
					script.log    = 'In progress...';

					this._globalStatusDirty = true;
					this._scriptToolTipUpdate(script);
				}
				return;
			}

			this._globalStatusDirty = true;

			// Log
			if (resp.error)
				this.addScriptLog(script, resp.error);
			else if (resp.report)
				this.addScriptLog(script, resp.report.info);
			else if (resp.info)
				this.addScriptLog(script, resp.info);

			if (end)
				this._setScriptResult(script, respList);
			break;
		}

		// End ?
		for (var i = 0; i < this._scriptList.length; i++) {
			if (this._scriptList[i].status !== 'done')
				return;
		}
		this._endTest();
	},


	// Start
	_startTest: function () {

		// Graph
		var graph = this._graph = new Graph({
			margin: {left: this._wName, top: this._marginHeight, bottom: this._marginHeight, right: 0},
			axis: {
				x: {
					auto: 'none',
					min: -this._timeMargin,
					max: (this._duration + this._timeMargin),
					unit: 'time',
					grad: false,
				},
				y: {
					axis: 0,
					unit: 'brate'
				},
				z: {
				}
			},
			series: lteLogs.ueSeries,
			onOver: this._onGraphOver.bind(this),
		});

		// Init
		this._testTimeout = Ext.Function.defer(this._endTest, (this._duration + 10) * 1000, this);
		this._restartButton.setDisabled(true);
		this._client.profileReset();

		// Start scripts
		for (var i = 0, count = this._scriptList.length; i < count; i++) {
			var script = this._scriptList[i];

			delete script.color;
			script.ratio = 0;
			script.log = "Not started";
			script.status = "wait";

			// Send message
			this._client.sendMessageList(script.msg, this._scriptMessageCallback.bind(this, script));
		};

		this.addLog('', 'Start', this._scriptList.length + ' event(s)');
		this._startTime = new Date() - 0;
		this._statState = "add";
		this._globalStatusDirty = true;
		this._updater.update(true);
	},

	_updateGlobalStatus: function () {

		var list    = [];
		var result  = 0;
		var ended   = 0;
		var started = 0;
		var error   = 0;
		var ok      = 0;

		for (var i = 0, count = this._scriptList.length; i < count; i++) {
			var script = this._scriptList[i];
			if (!script.ip) continue;

			switch (script.status) {
			case "start":
				started++;
				break;
			case "timeout":
				ended++;
				error++;
				break;
			case "done":
				result += script.ratio;
				ended++;
				if (!script.ratio)
					error++;
				else if (script.ratio >= 1)
					ok++;
				break;
			}
		};

		if (ended > 0)
			list.push(Math.round(100 * result / ended) + "%");
		list.push(this._scriptList.length + " script(s)");
		if (started > 0)
			list.push(started + " in progress");
		if (error > 0)
			list.push(error + " error(s)");
		if (ok > 0)
			list.push(ok + " passed");
		if (ended > 0)
			list.push(ended + " done");

		this._scriptLabel.setText("Results: " + list.join(", "));
	},

	// End
	_endTest: function () {

		clearTimeout(this._testTimeout);
		this._testTimeout = 0;
		this._client.profileDump();

		// Script timeout
		for (var i = 0, count = this._scriptList.length; i < count; i++) {
			var script = this._scriptList[i];

			if (script.status !== "done") {
				script.status = 'timeout';
				script.log    = 'Timeout';
				this.addScriptLog(script, 'Timeout');
			}
		};

		this.addLog('', 'End', 'End of scripts');

		this._restartButton.setDisabled(false);

		if (this._globalStatusDirty) {
			this._updateGlobalStatus();
			this._globalStatusDirty = false;
		}
		this._statState = "last";
		this._updater.update(true);
	},


	// Draw config
	_hUE: 40,
	_wName: 100,
	_tScale: 10,
	_marginWidth: 5.5,
	_marginHeight: 5.5,
	_graphHeight: 200,
	_scriptMargin: 4,
	_timeMargin: 1,

	_createSimReport: function () {

		this._scriptLabel = Ext.create('Ext.form.Label', {
			text: 'Status:',
			width: '100%',
			style: {'font-size':'16px'}
		});

		this._updater = Ext.create("lte.updater", {
			scope:			this,
			updateDelay:	500,
			dirty:			false,
			lock:			1,
			handler:		this._drawReport.bind(this)
		});

		// Create canvas
		this._canvasContainer = Ext.create('Ext.panel.Panel', {
			tbar: {items: [this._scriptLabel]},
			html: '<canvas></canvas>',
			layout: 'fit',
			autoScroll: true,
			listeners: {
				scope: this,
				resize: function(container) {
					if (!this._canvas) {
						// Configure canvas
						var canvas = this._canvas = container.el.down("canvas").dom;
						canvas.width = this._wName + (this._duration + this._timeMargin * 2) * this._tScale + this._marginWidth * 2;
						canvas.height = this._hUE * this._ueList.length + this._marginHeight * 2 + 200;
						canvas.addEventListener("mousemove", this._mouseMoveEvent.bind(this), false);
						canvas.addEventListener("mouseout", this._mouseOutEvent.bind(this), false);

						this._toolTip = Ext.create('Ext.tip.ToolTip', {
							target: canvas,
							trackMouse: false,
							autoHide: false,
						});
						this._updater.update(true);
					}
				}
			}
		});
		return this._canvasContainer;
	},

	_exportReport: function () {

		var csv = [];
		var sim = this._sim;

		// Config
		var cells = this._client.getParams('cells');
		csv.push("*** Config ***");
		for (var i in cells) {
			csv.push(["RB DL", cells[i].n_rb_dl]);
			csv.push(["RB UL", cells[i].n_rb_ul]);
		}
		if (sim.power.enabled) {
			csv.push(["CAPS", sim.power.caps]);
			csv.push(["Max UE", sim.power.on_max]);
			csv.push(["Power on duration", sim.power.on_time]);
			csv.push(["Power off duration", sim.power.off_time]);
		}
		if (sim.ue.enabled) {
			csv.push(["UE", sim.ue.count]);
		} else {
			csv.push(["UE", this._ue_ids.length]);
		}
		csv.push("");

		// Scripts
		csv.push("*** Scripts ***");
		csv.push(["UE ID", "Name", "Type", "Start", "Stop", "Status", "Result"]);
		for (var i = 0, length = this._scriptList.length; i < length; i++) {
			var script = this._scriptList[i];
			if (!script.ip) continue;

			csv.push([
				script.category,
				script.name,
				script.type,
				script.time,
				script.time + script.duration,
				script.status,
				script.ratio * 100
			]);
		}
		csv.push("");

		// Stats
		var graph = this._graph;
		var ueSeries = lteLogs.ueSeries;
		csv.push("*** Stats ***");
		var series = Object.keys(ueSeries);
		csv.push(series.reduce(function (o, v, i) {
			o.push(ueSeries[v].title);
			return o
		}, ["Time"]));

		series = series.map(function(s) { return graph.getValues(s);});
		var nSeries = series.length;
		for (var n = 0; n < 10; n++) {
			var values = series.map(function (v) { return v.length ? v[0].x : Number.POSITIVE_INFINITY; });

			var value = Math.min.apply(Math, values);
			if (value === NaN || value === Number.POSITIVE_INFINITY)
				break;

			var stats = [value];
			for (var i = 0; i < nSeries; i++) {
				if (value === series[i][0].x) {
					stats[i+1] = series[i].shift().y;
				}
			}
			csv.push(stats);
		}

		// Format
		for (var i = 0; i < csv.length; i++) {
			var line = csv[i];
			if (line instanceof Array) {
				line = line.join(";");
			}
			csv[i] = line;
		}

		var date = new Date(this._startTime);
		var filename = sim.name + '-' + 
				("0" + date.getFullYear()).slice(-4) +
				("0" + (date.getMonth() + 1)).slice(-2) +
				("0" + date.getDate()).slice(-2) + "-" +
				("0" + date.getHours()).slice(-2) + ":" +
				("0" + date.getMinutes()).slice(-2) + ":" +
				("0" + date.getSeconds()).slice(-2) +
				'.csv';

		lteLogs.exportFile(csv.join("\n"), filename, 'text/csv;charset=utf-8;');
	},

	_drawReport: function () {

		var canvas = this._canvas;
		if (!canvas || !this._graph) return;

		var t0 = new Date();
		
		var ctx    = canvas.getContext("2d");
		var hUE    = this._hUE;
		var wName  = this._wName;
		var tScale = this._tScale;
		var tMargin = this._timeMargin;

		ctx.fillStyle		= 'black';
		ctx.strokeStyle		= 'black';
		ctx.textBaseline	= 'middle';
		ctx.textAlign		= 'center';
		ctx.clearRect(0, 0, canvas.width, canvas.height);

		var simWidth = (this._duration + tMargin * 2) * tScale;
		this._graph.draw(canvas, this._marginWidth, this._marginHeight, wName + simWidth, this._graphHeight);

		ctx.save();
		ctx.translate(this._marginWidth, this._marginHeight + this._graphHeight);

		// For each UE
		for (var i = 0; i < this._ueList.length; i++) {
			var ue = this._ueList[i];

			ctx.save();
			ctx.translate(0, i * hUE);

			// Name
			ctx.strokeRect(0, 0, wName, hUE);
			ctx.font = (hUE >> 1) + "px Arial";
			ctx.fillText(ue.ue_id, wName >> 1, hUE >> 1);

			// Scripts
			ctx.font = (hUE >> 2) + "px Arial";
			ctx.translate(wName, 0);
			ctx.fillStyle = '#B0C0D0';
			ctx.fillRect(0, 0, simWidth, hUE);

			for (var s = 0; s < ue.scripts.length; s++) {
				var script = ue.scripts[s];
				this._drawScript(ctx, script);
			}

			// Frame
			ctx.strokeStyle = 'black';
			ctx.strokeRect(0, 0, simWidth, hUE);

			ctx.restore();
		}

		var ellapsed = (new Date() - this._startTime) / 1000;
		var max = this._duration + tMargin;
		if (ellapsed < max) {
			// Poll refresh
			this._updater.update(true);
		} else {
			ellapsed = max;
		}
		var x = Math.floor(wName + (ellapsed + tMargin) * tScale);
		ctx.beginPath();
		ctx.moveTo(x, -this._graphHeight);
		ctx.lineTo(x, this._ueList.length * hUE);
		ctx.strokeStyle = 'rgba(0,0,0,0.7)';
		ctx.lineWidth = 5;
		ctx.lineCap = 'round';
		ctx.stroke();
		ctx.restore();

		this._updateGlobalStatus();

		lteLogs.prof("Draw sim in", new Date() - t0, "ms");
	},

	_drawScript: function (ctx, script) {

		switch (script.type) {
		case 'power':
			if (script.x0 === undefined) return;
			ctx.fillStyle = '#F0F8FF';
			break;

		default:
			switch (script.status) {
			case "start":
				ctx.fillStyle = '#0080FF';
				var text = "...";
				break;
			case "done":
				ctx.fillStyle = script.color || 'white';
				var text = Math.floor(script.ratio * 100) + "%";
				break;
			case "timeout":
				ctx.fillStyle = '#808080';
				var text = "Timeout";
				break;
			case "wait":
				ctx.fillStyle = '#80C0FF';
				break;
			default:
				return;
			}
			break;
		}

		var x = script.x0;
		var y = script.y0;
		var w = script.x1 - script.x0;
		var h = script.y1 - script.y0;

		ctx.fillRect(x, y, w, h);
		ctx.strokeStyle = 'black';
		ctx.strokeRect(x, y, w, h);
		ctx.fillStyle = 'black';
		if (text)
			ctx.fillText(text, x + (w >> 1), y + (h >> 1));
	},

	_drawPowerOff: function (ctx, t0, t1) {
		var x = (t0 + this._timeMargin) * this._tScale;
		var w = (t1 + this._timeMargin) * this._tScale - x;

		ctx.fillStyle = '#C0C0C0';
		ctx.fillRect(x, 0, w, this._hUE);
		ctx.strokeStyle = 'black';
		ctx.strokeRect(x, 0, w, this._hUE);
	},

	_scriptToolTipUpdate: function (script) {
		if (script === this._toolTipRef) {
			this._toolTip.update(lteLogs.tooltip([
				"<b>" + script.name + "</b>:",
				"From " + script.time + "s to " + (script.time + script.duration) + "s",
				script.log,
			].join("<br/>")));
		}
	},

	_mouseMoveEvent: function (event) {

		var canvas = event.target;
		var rect = canvas.getBoundingClientRect();

		// Send to graph
		if (this._graph && this._graph.mouseMoveEvent(event))
			return;

		// Try to find script
		var x = event.clientX - rect.left - this._marginWidth - this._wName;
		var y = event.clientY - rect.top - this._marginHeight - this._graphHeight;
		var index = Math.floor(y / this._hUE);
		if (index >= 0 && index < this._ueList.length) {
			var ue = this._ueList[index];

			y -= index * this._hUE;
			for (var i = 0; i < ue.scripts.length; i++) {
				var script = ue.scripts[i];
				if (!script.ip) continue;
				if (x >= script.x0 && x < script.x1 && y >= script.y0 && y < script.y1) {

					this._toolTipRef = script;
					this._scriptToolTipUpdate(script);
					this._toolTip.showAt([script.x0 + rect.left + this._marginWidth + this._wName,
						script.y1 + rect.top + this._marginHeight + this._graphHeight + index * this._hUE]);
					return;
				}
			}
		}
		this._mouseOutEvent();
	},

	_onGraphOver: function (id, value, info, posX, posY) {
		if (id) {
			this._toolTipRef = null;
			this._toolTip.update(lteLogs.tooltip(info.title + ':<br/>' + info.y + " at " + info.x));
			this._toolTip.showAt([posX + 10, posY + 10]);
		}
		if (this._graph.highlight(value))
			this._updater.update(true);
	},

	_mouseOutEvent: function (event) {
		this._toolTipRef = null;
		this._toolTip.hide();
	},

	_eventListener: function (event) {

		switch (event.type) {
		case 'stats':
			var graph = this._graph;
			if (!graph || !this._statState) return;

			var now = (new Date() - this._startTime) / 1000;

			// For each cell
			for (var cell_id in event.data.cells) {
				var data = event.data.cells[cell_id];
				for (var id in data) {
					graph.addValues(id, [{
						x: now,
						y: data[id]
					}]);
				}
				break; // XXX: handle multiple cells
			}
			if (this._statState === "last") {
				this._updater.update(true);
				this._statState = null;
			}
			break;
		}
	},

});


lteLogs.ueSeries = {
	dl_bitrate: {title: 'DL bitrate'},
	ul_bitrate: {title: 'UL bitrate'},
	dl_sched_users_min: {title: "DL min users / TTI", y: 'z', enabled: false},
	dl_sched_users_avg: {title: "DL average users / TTI", y: 'z'},
	dl_sched_users_max: {title: "DL max users / TTI", y: 'z', enabled: false},
	ul_sched_users_min: {title: "UL min users / TTI", y: 'z', enabled: false},
	ul_sched_users_avg: {title: "UL average users / TTI", y: 'z'},
	ul_sched_users_max: {title: "UL max users / TTI", y: 'z', enabled: false},
};
