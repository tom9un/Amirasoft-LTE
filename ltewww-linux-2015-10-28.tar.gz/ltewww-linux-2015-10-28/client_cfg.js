/*
 * Copyright (C) 2012-2015 Amarisoft
 *
 * Amarisoft LTE Web interface 2015-10-28
 */

Ext.define("lte.client.config", {

	extend: 'Ext.window.Window',
	layout: 'fit',
	width: 400,
	height: 200,
	modal: true,

	constructor: function (config) {

		if (config.client) {
			this._applyMsg = 'Update';
			this._clientClass = Ext.getClassName(config.client);

			switch (this._clientClass) {
			case 'lte.client.server':
				this.height = 500;
				break;
			}
		} else {
			this._applyMsg = 'Create';
			this._clientClass = config.class;
			delete config.class;
		}

		this.callParent(arguments);
	},

	initComponent: function () {
		this.callParent(arguments);

		var client = this.client;
		lteLogs.client = client;

		if (client) {
			var name = client.getName();
			var disabled = false;

			switch (this._clientClass) {
			case 'lte.client.server':
				var logsConfig = client.getLogsConfig();
				if (logsConfig) {
					if (this.firstConnection)
						disabled = true;

				} else {
					// Client has never been connected
					if (client.getState() === 'connecting') {
						client.toggleState();
						this._restartClient = true;
					}
				}
				break;
			}

		} else {
			var name = 'Client';
			var disabled = false;
		}

		var fields = [Ext.create("Ext.form.field.Text", {
			xtype: 'textfield',
			value: name,
			allowBlank: false,
			name: 'name',
			fieldLabel: 'Name',
			disabled: disabled,
			width: '100%',
		})];

		switch (this._clientClass) {
		case 'lte.client.server':
			var address = client ? client.getAddress().split(':') : ['127.0.0.1', 9000];

			fields.push(Ext.create("Ext.form.field.Text", {
				value: address[0],
				allowBlank: false,
				name: 'addr',
				fieldLabel: 'Address',
				width: '100%',
				disabled: disabled,
			}));

			fields.push(Ext.create("Ext.form.field.Number", {
				name: 'port',
				fieldLabel: 'Port',
				value: address[1],
				allowDecimals: false,
				minValue: 1,
				maxValue: 65535,
				width: '100%',
				disabled: disabled,
				step: 1
			}));
			break;

		case 'lte.client.url':
			fields.push(Ext.create("Ext.form.field.Text", {
				value: client ? client.getUrl() : window.location.href,
				allowBlank: false,
				name: 'url',
				fieldLabel: 'URL',
				width: '100%',
				disabled: disabled,
			}));
			break;
		}

		if (logsConfig)
			this._addLogsConfig(fields, logsConfig);

		var form = Ext.create('Ext.form.Panel', {
			bodyPadding: 5,
			items: fields,
			buttons: [{
				text: this._applyMsg,
				scope: this,
				handler: function() {
					if (form.isValid()) {
						var config = form.getForm().getFieldValues();

						if (client) {
							this._modifyClient(config);
						} else {
							this._addClient(config);
						}
						this.close();
					}
				}
			}]
		});


		this.add(form);
	},

	_modifyClient: function (config) {

		if (config.name)
			this.client.setName(config.name);

		switch (this._clientClass) {
		case 'lte.client.server':
			if (config.addr && config.port)
				this.client.setAddress(config.addr + ':' + config.port);

			this._logsSave(config);

			if (this._restartClient)
				this.client.toggleState();
			break;
		case 'lte.client.url':
			if (config.url)
				this.client.setUrl(config.url);
			break;
		}
		lteLogs.saveConfig();
		lteLogs.refreshClientGrid();
	},

	_addClient: function (config) {
		switch (this._clientClass) {
		case 'lte.client.server':
			lteLogs.addClient({
				type: 'server',
				name: config.name,
				address: config.addr + ':' + config.port,
				enabled: true,
			}, true, true);
			break;
		case 'lte.client.url':
			lteLogs.addClient({
				type: 'url',
				name: config.name,
				url: config.url,
				enabled: true,
				locked: false,
			}, true, true);
			break;
		}
	},

	_addLogsConfig: function (fields, config) {

		// Log max count
		fields.push(Ext.create('Ext.form.field.Number', {
			fieldLabel:	'Log buffer count',
			name:		'logCount',
			value:		config.count,
			minValue:	4096,
			maxValue:	MAX_LOGS,
			step:		10000,
			width:		'100%',
		}));

		// Create layer store
		var store = this._logsStore = Ext.create('Ext.data.Store', {
			fields: ['layer', 'filter', 'level', 'max_size'],
			data: Object.keys(config.layers).map(function (l) {
				var layer = config.layers[l];
				return {
					layer:		l,
					level:		layer.level,
					filter:		layer.filter,
					max_size:	layer.max_size,
				};
			})
		});

		fields.push(Ext.create('Ext.grid.Panel', {
			store: store,
			selType: 'cellmodel',
			plugins: [Ext.create('Ext.grid.plugin.CellEditing', {clicksToEdit: 1})],
			columns: [{
				text: 'Layer',
				dataIndex: 'layer',
				flex: 1
			}, {
				text: 'Filter',
				dataIndex: 'filter',
				flex: 1,
				editor: {
					xtype: 'combobox', store: lteLogs.levels, editable: false
				}
			}, {
				text: 'Level',
				dataIndex: 'level',
				flex: 1,
				editor: {
					xtype: 'combobox', store: lteLogs.levels, editable: false
				}
			}, {
				text: 'Max size',
				dataIndex: 'max_size',
				flex: 1,
				editor: {
					xtype: 'numberfield',
					maxValue: 1024,
					minValue: 0,
				}
			}],
		}));
	},

	_logsSave: function (config) {

		var store = this._logsStore;
		if (!store)
			return;

		var logs = {
			count: config.logCount,
			layers: {}
		};
		for (var i = 0, length = store.getCount(); i < length; i++) {
			var data = store.getAt(i).getData();

			logs.layers[data.layer] = {
				level:		data.level,
				max_size:	data.max_size,
				filter:		data.filter
			}
		};

		this.client.setLogsConfig(logs, true);
	},

});


