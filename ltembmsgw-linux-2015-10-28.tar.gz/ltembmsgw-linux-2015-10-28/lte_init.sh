#!/bin/sh
# Copyright (C) 2012-2014 Amarisoft
# LTEMBMSGW system config version 2015-10-28

# Run once as root after the boot to init the network for LTEMBMSGW.

# Check root access
if [ `id -u` != 0 ] ; then 
    echo -e "\033[33mWarning, script must be run with root permissions\033[0m"
    exit 1
fi

# Name of the network interface which is for multicast
ifname="default"

# IPv6 configuration
ipv6=0

while [ "$1" != "" ] ; do
  case $1 in
    -h|--help)
      echo "Usage:"
      echo "> $0 [<ifname>]";
      echo "  ifname: interface name of the network connect to ths outside world"
      exit 1;
      ;;
    *)
      ifname="$1"
      ;;
  esac
  shift
done

# May be ipv6
iflist=$(ifconfig -a | sed 's/[: \t].*//;/^$/d')
defif=$(netstat -rn | grep UG | awk '{print $8}')

if [ "$ifname" = "default" ] ; then
    ifname="$defif"
    echo "Using default interface '$ifname'";
fi

# Interface present ?
found=0;
for i in $iflist; do
    if [ "$i" = "$ifname" ] ; then
        found=1;
    fi
done
if [ "$found" = "0" ] ; then
    echo -e "\033[33mWarning, $ifname interface not found\033[0m"
    echo "Available interfaces:"
    for f in $iflist ; do
        if [ "$f" = "$defif" ] ; then
            echo -e "  - \033[32m$f\033[0m (default)"
        else
            echo "  - $f"
        fi
    done
    echo "You may edit this script to force interface and/or to edit iptables rules"
    exit 1
fi

# Set multicats default route
route add -net 224.0.0.0 netmask 224.0.0.0 $ifname

exit 0;
